<?php
/**
 * @access public
 * @package Entity
 */

class EPartita {
	
	public $id;
	public $nomep;
	public $datap;
	public $orap;
	public $risultato;
	public $note;
	public $disputata = '0';
	
	public $_squadra1;
	public $_squadra2;
	public $_campo;
	public $_username;

	
	
   /**
 	* Setta tutti i campi che gli vengono passati, negli attributi dell'oggetto attuale
 	* Se il dato relativo alla key attuale non � settato (o � null), allora non viene scritto
 	* nell'attributo relativo.
 	* @param mixed $dati � un array che contiene i campi necessari a 
 	* riempire quelli dell'oggetto.  
 	*/
    public function  setCampi($dati) {
        foreach($this as $key => $value){
            if(isset($dati[$key]))
                $this->$key = $dati[$key];
        }
        $this->addSquadra1($dati['_squadra1']);
        $this->addSquadra2($dati['_squadra2']);
        $this->addCampo($dati['_campo']);
        $this->addUtente($dati['username']);       
    }
    
    /**
     * 
     * Dato il nome aggiunge una squadra alla partita
     * @param string $nome
     */
    public function addSquadra1($nome){
    	 $fsquadra = USingleton::getInstance('FSquadra');
    	 $trovato = $fsquadra->esisteSquadra($nome);
    	 if ($trovato == ''){
    	 	$s1 = new ESquadra;
    	 	$s1->setNome($nome);
    	 	$this->_squadra1 = $s1;
    	 }
    	 else
    	 {
    	 	$this->_squadra1 = $trovato;
    	 }
    }
    
    /**
     * 
     * Dato il nome aggiunge una squadra alla partita
     * @param string $nome
     */
	public function addSquadra2($nome){
    	 $fsquadra = USingleton::getInstance('FSquadra');
    	 $trovato = $fsquadra->esisteSquadra($nome);
    	 if ($trovato == ''){
    	 	$s2 = new ESquadra;
    	 	$s2->setNome($nome);
    	 	$this->_squadra2 = $s2;
    	 }
    	 else
    	 {
    	 	$this->_squadra2 = $trovato;
    	 }
    }
    
    /**
     * 
     * Dato il nome aggiunge il campo alla partita
     * @param string $nome
     */
    public function addCampo($nome){
    	$campo = USingleton::getInstance('Fcampo');
    	$tmp = $campo->getCampoByName($nome);
    	$this->_campo = $tmp[0];
    }
    
    /**
     * 
     * Dato il nomeUtente aggiunge chi l'ha creata 
     * @param string $nome
     */
    public function addUtente($utente){
    	$futente = USingleton::getInstance('FUtente');
    	$trovato = $futente->esisteUtente($utente);
    	if ($trovato != ''){
    		$this->_username = $trovato;	
    	}
    }
}
?>