<?php

/**
 * @access public
 * @package Entity
 */

class ECampo {
	
	public $id;
	public $nome;
	public $descrizione;
	public $citta;
	public $foto;
	
   /**
 	* Setta tutti i campi che gli vengono passati, negli attributi dell'oggetto attuale
 	* Se il dato relativo alla key attuale non � settato (o � null), allora non viene scritto
 	* nell'attributo relativo.
 	* @param mixed $dati � un array che contiene tutti i campi necessari a riempire quelli dell'oggetto.
 	*/
    public function  setCampi($dati) {
        foreach($this as $key => $value){
            if(isset($dati[$key]))
                $this->$key = $dati[$key];
        }
             
    }
    

}

?>