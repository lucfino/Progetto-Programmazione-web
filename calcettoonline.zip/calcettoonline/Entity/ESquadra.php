<?php

/**
 * @access public
 * @package Entity
 */

class ESquadra {
	
	public $nome;
	public $giocate =0;
	public $golFatti=0;
	public $golSubiti=0;
	public $vittorie=0;
	public $sconfitte=0;
	public $pareggi=0;
		
	/**
	 * Setta il nome della squadra
	 * @param string
	 */
    public function  setNome($nome) {
        $this->nome = $nome;
    }
}

?>