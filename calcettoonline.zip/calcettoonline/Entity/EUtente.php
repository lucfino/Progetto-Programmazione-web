<?php

/**
 * @access public
 * @package Entity
 */


class EUtente {
    
	public $nomeUtente;
    public $password;
    public $email;
    public $residenza;
    public $nomeu;
    public $cognome;
    public $sesso;
    public $dataN;
    public $ban = 0;
    public $codiceAttivazione;
    public $gol = 0;
    public $attivato = 0;
    public $privilegi = 0;
    public $foto;
    public $mediaGol = 0;
    public $giocate = 0;
    
   
	/**
	 * Setta tutti i campi che gli vengono passati, negli attributi dell'oggetto attuale
	 * Se il dato relativo alla key attuale non � settato (o � null), allora non viene scritto
	 * nell'attributo relativo.
	 * @param mixed $dati � un array che contiene tutti i campi necessari a riempire quelli dell'oggetto,
	 * tranne il codiceAttivazione, che viene settato a parte.
 	 */
    public function  setCampi($dati) {
        foreach($this as $key => $value){
            if(isset($dati[$key]))
                $this->$key = $dati[$key];
        }
       
        $this->setCodiceAttivazione();
       
    }
    
    
    /**
     * Crea un codice di attivazione casuale
     */
    public function setCodiceAttivazione(){
        $this->codiceAttivazione = mt_rand(100000,9999999999);
    }

    /**
     * restituisce il codice d'attivazione
     */
    public function getCodiceAttivazione(){
        return $this->codiceAttivazione;
    }
    
}
    
?>
    
    