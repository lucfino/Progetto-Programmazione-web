<?php

/**
 * @access public
 * @package Entity
 */

class EVoto {

    public $id;
    public $voto;
    public $testo;
    public $_partita;
    public $_ricevente;
    public $_mittente;
    public $data;

    /**
     * Setta gli attributi della classe 
     */
    public function  setCampi($voto,$testo,$mitt,$ricev,$id) {
		$futente = USingleton::getInstance('FUtente');
		$fpartita = USingleton::getInstance('FPartita');
    	$this->voto=$voto;
        $this->testo=$testo;
        $mittente = $futente->load($mitt);
        $ricevente = $futente->load($ricev);
        $partita = $fpartita->load($id);
        $this->_partita= $partita;
        $this->_mittente = $mittente;
        $data = getdate();
        $this->data = $data['mday'].'/'.$data['mon'].'/'.$data['year'].' '.$data['hours'].':'.$data['minutes'];
        if ($ricevente != false)
        	$this->_ricevente = $ricevente;
        else
        	$this->_ricevente = $ricev;
    }
    
    /**
     * 
     * Calcola la media voto di un utente
     * @param string $nomeu
     * @param int $count
     */
    public function mediaVoto($nomeu,$count){
    	$fvoto = USingleton::getInstance('FVoto');
    	$voti = $fvoto->search(array(array('ricevente','=',$nomeu)));
    	$mediav = 0;
    	if ($voti != null)
			foreach ($voti as $item){
				$totale = 0;
				$totale += $item->voto;
			}
	    else 
	    	$totale = 0;	 
		return $mediav = $totale/$count;
    }
    
}
?>