<?php
/**
 * @access public
 * @package Entity
 */
class ERecupero {
    public $email;
    public $codiceConferma;

    /**
     * Setta l'attributo $email dal parametro
     * @param string $email
     */
    public function setCampi($email){
        $this->email=$email;
        $this->codiceConferma = mt_rand(1000000, 9999999999);
    }
}
?>
