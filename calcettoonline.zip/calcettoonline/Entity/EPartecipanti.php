<?php
/**
 * @access public
 * @package Entity
 */

class EPartecipanti {
	
	public $_partita;
	public $_utente;
	public $_squadra;
	
	
}