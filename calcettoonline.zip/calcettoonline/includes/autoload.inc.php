<?php
/**
 * Autoload fa' in modo che quando viene instanziata una classe, questa sia disponibile,
 * anche se non � stata inclusa nello script. Quindi evita di dover richiamare
 * all'interno degli script i vari require delle classi. Ogni classe � provvista di un
 * attributo $class_name. L'autoload controlla la prima lettera del classname, in
 * questo modo, riesce a capire quale tipo di classe � stata instanziata e sa' trovare
 * il percorso relativo al sorgente della classe. Una volta determinato il percorso
 * nel quale sono contenute tutte le classi di quel tipo, l'interprete capisce dove andare
 * a prendere metodi e attributi. Includendo autoload nella home, tale procedimento, � valido
 * per tutte le classi incluse.
 * 
 * @package Includes
 */

function __autoload($class_name) {
    switch ($class_name[0]) {
        case 'V':
            require_once ('View/'.$class_name.'.php');
            break;
        case 'F':
            require_once ('Foundation/'.$class_name.'.php');
            break;
        case 'E':
            require_once ('Entity/'.$class_name.'.php');
            break;
        case 'C':
            require_once ('Controller/'.$class_name.'.php');
            break;
        case 'U':
            require_once ('Foundation/Utility/'.$class_name.'.php');
    }
}

?>
