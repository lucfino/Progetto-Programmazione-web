<?php
/**
 * @access public
 * @package Foundation
 */

class FPartecipanti extends Fdb{
    
	/**
     * Costruisce la classe
     */
	public function __construct() {
        $this->_table='partecipanti';
        $this->_key='id_partita,utente';
        $this->_return_class='EPartecipanti';
        USingleton::getInstance('Fdb');
    }
    
    /**
     * Salva nel db tutti i partecipanti di una partita
     * @see Fdb::store()
     */ 
    public function store($object){
   		$object->id_partita = $object->_partita->id;
   		$object->squadra = $object->_squadra->nome;
    	if ($object->_nomiUtenti){
   			foreach ($object->_nomiUtenti as $item){
    			$object->utente = $item->nomeUtente;
    			parent::store($object);
    		}
    	}
    	if ($object->_utenti){
    		foreach($object->_utenti as $item) {
    			$object->utente = $item;
    			parent::store($object);
    		}
    	}
    }
      
    
    /**
     * 
     * Controlla se utente partecipa ad un partita
     * @param int $id
     * @param string $nome
     * @returns {boolean}
     */
    public function partecipa($id,$nome){
    	$partecipanti = $this->search(array(array('id_partita','=',$id)));
    	if ($partecipanti){
    		foreach ($partecipanti as $item){
    			if ($item->utente == $nome){
    				$totale = true;
    				return true;
    			}
    		}	
    	}
    	return false;
    }
    
}