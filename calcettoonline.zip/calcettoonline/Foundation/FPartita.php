<?php
/**
 * @access public
 * @package Foundation
 */

class FPartita extends Fdb{
	/**
	 * 
	 * Costrisce la classe
	 */
    public function __construct() {
        $this->_table = 'partita';
        $this->_key = 'id';
        $this->_return_class = 'EPartita';
        $this->_auto_increment = true;
        USingleton::getInstance('Fdb');
    }
    
    
    /**
     * Salva una partiat sul db
     * @see Fdb::store()
     */
    public function store($object){
		$object->squadra1 = $object->_squadra1->nome;
        $object->squadra2 = $object->_squadra2->nome;
        $object->id_campo = $object->_campo->id;
        $object->username = $object->_username->nomeUtente;
        $id = parent::store($object);
        $object->id = $id;
        return $id;
        }

    /**
     * Dato l'id trova la partita corrispondete sul db 
     * e mette il risultato in un oggetto 
     * @see Fdb::load()
     */    
    public function load($key){
    	$campo = USingleton::getInstance('FCampo');
    	$squadra = USingleton::getInstance('FSquadra');
    	$utente = USingleton::getInstance('FUtente');
    	$partita = parent::load($key);
    	$partita->_squadra1 = $squadra->load($partita->squadra1);
    	$partita->_squadra2 = $squadra->load($partita->squadra2);
    	$partita->_campo = $campo->load($partita->id_campo);
    	$partita->_username = $utente->load($partita->username);
    	return $partita;
    }   
    
    /**
     * Aggiorna la stato di una partita
     * @see Fdb::update()
     */
    public function update($object){
    	$fsquadra = USingleton::getInstance('FSquadra');
        $fsquadra->update($object->_squadra1);
        $fsquadra->update($object->_squadra2);
    	$partita = parent::update($object);
    } 
    
    /**
     * 
     * Imposta una partita come disputata
     * @param EPartita $partita
     */
    public function disputata(EPartita $partita){
   		$partita->disputata = 1;
    	$this->update($partita);		
    }
    
    /**
     * Cerca una partita su db
     * @see Fdb::search() 
     */
	public function search($parametri = array(), $ordinamento = '', $limit = ''){
    	$risultato = parent::search($parametri, $ordinamento, $limit);
    	if ($risultato != null){
    		foreach ($risultato as $item){
    			$squadra = USingleton::getInstance('FSquadra');
    			$campo = USingleton::getInstance('FCampo');
    			$utente = USingleton::getInstance('FUtente');
    			$item->_squadra1 = $squadra->load($item->squadra1);
    			$item->_squadra2 = $squadra->load($item->squadra2); 
    			$item->_campo = $campo->load($item->id_campo);
    			$item->_username = $utente->load($item->username);
    		}
    		return $risultato;
    	}
    	else 
    		return false;
    }
        
    
}