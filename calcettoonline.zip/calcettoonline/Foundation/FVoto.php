<?php
/**
 * @access public
 * @package Foundation
 */

class FVoto extends Fdb{
	
	/**	 
	 * Costruisce la classe
	 */
    public function __construct() {
        $this->_table='voto';
        $this->_key='id';
        $this->_auto_increment = true;
        $this->_return_class='EVoto';
        USingleton::getInstance('Fdb');
    }
    
    /**
     * Salva un voto su db
     * @see Fdb::store()
     */
    public function store($object){
    	$object->mittente = $object->_mittente->nomeUtente;
    	if (is_object($object->_ricevente))
    		$object->ricevente = $object->_ricevente->nomeUtente;
    	else
    		$object->ricevente = $object->_ricevente;
    	$object->id_partita = $object->_partita->id;
    	$id = parent::store($object);
    	$object->id = $id;
    }
    
    /**
     * Dato l'id trova il voto corrispondente sul db 
     * e salva il risultato in un oggetto
     * @see Fdb::load()
     */
    public function load($id){
    	$futente = USingleton::getInstance('FUtente');
    	$fpartita = USingleton::getInstance('FPartita');
    	$voto = parent::load($id);
    	$voto->_mittente = $futente->load($voto->mittente);
    	$ricev = $futente->load($voto->ricevente);
    	if ($ricev != false)
    		$voto->_ricevente = $ricev;
    	else
    		$voto->_ricevente = $voto->ricevente;
    	$voto->_partita = $fpartita->load($voto->id_partita);
    	return $voto;
    }
    
    /**
     * Cerca un voto sul db
     * @see Fdb::search()
     */
    public function search($parametri = array(),$ordinamento = '',$limit=''){
    	$futente = USingleton::getInstance('FUtente');
    	$fpartita = USingleton::getInstance('FPartita');
    	$voti = parent::search($parametri,$ordinamento,$limit);
    	if ($voti != null){
    		foreach ($voti as $key => $item){
    			$item->_mittente = $futente->load($item->mittente);
    			$ricev = $futente->load($item->ricevente);
    			if ($ricev != false)
    				$item->_ricevente = $ricev;
    			else
    				$item->_ricevente = $item->ricevente;
    			$item->_partita = $fpartita->load($item->id_partita);
    		}
    		return $voti;
    	}
    	else
    		return false;
    }
}