<?php
/**
 * @access public
 * @package Foundation
 */
class FSquadra extends Fdb{
	
	/**
	 * 
	 * Costruisce la classe
	 */
    public function __construct() {
        $this->_table='squadra';
        $this->_key='nome';
        $this->_return_class='ESquadra';
        USingleton::getInstance('Fdb');
    }    
    
    /**
     * 
     * Controlla dato il nome se una squadra esiste sul db
     * @param string $nome
     */
    public function esisteSquadra($nome){
        $snome = $this->load($nome);
    	return $snome;
    }
    
   
}