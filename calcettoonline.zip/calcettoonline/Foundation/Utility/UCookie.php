<?php
/**
 * @access public
 * @package Foundation
 * @subpackage Utility
 */

class UCookie {
    public function  __construct() {
        //vuoto
    }

    /**
     * Setta un cookie
     */
    public function setCookie($cookie = 'cookieCheck',$value = 'activated', $path = '/'){
        setcookie($cookie,$value,0,$path);
    }

    /**
     * Controlla se il cookie "cookieCheck" è settato.
     * @return bool
     */
    public function checkCookie(){
        if(isset($_COOKIE['cookieCheck']))
            return true;
        else
            return false;
    }

    /**
     * Dato un nome, elimina il cookie con quel nome
     * @param string $cookie nome del cookie
     */
    public function eliminaCookie($cookie,$posizione = '/'){
        setcookie($cookie,"",time()-3600,$posizione);
    }
}
?>
