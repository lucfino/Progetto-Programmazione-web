<?php
/**
 * @access public
 * @package Foundation
 * @subpackage Utility
 */

class USession {
    
    /**
     * Il metodo, crea la sessione. Imposta la frequenza di passaggio del garbage collector
     * sul server a 1 passaggio ogni 20 richieste e il tempo di scadenza dei dati server a 1 ora
     */
    public function __construct() {
        ini_set('session.gc_divisor',0);
        ini_set('session.gc_maxlifetime',600);
        session_start();
    }

    /**
     * Dati chiave e valore, crea un indice nell'array $_SESSION
     * @param mixed $chiave
     * @param mixed $valore
     */
    function impostaValore($chiave,$valore) {
        $_SESSION[$chiave]=$valore;
    }

    /**
     * Dati chiave e valore, crea un indice nell'array $_SESSION
     * @param mixed $chiave
     * @param mixed $valore
     */
    function appendValoreArray($chiave,$valore) {
        $_SESSION[$chiave][]=$valore;
    }

    /**
     * Data la chiave di $_SESSION, se a questa corrisponde un array, allora
     * il valore passato viene eliminato dall'array
     * @param mixed $chiave
     * @param mixed $valore
     */
    function removeValoreArray($chiave,$valore) {
        foreach ($_SESSION[$chiave] as $key=>$value)
            if($value==$valore)
                unset($_SESSION[$chiave][$key]);
    }

    /**
     *Data la chiave, elimina tale valore dall'array $_SESSION
     * @param mixed $chiave
     */
    function cancellaValore($chiave) {
        unset($_SESSION[$chiave]);
    }

    /**
     *Data al chiave, legge il valore corrispondente e lo ritorna, oppure ritorna false
     * nel cason quella chiave non sia settata o sia null
     * @param mixed $chiave
     * @return mixed false se la chiave non esiste, mixed se la chiave esiste
     */
    function leggiValore($chiave) {
        if (isset($_SESSION[$chiave]))
            return $_SESSION[$chiave];
        else
            return false;
    }
    /**
     * Distrugge la sessione ed elimina il cookie per il controllo della sessione
     */
    function distruggiSessione(){
        $cookie = USingleton::getInstance('UCookie');
        $cookie->eliminaCookie('sessione');
        session_destroy();
        $cookie->eliminaCookie("PHPSESSID");
    }

    /**
     * Controlla se la sessione è attiva o scaduta
     * @return bool true se la sessione è attiva, false altrimenti
     */
    public function checkSessioneAttiva(){
        if($this->leggiValore('username') != false){
            if(!isset($_COOKIE['sessione'])){
                $cookie = USingleton::getInstance('UCookie');
                $cookie->setCookie('sessione','si');
            }
            return true;
        }
        if(isset($_COOKIE['sessione']))
           return false;
        else
           return true;        
    }
}
?>
