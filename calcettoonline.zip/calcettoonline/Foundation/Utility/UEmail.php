<?php
require("lib/phpmailer/class.phpmailer.php");
/**
 * @access public
 * @package Foundation
 * @subpackage Utility
 */

class UEmail {
    private $_mail;
    
    /**
     * Costruisce la classe
     */
    public function __construct() {
        global $config;
        $this->_mail = new PHPMailer();
        $this->_mail->IsSMTP();           
        $this->_mail->Host = $config['smtp']['host'];  
        $this->_mail->Port = $config['smtp']['port'];  
        $this->_mail->SMTPAuth = $config['smtp']['smtpauth']; 
        $this->_mail->Username = $config['smtp']['username']; 
        $this->_mail->Password = $config['smtp']['password']; 
        $this->_mail->Charset = 'utf-8';
    }
    /**
     * 
     * Invia l'email
     * @param string $email_destinatario
     * @param string $nome_destinatario
     * @param string $oggetto
     * @param string $corpo_email
     * @param string $corpo_email_testo_semplice
     * @param boolean $html
     */
    public function invia_email($email_destinatario, $nome_destinatario, $oggetto, $corpo_email, $corpo_email_testo_semplice = '', $html=false) {
        $this->_mail->AddAddress($email_destinatario, $nome_destinatario);
        $this->_mail->SetFrom('calcetto89@virgilio.it','Calcetto');
        $this->_mail->WordWrap = 50;                                 
        $this->_mail->IsHTML($html); // set email format to HTML
        $this->_mail->Subject = $oggetto;
        $this->_mail->Body    = $corpo_email;
        $this->_mail->AltBody = $corpo_email_testo_semplice;
		if(!$this->_mail->Send()) {
           
            return false;
        }
        return true;
    }
}
?>