<?php
/**
 * @access public
 * @package Foundation
 * @subpackage Utility
 */

class UControlli {

	/**
     * Controlla che il nome o il cognome, vengano scritti nella maniera corretta
     * @param string $nomCog nome o cognome
     * @return string
     */
    public function nomCog($nomCog){
    	$totale = NULL;
		if($nomCog == null)
        $totale = 'Devi inserire il nome e il cognome';
    	else{
        	$pattern = "/^([a-zA-Z]{1,}( |'){0,1}){1,}([a-zA-Z]{1,})$/";
        	if(preg_match($pattern, $nomCog) != 1){
        		$totale = "Controlla di aver inserito il nome e il cognome in modo corretto";
        	}
    	}
    	return $totale;
    }
    
 	/**
     * Controlla la correttezza sintattica del nome utente e ritorna un errore nel
     * caso venga fallito il controllo. Altrimenti ritorna NULL
     * @param string $user l'username
     * @param bool Il parametro deve essere passato come true, se si vuole saltare il controllo dell'esistenza nel db
     * @return string
     */
    public function username($user,$k = false){
        $totale = NULL;
		if($user == null)
            $totale = 'Devi inserire un nome utente';
        else{
            $pattern = "/^[0-9a-z]{5,15}$/";
            if(preg_match($pattern, $user) != 1){
                $totale = 'Il nome utente non pu&ograve; contenere caratteri speciali e devi rispettare le dimensioni richieste';
            }
            else{
                if($k==false){
                	$FUtente = USingleton::getInstance('FUtente');
                $param = array(array('nomeUtente','=',$user));
                $esiste = $FUtente->search($param);
                if($esiste != '')
                	$totale = "Il nome utente inserito è già presente nel database";}
            }
        }
        return $totale;
    }
    
    /**
     * Controlla che il comune venga scritto nella maniera corretta
     * @param string $comune comune
     * @return string
     */
	public function comune($comune){
        $totale = NULL;
		if($comune == null)
            $totale = 'Devi inserire il comune';
        else{
            $pattern = "/^([a-zA-Z]{1,}( |'){0,1}){1,}([a-zA-Z]{1,})$/";
            if(preg_match($pattern, $comune) != 1){
                $totale = "Controlla di aver inserito il comune in modo corretto";
            }
        }
        return $totale;
    }
    
    /**
     * Controlla che la mail sia nel formato giusto. Non effettua il controllo con
     * l'email di conferma
     * @param string $email
     * @return string
     */
    public function emailRichieste($email){
        $totale = NULL;
	if(!isset($email))
            $totale = 'Devi inserire una email';
        else{
            $pattern = "/^[0-9a-z_\.]+@+[a-z]+\.+[a-z0-9]{2,4}$/";
            if(preg_match($pattern, $email) != 1){
                $totale = "Controlla che il formato dell'email sia corretto";
                }
        }
        return $totale;
    }

	/**
     * Controlla che la password inserita sia sintatticamente corretta e che il campo
     * passsword e conferma password, contengano lo stesso valore
     * @param string $password la password
     * @param string $passwordC la conferma della password
     * @return string ritorna l'errore che si è verificato, oppure null
     */
    public function password($password,$passwordC){
        $totale = NULL;
		if($password==NULL)
            {$totale = 'Devi inserire una password';}
        else
            {if($passwordC==NULL)
                {$totale = 'Devi confermare la password';}
            else{
            $pattern = "/^[0-9a-zA-Z\*\@\_\-]{7,15}$/";
                if(preg_match($pattern, $password) != 1){
                    $totale = 'Alcuni caratteri inseriti nella password non sono consentiti';}
                else{
                    if($password != $passwordC){
                        $totale = 'I campi password e conferma password non coincidono';}
                }
            }
        }
        return $totale;
    }
     
	/**
     * Controlla che la email inserita sia sintatticamente corretta e che il campo
     * email e conferma email, contengano lo stesso valore
     * @param string $email la email
     * @param string $emailC la conferma della email
     * @return string ritorna l'errore che si è verificato, oppure null
     */
    public function email($email,$emailC,$k = false){
        $totale = NULL;
		if($email==null)
            $totale = 'Devi inserire una email';
        else
            if($emailC==null)
                $totale = 'Devi confermare la email';
        	else{
            	$pattern = "/^[0-9a-z_\.]+@+[a-z\.]+\.+[a-z]{2,4}$/";
            	if(preg_match($pattern, $email) != 1){
                	$totale = "Controlla che il formato dell'email sia corretto";
                }
            	else{
                	if($email != $emailC){
                    $totale = 'I campi email e conferma email non coincidono';
                	}
                    else{
                		if($k==false){
                    		 $FUtente = USingleton::getInstance('FUtente');
                   			 if($FUtente->search(array(array('email','=',$email))) != null)
                        		$totale = "L'email inserita è già stata utilizzata da un altro utente";}
                	} 
            	}	
        	}
        return $totale;
    }
    
    /**
     * Controlla che il nome della partita venga scritto nella maniera corretta
     * @param string $nomP 
     * @return string
     */
    public function nomP($nomP){
        $totale = NULL;
	    if($nomP == '')
            $totale = 'Devi inserire il nome della partita';
        else{
            $pattern = "/^[a-zA-Z0-9]{1,}$/";
            if(preg_match($pattern, $nomP) != 1){
                $totale = "Controlla di aver inserito il nome della partita in modo corretto";
            }
        }
        return $totale;
    }
    
 	/**
     * Controlla che il nome del campo venga scritto nella maniera corretta
     * @param string $nomC 
     * @return string
     */
    public function nomC($nomC){
        $totale = NULL;
        $indice= '-campo-';
		if($nomC == $indice)
            $totale = 'Devi inserire il nome della campo';
        else{
            $campo=USingleton::getInstance('FCampo');
            $tmp=$campo->search(array (array('nome','=',$nomC)));
            if($tmp == ''){
                $totale = "Controlla di aver inserito il nome del campo in modo corretto";
            }
        }
        return $totale;
    }

/**
     * Controlla che il nome del campo venga scritto nella maniera corretta
     * @param string $nomP 
     * @return string
     */
    public function nomeCampo($nomP,$modifica=false){
        $totale = NULL;
	    if($nomP == ''){
            $totale = 'Devi inserire il nome del campo';
	    }
        else{
            $pattern = "/^([a-zA-Z0-9]{1,}( |'){0,1}){1,}([a-zA-Z0-9]{1,})$/";
            if(preg_match($pattern, $nomP) != 1){
                $totale = "Controlla di aver inserito il nome del campo in modo corretto";
            }
            if (!$modifica){
    			$campo=USingleton::getInstance('FCampo');
        		$tmp=$campo->search(array (array('nome','=',$nomP)));
        		if($tmp != false){
           			$totale = "Il nome del campo &egrave; gi&agrave; presente nel database";
        		}
            }
        }
        return $totale;
    }
    
    
	/**
     * Controlla che il nome delle squadre venga scritto nella maniera corretta
     * @param string $nomS
     * @return string
     */
    public function nomS($nomS){
        
        $totale = NULL;
		if($nomS != ''){
            $pattern = "/^([a-zA-Z0-9]{1,}( |'){0,1}){1,}([a-zA-Z0-9]{1,})$/";
            if(preg_match($pattern, $nomS) != 1){
                $totale = "Controlla di aver inserito il nome del squadra in modo corretto";
            }
        }
        else $totale = 'Devi inserire il nome della squadra';
        return $totale;
    }
    
    /**
     * Controlla che il sesso sia stato inserito
     * @param enum $sesso
     * @return string
     */
    public function sesso($sesso){
        $totale = NULL;
		if($sesso != ''){
        	if($sesso != 'm' && $sesso != 'f'){
                $totale = "Si è verificato un errore durante l'invio del campo sesso.
                                                        Aggiorna la pagina e riprova";
        	}
		}
        else $totale = 'Devi inserire il sesso';
        return $totale;
    }
    
   
    /**
     * Controlla che la data inserita sia corretta e sia stata inserita
     * @param int $giorno
     * @param int $mese
     * @param int $anno
     * @param int $maxAnno
     * @return string
     */
    public function data($giorno,$mese,$anno){
        $totale=NULL;
        if($giorno != '-giorno-' && $mese != 0 && $anno != '-anno-'){
        	if($mese == 2){
        		$bisestile = UTime::getBisestile($anno);
        		if (!$bisestile){
        			if ($giorno>28) $totale= "Febbraio ha al massimo 28 giorni nell'anno ".$anno;
        		}
        		else{
        			if ($giorno>29) $totale= "Febbraio ha al massimo 29 giorni nell'anno ".$anno;
        		}             
            }
            else{
            	if(($mese == 4 || $mese == 6 || $mese == 9 || $mese == 11) && ($giorno > 30)){
                	$totale = "Il mese ".$mese." pu� avere al massimo 30 giorni";
            	}
            }
        }
        else $totale="Devi inserire tutti i campi della data";
        return $totale;
    }

    /**
     * Controlla che la data che arriva al server sia maggiore della data attuale
     * @param array $dati
     * @return string
     */
    public function isMaggioreDataAttuale($dati){
        $oggi = getdate();
        if(isset($dati['giorno']) && isset($dati['mese']) && isset($dati['anno']) &&
                isset($dati['ore']) && isset($dati['minuti'])){
        $dataP = $dati['giorno'].'-';
        $dataP .= $dati['mese'].'-';
        $dataP .= $dati['anno'].' ';
        $dataP .= $dati['ore'].':';
        $dataP .= $dati['minuti'].':00';
        $dataP = strtotime($dataP);
        if($dataP < $oggi[0])
            return 'La data della partita deve essere maggiore della data attuale';}
        else return;
    }

    /**
     * Controlla che un'ora sia scritta nel formato giusto (2 cifre o 0)
     * @param int $ora
     * @param int $minuto
     * @return string
     */
    public function ora($ora,$minuto){
        $totale = NULL;
        if ($ora != '-ore-' && $minuto != '-minuti-'){
        	$pattern = "/^[0-9]{0,2}$/";
        	if($ora > 23 || $minuto>59){
            	$totale = "Orario non esatto";
        	}
        	if((preg_match($pattern, $ora) != 1) || (preg_match($pattern, $minuto) != 1)){
                $totale = "orario non esatto 2";
        	}
        }
        else $totale="Controlla di aver inserito l'ora correttamente";
        return $totale;
    }

    /**
     * Controlla che un testo non sia + lungo di 300 caratteri
     * @param string $testo
     * @return string
     */
    public function testo($testo){
        $totale = NULL;
        $pattern = "/^.{0,300}$/";
        if((preg_match($pattern, $testo) != 1)){
                            $totale = "Puoi inserire massimo 300 caretteri.";}
        return $totale;
    }

    /**
     * Controlla che un commento non sia + lungo di 55 caratteri
     * @param string $testo
     * @return string
     */
    public function commento($testo){
        $totale = NULL;
        $pattern = "/^.{0,55}$/";
        if((preg_match($pattern, $testo) != 1)){
                            $totale = "Puoi inserire massimo 55 caretteri.";}
        return $totale;
    }
    
    /**
     * Controlla che gol sia un numero di massimo due cifre
     * @param int $gol
     * @return string
     */
    public function gol($gol){
    	$totale = NULL;
    	$pattern = "/^[0-9]{0,2}$/";
    	if((preg_match($pattern, $gol) != 1)){
                            $totale = "Puoi inserire solo numeri compresi tra 0 e 99";}
        return $totale;
    }
    
    /**
     * 
     * Controlla che un voto sia scritto in modo corretto
     * @param int $voto
     * @return string
     */
    public function voto($voto){
    	$totale = NULL;
    	$pattern = "/^([0-9]|10)$|^(([0-9]|10)*\.([0-9]))$/";
    	if((preg_match($pattern, $voto) != 1)){
                            $totale = "Puoi inserire solo numeri compresi tra 0 e 10";}
        return $totale;
    }

   
}

?>
