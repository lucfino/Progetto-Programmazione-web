<?php
/**
 * @access public
 * @package Foundation
 * @subpackage Utility
 */

class UTime {

    /**
     * Il costruttore è dichiarato privato per evitare che si possa istaziare
     * un oggetto di tipo UTime
     */
    private function  __construct() {
        
    }

    /**
     *
     * @return array ritorna l'array con i nomi dei mesi
     */
    public static function getMesi(){
        return array('-mese-','Gennaio','Febbraio','Marzo','Aprile',
                                'Maggio','Giugno','Luglio','Agosto','Settembre',
                                'Ottobre','Novembre','Dicembre');
    }

    /**
     *
     * @return array ritorna un array con i giorni del mese
     */
    public static function getGiorni(){
        return array ('-giorno-','01','02','03','04','05','06','07','08','09','10','11','12','13','14',
        				'15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31');
    }

    /**
     *
     * @return int ritorna un array di 100 ore
     */
    public static function getOre(){
        $ore[NULL] = '-ore-';
        for($i=0;$i<100;$i++)
            $ore[]=$i;
        return $ore;
    }

    /**
     *
     * @return int ritorna un array di 59 minuti
     */
    public static function getMinuti(){
        return array (null=>'-minuti-','00','15','30','45');
    }

    /**
     *
     * @return array ritorna l'array delle ore da 0 a 24
     */
    public static function getOreOrari(){
        return array (null=>'-ore-','00','01','02','03','04','05','06','07','08','09','10','11','12',
        				'13','14','15','16','17','18','19','20','21','22','23');
    }


    /**
     * Restituisce un array contenente un intervallo di anni in funzione alla variabile
     * $tipo. Il contenuto dell'array è differente in base a come viene utilizzato.
     * Ad esempio, l'array necessario al modulo di ricerca, sarà differente da quello
     * utilizzato dal modulo di registrazione.
     * @param string $tipo indica il tipo di array che si vuole ottenere
     * @return array ritorna un array di numeri (gli anni). Questo array dipende dal tipo
     */
    public static function getAnni($tipo){
        $y= getdate();
        $y = $y['year'];
        $start;$end;
        $anno = array('0'=>'-anno-');
        switch ($tipo){
            case 'nascita':
               for($i=$y-18;$i>=$y-100;$i--){
                    $anno["$i"] = $i;
               }
               break;
           case 'ricerca':
               for($i=$y;$i<=$y+2;$i++){
                    $anno["$i"] = $i;}
                break;
           }
        return $anno;
    }

    /**
     * Ritorna true se l'anno è bisestile, false nel caso contrario
     * @param int $anno
     * @return bool
     */
    public static function getBisestile($anno){
    if(($anno % 100) == 0 && ($anno % 400) == 0){
        return true;}
    if(($anno % 100) != 0 && ($anno % 4) == 0){
        return true;}
    else return false;
	}

}
?>
