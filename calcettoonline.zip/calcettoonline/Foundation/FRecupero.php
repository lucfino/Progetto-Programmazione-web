<?php
/**
 * @access public
 * @package Foundation
 */

class FRecupero extends Fdb{
    
	/**
	 * 
	 * Costruisce la classe
	 */
    public function  __construct() {
        global $config;
        $this->_table='recupero';
        $this->_key='email';
        $this->_return_class='ERecupero';
        USingleton::getInstance('Fdb');
    }
}
?>
