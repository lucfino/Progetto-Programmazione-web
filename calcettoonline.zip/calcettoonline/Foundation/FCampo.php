<?php
/**
 * @access public
 * @package Foundation
 */

class FCampo extends Fdb{
	
	/**
     * Costruisce la classe
     */
    public function __construct() {
        $this->_table='campo';
        $this->_key='id';
        $this->_return_class='ECampo';
        USingleton::getInstance('Fdb');
    }

    /**
     * Salva un oggetto campo sul db
     * @see Fdb::store()
     */
    public function store( $object){
        $id = parent::store($object);
        $object->id=$id;
          
    }

    /**
     * Dato il nome trova il campo corrispondete sul db 
     * e mette il risultato in un oggetto 
     * @param $nome nom del campo
     * @return ECampo $tmp
     */
    public function getCampoByName($nome){
    	$nomec = array(array('nome','=',$nome));
        $tmp = $this->search($nomec);
        return $tmp;
    }
    
    
}

?>