<?php
/**
 * @access public
 * @package Foundation
 */

class FUtente extends Fdb{
	
	/**
	 * 
	 * Costruisce la classe
	 */
    public function __construct() {
        $this->_table='utente';
        $this->_key='nomeUtente';
        $this->_return_class='EUtente';
        USingleton::getInstance('Fdb');
    }
    
    /**
     * 
     * Aggiorna il numero di gol fatti da un utente
     * @param EUtente $utente
     * @param int $gol
     */
    public function aggiornaGol(EUtente $utente,$gol){
    	$utente->giocate += 1;
    	$utente->gol += $gol;
    	$media = ($utente->gol)/($utente->giocate);
    	$mediaGol = number_format($media,2);
    	$utente->mediaGol = $mediaGol;
    	$this->update($utente);
    	
    }
    
    /**
     * 
     * Controlla dato lo username se esiste un utente sul db
     * @param string $user
     */
    public function esisteUtente($user){
    	$esito = true;
    	$utente = $this->load($user);
    	return $utente;
    }
    
    
}