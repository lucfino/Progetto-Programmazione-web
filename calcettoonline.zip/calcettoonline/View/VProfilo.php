<?php
 /**
 * @access public
 * @package View
 */
class VProfilo extends View {
    /**
     * Ritorna il contenuto del template che si vuole visualizzare
     * @param string $content
     * @return string
     */
    public function getContenuto($content){
        $contenuto = $this->fetch('profilo_'.$content.'.tpl');
        return $contenuto;
    }
    
    /**
     * 
     * Grazie a questa funzione
     * all'interno della variabile $dati vengono registrati tutti i dati inviati tramite
     * POST relativi al profilo utente
     * @return array $dati
     */
    public function getDati(){
        $dati_reg = array('nomeu','cognome','sesso','giorno','mese','anno','residenza',
        'password','Cpassword','email','Cemail','nomeUtente');
        $dati=array();
        foreach ($dati_reg as $dato) {
            if (isset($_REQUEST[$dato]))
                $dati[$dato]=$_REQUEST[$dato];
        }
        $dati['dataN'] = $_REQUEST['anno'].'-'.$_REQUEST['mese'].'-'.$_REQUEST['giorno'];
        return $dati;   
    }
    
    /**
     * 
     * Assegna ai campi del template corrispondente i valori dell'array $dati
     * @param array $dati
     */
	public function assegnaDatiModifica($dati){
    	$this->assign('username',$dati['nomeUtente']);
    	$this->assign('nome_utente',$dati['nomeu']);
    	$this->assign('cognome_utente',$dati['cognome']);
    	$this->assign('comune_utente',$dati['residenza']);
    	$this->assign('email',$dati['email']);
    }
}
 

    
