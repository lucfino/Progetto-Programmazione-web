<?php

/**
 * @access public
 * @package View
 */
class VCerca extends View {
    /**
     * Ritorna il contenuto del template che si vuole visualizzare
     * @param string $mainCont
     * @param string $sideCont
     * @return string
     */
    public function getContenuto($content){
        $contenuto = $this->fetch('partite_'.$content.'.tpl');
        return $contenuto;
    }
    
    /**
     * 
     * Assegna a smarty i valori del riepilogo della partita passata come parametro
     * @param EPartita $nomepartita
     */
	public function assegnaDatiRiepilogo($nomepartita){
		$this->assign('creatore',$nomepartita->username);
    	$this->assign('nome_partita',$nomepartita->nomep);
        $this->assign('data_partita',$nomepartita->datap);
        $this->assign('ora_partita',$nomepartita->orap);
        $this->assign('campo_partita',$nomepartita->_campo->nome);
        $this->assign('note_partita',$nomepartita->note);
        $this->assign('squadra1',$nomepartita->_squadra1->nome);
        $this->assign('squadra2',$nomepartita->_squadra2->nome);
        }

    /**
      * 
      * Grazie a questa funzione all'interno della variabile $dati 
      * vengono registrati tutti i dati inviati tramite
      * POST nei campi dei partecipanti della prima squadra
      * 
      * @return array
      */       
    public function getDatiCompila1(){
    	$dati_reg = array('part1','part2','part3','part4','part5');
    	
        $dati=array();
        foreach ($dati_reg as $dato) {
            if (isset($_REQUEST[$dato]))
                $dati[$dato]=$_REQUEST[$dato];
        }
        return $dati;
    }
    
    /**
     * 
     * Grazie a questa funzione all'interno della variabile $dati 
     * vengono registrati tutti i dati inviati tramite
     * POST nei campi dei partecipanti della seconda squadra
     *  
     * @return array
     * 
     */
    public function getDatiCompila2(){
    	$dati_reg = array('part6','part7','part8','part9','part10');
    	
        $dati=array();
        foreach ($dati_reg as $dato) {
            if (isset($_REQUEST[$dato]))
                $dati[$dato]=$_REQUEST[$dato];
        }
        return $dati;
    }
            
    /**
     * 
     * Grazie a questa funzione all'interno della variabile $dati 
     * vengono registrati tutti i dati inviati tramite
     * POST nei campi dei goal
     */   
    public function getDatiCompila3(){
    	$dati_reg = array('1','2','3','4','5','6',
    	'7','8','9','10');
    	
        $dati=array();
        foreach ($dati_reg as $dato) {
            if (isset($_REQUEST[$dato]))
                $dati[$dato]=$_REQUEST[$dato];
        }
        return $dati;
    }
    
    /**
     * 
     * Ritorna il risultato della partita attraverso i gol segnati da ciascuna squadra
     * 
     * @param array $dati
     * @return string
     */
    public function getRisultato($dati){
    	$gol1 = $dati['1'] + $dati['2'] + $dati['3'] + $dati['4'] + $dati['5'];
    	$gol2 = $dati['6'] + $dati['7'] + $dati['8'] + $dati['9'] + $dati['10'];
    	$risultato = $gol1.'-'.$gol2;
    	return $risultato;
    }
    
    /**
     * 
     * Grazie a questa funzione all'interno della variabile $dati 
     * vengono registrati tutti i dati inviati tramite
     * POST nei campi dei partecipanti alla partita
     */
 	public function getDatiCompila4(){
    	$dati_reg = array('part1','part2','part3','part4','part5',
    	'part6','part7','part8','part9','part10');
    	
        $dati=array();
        foreach ($dati_reg as $dato) {
            if (isset($_REQUEST[$dato]))
                $dati[$dato]=$_REQUEST[$dato];
        }
        return $dati;
    }
        
    
}




?>