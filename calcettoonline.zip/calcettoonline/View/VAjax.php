<?php
/**
 * @access public
 * @package View
 */


class VAjax extends View {
    
	/**
	 * 
	 * Costruisce la classe
	 */
    public function  __construct() {
        parent::__construct();
        $this->nomeClasse = 'ajax';
    }
}
?>
