<?php

/**
 * @access public
 * @package View
 */
class VRegistrazione extends View {
    
    /**
     * Ritorna il contenuto del template che si vuole visualizzare 
     * @param string $content
     * @return string
     */
    public function getContenuto($content){
        $contenuto = $this->fetch('registrazione_'.$content.'.tpl');
        return $contenuto;
    }
    
	/**
     * L'array "statico" porta i nomi dei campi del db. Grazie a questa funzione
     * all'interno della variabile $dati vengono registrati tutti i dati inviati tramite
     * POST dal modulo di registrazione
     * @return array
     */
    public function getDatiRegistrazione(){
        $dati_reg = array('nomeu','cognome','sesso','giorno','mese','anno','residenza',
        'nomeUtente','password','Cpassword','email','Cemail','dataN');
        $dati=array();
        foreach ($dati_reg as $dato) {
            if (isset($_REQUEST[$dato]))
                $dati[$dato]=$_REQUEST[$dato];
        }
        return $dati;
    }
    
    /**
     * 
     * Assegna a smarty i dati della registrazione passati come parametro
     * @param array $dati
     * @param int $data
     */
    public function assegnaDatiRegistrazione($dati,$data = 0){
    	$this->assign('username',$dati['nomeUtente']);
    	$this->assign('nome_utente',$dati['nomeu']);
    	$this->assign('cognome_utente',$dati['cognome']);
    	$this->assign('sesso_utente',$dati['sesso']);
    	$this->assign('comune_utente',$dati['residenza']);
    	if ($data == 0){
    		$datau = $dati['anno'].'-'.$dati['mese'].'-'.$dati['giorno'];
    		$this->assign('data_utente',$datau);
    	}
    	$this->assign('email',$dati['email']);
    	$this->assign('password',md5($dati['password']));
    }
    
    /**
     * 
     * Assegna a smarty i valori della registrazione dell'utente passati come parametro
     * @param EUtente $nomepartita
     */
    public function assegnaDatiOggetto($utente){
    	$this->assign('username',$utente->nomeUtente);
    	$this->assign('nome_utente',$utente->nomeu);
    	$this->assign('cognome_utente',$utente->cognome);
    	$this->assign('sesso_utente',$utente->sesso);
    	$this->assign('comune_utente',$utente->residenza);
    	$this->assign('data_utente',$utente->dataN);
    	$this->assign('email',$utente->email);
    	$this->assign('codiceAttivazione',$utente->getCodiceAttivazione());
    	$this->assign('password',$utente->password);
    }
}