<?php
/**
 * @access public
 * @package View
 */

require('lib/smarty/smarty.class.php');

class View extends Smarty {

    /**
     * 
     * Costruttore della classe
     */  
    public function __construct() {
        global $config;
        $this->Smarty();    //Non è un costruttore
        $this->template_dir = $config['smarty']['template_dir'];  //L'insieme di queste assegnazioni
        $this->compile_dir = $config['smarty']['compile_dir'];    //serve all'oggetto Smarty per
        $this->config_dir = $config['smarty']['config_dir'];      //conoscere la posizione di alcune
        $this->cache_dir = $config['smarty']['cache_dir'];        //cartelle usate dal programma
        $this->caching = false;
       
    }
     

    /**
     * Questa funzione, restituisce il task inviato all'interno del vettore
     * superglobale $_REQUEST
     */
    public function getTask(){          
        if(isset($_REQUEST['task'])){   
            return $_REQUEST['task'];   
        }
    }
    
    /**
     * Questa funzione ritorna il valore  relativo all'indice passato relativo al
     * vettore $_REQUEST
     * @param $indice l'indice che si vuole ottenere da $_REQUEST
     */
    public function getRequest($indice){
        if(isset($_REQUEST[$indice])){
            return $_REQUEST[$indice];
        }
    }


    /**
     * impostra il controller a un certo valore
     * @param string $controller
     */
    public function setController($controller){
        $_REQUEST['controller'] = $controller;
    }

    public function setRequest($chiave,$valore){
        $_REQUEST[$chiave] = $valore;
    }

    /**
     * impostra il task a un certo valore
     * @param string $task
     */
    public function setTask($task){
        $_REQUEST['task'] = $task;
    }

    /**
     * 
     * Elimina il contenuto di $_REQUEST
     * 
     */
    public function unsetRequest(){
        unset($_REQUEST);
    }
    
	/**
     * Il metodo assegna ai link l'url, del sito (differenziando http da https)
     * @global mixed $config
     */
    public function impostaUrl(){
        global $config;
        if (file_exists('includes/config.inc.php')){
        	$this->assign('url', $config['url']['http']);
        	$this->assign('urls', $config['url']['https']);
        }
    }
    
	/**
     * Il metodo, serve per assegnare alle variabili del tpl Smarty, gli array calcolati
     * tramite i metodi di UTime (DATE).
     * @param string $type serve per selezionare il tipo di anni richiesti
     * @param string $day nome della variabile smarty alla quale assegnare i giorni
     * @param string $month nome della variabile smarty alla quale assegnare il mese
     * @param string $year nome della variabile smarty alla quale assegnare l'anno
     */
    public function impostaDate($type,$day = 'giornoNascita',$month = 'meseNascita',$year = 'annoNascita'){
        $anni = UTime::getAnni($type);
        $mesi = UTime::getMesi();
        $giorni = UTime::getGiorni();
        $this->assign('day',$giorni);
        $this->assign('month',$mesi);
        $this->assign('year',$anni);
    }
    
    
	/**
     * Il metodo, serve per assegnare alle variabili del tpl Smarty, l'array dei campi.
     * @param string $campi nome della variabile smarty alla quale assegnare i campi
     */
    public function impostaCampi($campi){
    	$this->assign('campi',$campi);
        }
     
    /**
     * Il metodo, serve per assegnare alle variabili del tpl Smarty, gli array calcolati
     * tramite i metodi di UTime (ORA).
     */
    public function impostaOra(){
        $ore = UTime::getOreOrari();
        $minuti = UTime::getMinuti();
        $this->assign('ore',$ore);
        $this->assign('minuti',$minuti);
    }
    
   /**
     * @return string $contenuto contiene il fisultato del fetch dei template main
     * di errore
     */
    public function getErrore(){
        $this->impostaUrl();
        $contenuto = $this->fetch('admin_main_errore.tpl');
        return $contenuto;
    }

    /**
     * Ritorna i template in caso di operazione andata a buon fine
     * @return string
     */
    public function getSuccesso(){
    	$this->impostaUrl();
        $contenuto = $this->fetch('admin_main_successo.tpl');
        return $contenuto;
    }
    
   /** 
     * Assegna gli errori ad visualzzare nella home. Esiste il default
     * @param string $errore la stringa che descrive l'errore
     * @param bool $back un booleano, se posto a false, fa' sì che non compaia il link per tornare alla homepage
     */
    public function impostaAccessoNegato($errore = "Errore!",$back = true){
        $view = USingleton::getInstance('VHome');
        $view->assign('errori', $errore);
        $view->assign('back',$back);
        }

   /**
    * Assegna il messaggio di successo nella home
    * @param string $successo
    * @param bool $back
    */
   public function impostaSuccesso($successo = "Complimenti! L'operazione è avvenuta con successo!",$back = true){
       $view = USingleton::getInstance('VHome');
       $view->assign('back',$back);
       $view->assign('successo', $successo);
    }
}

?>
