<?php

/**
 * Classe VInstalla
 * @package View
 */

class VInstalla extends View {
    
   /**
     * Ritorna il contenuto del template che si vuole visualizzare
     * @param string $mainCont
     * @return string
     */
    public function getContenuto($mainCont){
        $contenuto = $this->fetch('installazione_'.$mainCont.'.tpl');
        return $contenuto;
    }
    
        
    /**
     * @return array $contenuto contiene il Risultato del fetch dei template main
     * di errore
     */
    public function getErrore(){
        $this->impostaUrl();
        $contenuto = $this->fetch('errore_main.tpl');
        return $contenuto;
    }

    /**
     * Ritorna i template in caso di operazione andata a buon fine
     * @return array
     */
    public function getSuccesso(){
    	$this->impostaUrl();
        $contenuto = $this->fetch('successo_main.tpl');
        return $contenuto;
    }
    
/**
     * 
     * Assegna gli errori ad visualzzare nella home. Esiste il default
     * @param string $errore la stringa che descrive l'errore
     * @param bool $back un booleano, se posto a false, fa' sì che non compaia il link per tornare alla homepage
     */
    public function impostaAccessoNegato($errore='Errore!',$back = true){
        $this->assign('errori', $errore);
        $this->assign('back',$back);
    }

   /** 
    * Assegna il messaggio di successo nella home
    * @param string $successo
    * @param bool $back
    */
   public function impostaSuccesso($successo = "Complimenti! L'operazione è avvenuta con successo!",$back = true){
       $this->assign('back',$back);
       $this->assign('successo', $successo);
   }
 
} 

?>