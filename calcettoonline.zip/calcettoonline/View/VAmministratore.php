<?php
/**
 * @access public
 * @package View
 */

class VAmministratore extends View{
    
    /**
     * Ritorna il contenuto del template che si vuole visualizzare 
     * @param string $mainCont
     * @return string
     *
     */
    public function getContenuto($mainCont){
        $this->impostaUrl();
        $contenuto = $this->fetch('admin_main_'.$mainCont.'.tpl');
        return $contenuto;
    }
    
    /**
     * 
     * Assegna alla select i nomi delle tabelle 
     */
    public function assegnaTabelle(){
    	global $config;
    	$tab[] = '-tabella-';
    	$tab[] = $config['tabelle']['utente'];
        $tab[] = $config['tabelle']['squadra'];
        $tab[] = $config['tabelle']['partita'];
        $tab[] = $config['tabelle']['voto'];
        $tab[] = $config['tabelle']['campo']; 
        $this->assign('tabelle',$tab);
    }
    
   /**
     * @return array $contenuto contiene il fisultato del fetch dei template main
     * di errore
     */
    public function getErrore(){
        $this->impostaUrl();
        $contenuto = $this->fetch('admin_main_errore.tpl');
        return $contenuto;
    }

    /**
     * Ritorna i template in caso di operazione andata a buon fine
     * @return string
     */
    public function getSuccesso(){
    	$this->impostaUrl();
        $contenuto = $this->fetch('admin_main_successo.tpl');
        return $contenuto;
    }
    
   /** 
     * Assegna gli errori ad visualzzare nella home. Esiste il default
     * @param string $errore la stringa che descrive l'errore
     * @param bool $back un booleano, se posto a false, fa' sì che non compaia il link per tornare alla homepage
     */
    public function impostaAccessoNegato($errore = "Errore!",$back = true){
        $view = USingleton::getInstance('VHome');
        $view->assign('errori', $errore);
        $view->assign('back',$back);
        }

   /**
    * Assegna il messaggio di successo nella home
    * @param string $successo
    * @param bool $back
    */
   public function impostaSuccesso($successo = "Complimenti! L'operazione è avvenuta con successo!",$back = true){
       $view = USingleton::getInstance('VHome');
       $view->assign('back',$back);
       $view->assign('successo', $successo);
    }
}