<?php

/**
 * @access public
 * @package View
 */
class VVoti extends View {
	
	/**
	 * 
	 * Grazie a questa funzione all'interno della variabile $dati 
	 * vengono registrati tutti i dati inviati tramite POST dal modulo dei voti
     * @return array $dati
	 */
	public function getDatiCommento(){
		$dati[] = $this->getRequest('user1'); 
		$dati[] = $this->getRequest('voto1');
		$dati[] = $this->getRequest('testo1');
		$dati[] = $this->getRequest('idp');
		return $dati;
	}
	
	/**
	 * 
	 * 
     * Ritorna il contenuto del template che si vuole visualizzare (sottoforma di un
     * array formato da main e side content)
     * @param string $content
     * @return string
     */
	public function getContenuto($content){
		$contenuto = $this->fetch('voti_'.$content.'.tpl');
        return $contenuto;
	}
	
	/**
	 * Assegna ai campi corrsipondenti del tpl i valori dell'array $dati
	 * @param array $dati
	 */
	public function assegnaCommento($dati){
		$this->assign('user1',$dati[0]);
		$this->assign('voto1',$dati[1]);
		$this->assign('testo1',$dati[2]);
		$this->assign('idp',$dati[3]);
	}
}