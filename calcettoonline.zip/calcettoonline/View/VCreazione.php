<?php

/**
 * @access public
 * @package View
 */
class VCreazione extends View {
    
    /**
     * Ritorna il contenuto del template che si vuole visualizzare 
     * @param string $mainCont
     * @param string $sideCont
     * @return string
     */
    public function getContenuto($content){
        $contenuto = $this->fetch('creazione_'.$content.'.tpl');
        return $contenuto;
    }
    
/**
     * L'array "statico" porta i nomi dei campi del db. Grazie a questa funzione
     * all'interno della variabile $dati vengono registrati tutti i dati inviati tramite
     * POST dal modulo di registrazione
     * @return array
     */
    public function getDatiRegistrazione(){
        $dati_reg = array('id','nomep','_campo','giorno','mese','anno','risultato',
        'note','disputata','_squadra1','_squadra2','ore','minuti','datap','orap');
        $dati=array();
        foreach ($dati_reg as $dato) {
            if (isset($_REQUEST[$dato]))
                $dati[$dato]=$_REQUEST[$dato];
        }
        return $dati;
    }
    
   /**
     * L'array "statico" porta i nomi dei campi del db. Grazie a questa funzione
     * all'interno della variabile $dati vengono registrati tutti i dati inviati tramite
     * POST dal modulo di registrazione
     * @return array
     */
    public function getDatiEmail(){
        $dati_reg = array('giocatore1','giocatore2','giocatore3','giocatore4','giocatore5',
        'giocatore6','giocatore7','giocatore8','giocatore9','giocatore10','giocatore11',
        'giocatore12','giocatore13','giocatore14','giocatore15','giocatore16', 'idp');
        $dati=array();
        foreach ($dati_reg as $dato) {
            if (isset($_REQUEST[$dato]))
                $dati[$dato]=$_REQUEST[$dato];
        }
        return $dati;
    }
    
    /**
     * 
     * Assegna a smarty i valori del riepilogo della partita passata come parametro
     * @param array $nomepartita
     * @param boolean $time
     */
    public function assegnaDatiRiepilogo($nomepartita,$time = true){
    	$this->assign('nome_partita',$nomepartita['nomep']);
    	if ($time){
    		$orap = $nomepartita['ore'].':'.$nomepartita['minuti'];
    		$datap = $nomepartita['anno'].'-'.$nomepartita['mese'].'-'.$nomepartita['giorno'];
    		$this->assign('data_partita',$datap);
        	$this->assign('ora_partita',$orap);
    	}
        $this->assign('campo_partita',$nomepartita['_campo']);
        $this->assign('note_partita',$nomepartita['note']);
        $this->assign('squadra1',$nomepartita['_squadra1']);
        $this->assign('squadra2',$nomepartita['_squadra2']);
    }
    
    /**
     * 
     * Assegna a smarty i valori del riepilogo della partita passata come parametro
     * @param EPartite $nomepartita
     */
	public function assegnaDatiOggetto($nomepartita){
    	$this->assign('nome_partita',$nomepartita->nomep);
        $this->assign('data_partita',$nomepartita->datap);
        $this->assign('ora_partita',$nomepartita->orap);
        $this->assign('campo_partita',$nomepartita->_campo->nome);
        $this->assign('note_partita',$nomepartita->note);
        $this->assign('squadra1',$nomepartita->_squadra1->nome);
        $this->assign('squadra2',$nomepartita->_squadra2->nome);
        $this->assign('creatore',$nomepartita->_username->nomeUtente);
        $this->assign('idp',$nomepartita->id);
    }

    
    
}

?>