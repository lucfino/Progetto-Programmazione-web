<?php
/**
 * @access public
 * @package View
 */
class VClassifiche extends View {
	
	/**
	 * 
	 * Ritorna il contenuto del template che si vuole visualizzare
     * @param string $content
     * @return string
	 */
	public function getContenuto($content){
        $contenuto = $this->fetch('classifica_'.$content.'.tpl');
        return $contenuto;
    }
}