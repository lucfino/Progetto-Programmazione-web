<?php

/**
 * Classe VHome, estende la classe view e gestisce la visualizzazione e formattazione del sito, inoltre imposta i principali contenuti della pagina, suddivisi in contenuti principali (main_content) e contenuti della barra laterale (side_content)
 *
 * @package View
 */
class VHome extends View {
    
    /**
     * @var string $_main_content
     */
    private $mainContent;
    
    public function getController(){
    if(isset($_REQUEST['controller'])){
            return $_REQUEST['controller'];
        }
    }
       
    /**
     * imposta il contenuto principale alla variabile privata della classe
     */
    public function impostaContenuto($contenuto) {
        $this->mainContent=$contenuto;
    }
    
    
   /**
     * Ritorna il contenuto del template che si vuole visualizzare
     * @param string $mainCont
     * @return string
     */
    public function getContenuto($mainCont = 'default'){
        $contenuto = $this->fetch('home_main_'.$mainCont.'.tpl');
        return $contenuto;
    }
    
    /**
     * Scrive nel tpl gli attributi della classe
     */
    public function inserisciContenuto(){
        $this->assign('content',$this->mainContent);
    }
    
    /**
     * 
     * Mostra il tamplete di home_dafault
     */
    public function mostraPagina(){
    	$this->display('home_default.tpl');
    }
    
   /**
     * Fa' il fetch del menu che si vuole visualizzare (registrato o ospite per esempio).
     * @param string $tipo
     */
    public function impostaMenu($tipo){
        $cont = $this->fetch('sidebar_'.$tipo.'.tpl');
        $this->assign('sidebar', $cont);
    }
    
   /**
     * Effettua il display del tpl dell'amministratore
     */
    public function mostraPaginaAdmin(){
        $this->display('admin_default.tpl');
    }
    
   /**
     * @return array $contenuto contiene il Risultato del fetch dei template main
     * di errore
     */
    public function getErrore(){
        $this->impostaUrl();
        $contenuto = $this->fetch('errore_main.tpl');
        return $contenuto;
    }

    /**
     * Ritorna i template in caso di operazione andata a buon fine
     * @return string
     */
    public function getSuccesso(){
    	$this->impostaUrl();
        $contenuto = $this->fetch('successo_main.tpl');
        return $contenuto;
    }
    
/**
     * 
     * Assegna gli errori ad visualzzare nella home. Esiste il default
     * @param string $errore la stringa che descrive l'errore
     * @param bool $back un booleano, se posto a false, fa' sì che non compaia il link per tornare alla homepage
     */
    public function impostaAccessoNegato($errore = "Errore! Per poter effettuare l'operazione richiesta devi loggarti. Se non sei ancora un utente ePooling, registrati compilando semplicemente il modulo che segue!!!",$back = true){
        $view = USingleton::getInstance('VHome');
        $view->assign('errori', $errore);
        $view->assign('back',$back);
        }

   /** 
    * Assegna il messaggio di successo nella home
    * @param string $successo
    * @param bool $back
    */
   public function impostaSuccesso($successo = "Complimenti! L'operazione è avvenuta con successo!",$back = true){
       $view = USingleton::getInstance('VHome');
       $view->assign('back',$back);
       $view->assign('successo', $successo);
    }
    
    
}