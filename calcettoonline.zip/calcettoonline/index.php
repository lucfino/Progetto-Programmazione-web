<?php

require_once 'includes/autoload.inc.php';

if (file_exists('includes/config.inc.php'))

	require_once 'includes/config.inc.php';
	
else 

	require_once 'config.inc';

$CHome=USingleton::getInstance('CHome');

$CHome->impostaPagina();

?>