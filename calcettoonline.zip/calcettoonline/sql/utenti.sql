CREATE TABLE  utente (
nomeUtente VARCHAR( 15 ) NOT NULL ,
password VARCHAR( 32 ) NOT NULL ,
email VARCHAR( 50 ) NOT NULL ,
residenza VARCHAR( 50 ) NOT NULL ,
nomeu VARCHAR( 20 ) NOT NULL ,
cognome VARCHAR( 20 ) NOT NULL ,
sesso VARCHAR( 1 ) NOT NULL ,
dataN DATE NOT NULL ,
ban TINYINT(1) NOT NULL ,
codiceAttivazione VARCHAR( 10 ) NOT NULL ,
gol TINYINT(3) ,
attivato TINYINT(1),
privilegi TINYINT(1),
foto VARCHAR (170),
giocate INT(3),
mediaGol FLOAT(4),
PRIMARY KEY ( nomeUtente)
) ENGINE = INNODB;

