CREATE TABLE  squadra (
nome VARCHAR( 30 ) NOT NULL ,
giocate INT(3) NOT NULL,
vittorie INT(3) NOT NULL,
pareggi INT(3) NOT NULL,
sconfitte INT(3) NOT NULL,
golFatti INT(4) NOT NULL,
golSubiti INT(4) NOT NULL,
PRIMARY KEY (  nome )
) ENGINE = INNODB;