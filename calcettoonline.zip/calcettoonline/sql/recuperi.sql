CREATE TABLE  recupero (
email VARCHAR( 50 ) NOT NULL ,
codiceConferma INT( 10 ) NOT NULL,
PRIMARY KEY (email)
) ENGINE = INNODB;
