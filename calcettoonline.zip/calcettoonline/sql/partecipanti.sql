CREATE TABLE  partecipanti (
id_partita INT(5) NOT NULL,
utente VARCHAR( 15 ) NOT NULL,
squadra VARCHAR(30),
PRIMARY KEY (  id_partita,utente ),
FOREIGN KEY (id_partita) REFERENCES partita(id) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY (squadra) REFERENCES squadra(nome) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = INNODB;

