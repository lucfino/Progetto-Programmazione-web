INSERT INTO utente (
nomeUtente ,
password ,
email ,
residenza ,
nomeu ,
cognome ,
sesso ,
dataN ,
ban ,
codiceAttivazione ,
gol ,
attivato,
privilegi,
foto,
giocate,
mediaGol
)
VALUES 
('merlo', 'f2e522176d16a78e27abadec089c49a0 ', 'merlo89@hotmail.it', 'campobasso', 'giuseppe', 'fiorilli', 'm', '1989-02-28', '0', '1122334455', '0', '0', '0','./templates/main/templates/images/default.jpg','0','0'), 
('danny', 'f0a123d1917bebfc1bb226b1da00e2b4', 'danny89@hotmail.it', 'sulmona', 'daniele', 'leombruni', 'm', '1989-02-25', '0', '6677889900', '0', '1', '0','./templates/main/templates/images/default.jpg','0','0'), 
('lucas', '943559f251b9c5c937460c30dc638b9c', 'lucas89@hotmail.it', 'silvi', 'luca', 'finocchio', 'm', '1989-06-07', '0', '1234567890', '0', '1', '0', './templates/main/templates/images/default.jpg','0','0'), 
('james', '4b53b54a48fcd832cd20427643dc0f00', 'james89@hotmail.it', 'coppito', 'mario', 'corsi', 'm', '1989-03-21', '1', '0987654321', '0', '1', '0','./templates/main/templates/images/default.jpg','0','0');

INSERT INTO squadra (nome, giocate, vittorie, pareggi, sconfitte, golFatti, golSubiti)
VALUES ('milan','0','0','0','0','0','0'), ('juve','0','0','0','0','0','0'),('inter','0','0','0','0','0','0'), ('roma','0','0','0','0','0','0');

INSERT INTO partita (
id ,
nomep ,
datap ,
orap ,
risultato ,
note ,
disputata ,
id_campo ,
squadra1 ,
squadra2 ,
username
)
VALUES 
('1', 'prova', '2010-02-11', '21:00:00', NULL , NULL , '0', '1', 'milan', 'juve', 'danny'),
('2', 'prova1', '2011-10-14', '21:00:00', NULL , NULL , '0', '1', 'milan', 'inter', 'danny'),
('3', 'prova2', '2010-08-09', '12:00:00', NULL , NULL , '0', '2', 'inter', 'roma', 'lucas');









