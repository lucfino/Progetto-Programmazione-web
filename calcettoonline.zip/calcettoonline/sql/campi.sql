CREATE TABLE  campo (
id INT(5) NOT NULL AUTO_INCREMENT ,
nome VARCHAR( 30 ) NOT NULL ,
descrizione VARCHAR( 100 ) NULL ,
citta VARCHAR( 30 ) NOT NULL ,
foto VARCHAR( 170 ),
PRIMARY KEY ( id ),
INDEX (nome)
) ENGINE = INNODB;

INSERT INTO campo (id, nome, descrizione, citta, foto) VALUES 
('1', 'greenclub', NULL, 'laquila',NULL), 
('2', 'kickoff', NULL, 'silvi','./templates/main/templates/images/calcetto1.jpg'), 
('3', 'trisi', NULL, 'montesilvano','./templates/main/templates/images/calcetto2.jpg'), 
('4', 'marina', NULL, 'silvi','./templates/main/templates/images/calcetto3.jpg');




