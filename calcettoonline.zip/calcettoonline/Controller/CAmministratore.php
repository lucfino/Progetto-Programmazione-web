<?php
/**
 * @access public
 * @package Controller
 */

class CAmministratore {

    /**
     * Controlla se l'utente � un amministratore
     * @return bool true se l'utente � amministratore, false altrimenti
     */
    public function checkAmministratore(){
        $session = USingleton::getInstance('USession');
        $admin = $session->leggiValore('admin');
        if($admin == 1)
            return true;
        else
            return false;
    }

 	 /**
     * Mostra la pagina principale dell'amministratore.
     * @return string
     */
    public function index(){
    	global $config;
        $view = USingleton::getInstance('VAmministratore');
       	return $view->getContenuto('default');
    }
    
    /**
     * Mostra la pagina tramite la quale l'amministratore pu� bannare, attivare,
     * togliere il ban e dare privilegi agli utenti. 
     * @return string
     */
    public function moduloBanna(){
    	$view = USingleton::getInstance('VAmministratore');
    	return $view->getContenuto('modulo');
    }
    
    /**
     * Dato il nomeUtente inviato tramite request banna l'utente relativo. 
     * A fornte di questa azione le partite create da quest'ultimo vengono 
     * impostate come non disputate(non � possibile quindi inserire le
     * statistiche se gia non lo � stato fatto). 
     * Vengono inoltre cancellati tutti i commenti fatti dall'utente. 
     */
    public function banna(){
    	$view = USingleton::getInstance('VAmministratore');
    	$futente = USingleton::getInstance('FUtente');
    	$fpartita = USingleton::getInstance('FPartita');
    	$fvoti = USingleton::getInstance('FVoto');
    	$sessione = USingleton::getInstance('USession');
    	$user = $view->getRequest('nomeutente');
    	$utente = $futente->load($user);
    	if (!$utente){
    		$view->impostaUrl();
    		$view->impostaAccessoNegato('lo username non esiste');
    		if ($view->getRequest('aj')==1)
    			return $view->display('admin_main_errore.tpl');
    		else
    			return $view->getErrore();	    		
    	}
    	$sestesso = $sessione->leggiValore('username');
    	if ($utente == $sestesso){
    		$view->impostaUrl();
    		$view->impostaAccessoNegato('non puoi bannare te stesso');
    		if ($view->getRequest('aj')==1)
    			return $view->display('admin_main_errore.tpl');
    		else
    			return $view->getErrore();
    	}
    	$utente->ban = 1;
    	$futente->update($utente);
    	$partita = $fpartita->search(array(array('username','=',$user)));
    	if ($partita){
    		foreach($partita as $item){
    			$item->disputata = 0;
    			$fpartita->update($item);
    		}
    	}
    	$voti = $fvoti->search(array(array('mittente','=',$user)));
    	if ($voti){
    		foreach ($voti as $item){
    			$fvoti->delete($item);
    		}
    	}
    	$view->impostaSuccesso('utente bannato');
    	if ($view->getRequest('aj')==1)
    		return $view->display('admin_main_successo.tpl');
    	else
    		return $view->getSuccesso();
    }
    
    /**
     * Dato il nomeUtente inviato tramite request attiva l'utente relativo.
     */
    public function attiva(){
    	$view = USingleton::getInstance('VAmministratore');
    	$futente = USingleton::getInstance('FUtente');
    	$user = $view->getRequest('nomeutente');
    	$utente = $futente->load($user);
    	if ($utente != ''){
    		$utente->attivato = 1;
    		$futente->update($utente);
    		$view->impostaUrl();
    		$view->impostaSuccesso('utente bannato');
    		return $view->getSuccesso(); 
    	}
    	else{
    		$view->impostaUrl();
    		$view->impostaAccessoNegato('lo username non esiste');
    		return $view->getSuccesso();
    	}
    		
    }
    
    /**
     * Dato il nomeUtente inviato tramite request assegna all'utente relativo
     * i privilegi di amministratore.
     */
	public function privilegi(){
    	$view = USingleton::getInstance('VAmministratore');
    	$futente = USingleton::getInstance('FUtente');
    	$user = $view->getRequest('nomeutente');
    	$utente = $futente->load($user);
    	if ($utente != ''){
    		$utente->privilegi = 1;
    		$futente->update($utente);
    		$view->impostaUrl();
    		$view->impostaSuccesso('utente bannato');
    		return $view->getSuccesso(); 
    	}
    	else{
    		$view->impostaUrl();
    		$view->impostaAccessoNegato('lo username non esiste');
    		return $view->getSuccesso();
    	}
    		
    }
    
    /**
     * Dato il nomeUtente inviato tramite request togli l'utente relativo
     * i privilegi di amministratore.
     * @return string
     */
	public function togliPrivilegi(){
    	$view = USingleton::getInstance('VAmministratore');
    	$futente = USingleton::getInstance('FUtente');
    	$user = $view->getRequest('nomeutente');
    	$utente = $futente->load($user);
    	if ($utente != ''){
    		$utente->privilegi = 0;
    		$futente->update($utente);
    		$view->impostaUrl();
    		$view->impostaSuccesso('utente bannato');
    		return $view->getSuccesso(); 
    	}
    	else{
    		$view->impostaUrl();
    		$view->impostaAccessoNegato('lo username non esiste');
    		return $view->getSuccesso();
    	}
    		
    }
    
    /**
     * Dati la tabella, il campo, e il valore iviati tramite requeset,
     * da cercare viene stampato in una tabella il risultato della ricerca.
     * @return string
     */
	public function database(){
    	global $config;
    	$vamministratore = USingleton::getInstance('VAmministratore');
    	$tabella = $vamministratore->getRequest('tabella');
    	$colonna = $vamministratore->getRequest('colonne');
    	$nome = $vamministratore->getRequest('nome');
    	$vamministratore->assegnaTabelle();
    	if ($tabella!='' && $colonna!=''){
    		if ($nome!='')
    			$parametri = array(array($colonna,'REGEXP',$nome));
    		else
    			$parametri=array();
    		$vamministratore->assign('table',$tabella);
    		$risultato = $this->ricerca($tabella,$parametri);
    		$vamministratore->assign('risultato',$risultato);
    	}
    	$vamministratore->impostaUrl();
    	return $vamministratore->getContenuto('database');
    }
    
    /**
     * Dati la tabella e i parametri richiesti effettua
     * la ricerca nel database.
     * @return array
     */
    public function ricerca($tabella, $parametri = array()){
    	ucfirst($tabella);
    	$fcerca = USingleton::getInstance('F'.$tabella);
    	return $fcerca->search($parametri);
    }
    
    /**
     * Elimina una tupla dal db.
     * @return string
     */
    public function elimina(){
    	$vamministratore = USingleton::getInstance('VAmministratore');
    	$tabella = $vamministratore->getRequest('tabella');
    	ucfirst($tabella);
    	$fcerca = USingleton::getInstance('F'.$tabella);
    	$elimina= $vamministratore->getRequest('elimina');
    	$oggetto=$fcerca->load($elimina);
    	$successo=true;
    	$successo = $fcerca->delete($oggetto);
    	$vamministratore->impostaUrl();
    	if ($successo){
    		$vamministratore->impostaUrl();
    		$vamministratore->impostaSuccesso("L'eliminazione � avvenuta con successo");
	    	return $vamministratore->getSuccesso();
    	}
    	else{
    		$view->impostaUrl();
    		$vamministratore->impostaAccessoNegato("C'� stato un errore");
            return $vamministratore->getErrore();
    	}
    }
    
     /**
     * In base al parametro mostra la form per la modifica o quella
     * per aggiunger un campo
     * @param boolean $riprova
     */
    public function moduloModifica($riprova = false){
    	$vamministratore= USingleton::getInstance('VAmministratore');
    	if (!$riprova){
    		$modifica=$vamministratore->getRequest('modifica');
    		$aggiungi=true;
    		if ($modifica!=''){
    			$fcerca = USingleton::getInstance('FCampo');
    			$oggetto=$fcerca->load($modifica);
    			$vamministratore->assign('risultato',$oggetto);
    			$aggiungi=false;
    		}
    	}
    	else
    		$aggiungi = false;
    	$vamministratore->assign('aggiungi',$aggiungi);
    	$vamministratore->impostaUrl();
    	return $vamministratore->getContenuto('moduloModifica');
    }
    
    /**
     * Controlla che tutti i valori inseriti siano giusti e modifica il campo
     */
    public function modificaCampo(){
    	$vamministratore = USingleton::getInstance('VAmministratore');
    	$fcampo = USingleton::getInstance('FCampo');
    	$id = $vamministratore->getRequest('id');
    	$nome = $vamministratore->getRequest('nome');
    	$citta = $vamministratore->getRequest('citta');
    	$descrizione = $vamministratore->getRequest('descrizione');
	    foreach($errori as $value){
        	if($value != NULL)
            	$esito = true;
        }
        if (!$esito){
    		$attuale = $fcampo->load($id);
    		$attuale->nome = $nome;
    		$attuale->citta = $citta;
    		$attuale->descrizione = $descrizione;
    		$esito2 = true;
    		$esito2 = $fcampo->update($attuale);
    		if ($esito2 != true){
    			$view->impostaUrl();
    			$vamministratore->impostaAccessoNegato("C'&egrave; stato un errore");
            	return $vamministratore->getErrore();
    		}
    		else{
    			$view->impostaUrl();
            	$vamministratore->impostaSuccesso("La modifica &egrave; avvenuta con successo");
	    		return $vamministratore->getSuccesso();
    		}
        }
        else{
        	$array = array();
            foreach ($errori as $value)
                    $array[]=$value;
            $id = $vamministratore->getRequest('id');
            $risultato = $fcampo->load($id);
            $vamministratore->assign('risultato',$risultato);
            $vamministratore->assign('errori',$array);
            return $this->moduloModifica(true);
        }
    }
    
    /**
     * Controlla se ci sono errori nei dati di un campo
     * @param string $nome
     * @param string $citta
     * @param string $descrizione
     * @param string $modifica
     */
    public function controllaCampi($nome,$citta,$descrizione,$modifica=false){
    	$ucontrolli = USingleton::getInstance(('UControlli'));
    	$errori[0] = $ucontrolli->nomeCampo($nome,$modifica);
    	$errori[1] = $ucontrolli->comune($citta);
    	$errori[2] = $ucontrolli->commento($descrizione);
    	$errori[3] = $this->controllaFoto();
    	return $errori;
    }
    
    /**
     * Dato il nomeUtente inviato tramite request toglie
     * il ban all'utente relativo.
     */
	public function togliBan(){
    	$view = USingleton::getInstance('VAmministratore');
    	$futente = USingleton::getInstance('FUtente');
    	$fpartita = USingleton::getInstance('FPartita');
    	$user = $view->getRequest('nomeutente');
    	$utente = $futente->load($user);
    	if ($utente != ''){
    		$utente->ban = 0;
    		$futente->update($utente);
    		$partita = $fpartita->search(array(array('username','=',$user)));
    		foreach($partita as $item){
    			$item->disputata = 1;
    			$fpartita->update($item);
    		}
    		$view->impostaUrl();    		
    		$view->impostaSuccesso('utente bannato');
    		return $view->getSuccesso();
    	}
    	else{
    		$view->impostaUrl();
    		$view->impostaAccessoNegato('lo username non esiste');
    		return $view->getSuccesso();
    	}
    }
    
    /**
     * Aggiunge un campo nel database con i dati presi dalla form
     */
    public function aggiungiCampo(){
    	$vamministratore = USingleton::getInstance('VAmministratore');
    	$fcampo = USingleton::getInstance('FCampo');
    	$attuale = USingleton::getInstance('ECampo');
    	$nome = $vamministratore->getRequest('nome');
    	$citta = $vamministratore->getRequest('citta');
    	$descrizione = $vamministratore->getRequest('descrizione');
    	$errori = $this->controllaCampi($nome,$citta,$descrizione);
    	$esito = false;
	    foreach($errori as $value){
        	if($value != NULL)
            	$esito = true;
        }
        if (!$esito){
    		$attuale->nome = $nome;
    		$attuale->citta = $citta;
    		$attuale->descrizione = $descrizione;
    		$path = $_FILES["fotoCampo"]['name'];
    		$attuale->foto = './templates/main/templates/images/'.$path;
    		$esito2 = true;
    		$esito2 = $fcampo->store($attuale);
    		if ($esito2){
    			$vamministratore->impostaUrl();
    			$vamministratore->impostaAccessoNegato("C'&egrave: stato un errore. Riprova");
            	return $vamministratore->getErrore();
    		}
    		$esito2 = move_uploaded_file($_FILES["fotoCampo"]['tmp_name'], './templates/main/templates/images/'.$_FILES["fotoCampo"]['name']);    		
    		if (!$esito2){
 				$vamministratore->impostaUrl();
    			$vamministratore->impostaAccessoNegato("C'&egrave: stato un errore nel caricamento della foto. Riprova");
            	return $vamministratore->getErrore();
 				}
    		$vamministratore->impostaUrl();
            $vamministratore->impostaSuccesso("Il campo &egrave; stato aggiunto con successo");
	    	return $vamministratore->getSuccesso();    		
        }
        else{
        	$array = array();
            foreach ($errori as $value)
                    $array[]=$value;
            $vamministratore->assign('errori',$array);
            return $this->moduloModifica();
        }
    }
    
    /**
     * 
     * Controlla che le dimesioni e il formato siano corrette oltre che 
     * contrllare se $_FILES["fotoCampo"]['error'] sia uguale a 0 
     */
    public function controllaFoto(){
    	$mess= NULL;
    	if($_FILES["fotoCampo"]['error'] == 4){} //se il campo error &egrave = 4 allora in ql campo nn &egrave stata caricata alcuna foto
			else if($_FILES["fotoCampo"]['type'] !='image/jpeg' && $_FILES["fotoCampo"]['type'] !='image/gif' && $_FILES["fotoCampo"]['type'] !='image/png'  ){
				$mess= $mess."il formato della foto non è corretto. <br>La foto non e&grave stata inserita. Riprova ";
				return $mess;		
				}
			else{  //controllo le dimensioni del file. La dimensione max definita in php.ini &egrave di 2 MB=2097152 Byte
					if($_FILES["fotoCampo"]['size'] > 2097152){
						$mess="la foto e&grave troppo grande. <br> La foto non e&grave stata inserita. Riprova!";
						return $mess;	
					}	
					else if($_FILES["fotoCampo"]['error'] != 0){
						$mess="&Egrave stato riscontrato un errore nella foto. Riprova";
						return $mess;
					}
		}
		return $mess;
    }    
    
    /**
     * Smista le richieste ai vari metodi
     * @return mixed
     */
	public function smista(){
		$VHome = USingleton::getInstance('VHome');
		$cookie = USingleton::getInstance('UCookie');
        $view = USingleton::getInstance('VAmministratore');
        $task = $view->getTask();
        if(!isset($task))
            $task='default';
        switch ($task) {
            default:
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->index();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
            case 'bannaUtente':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->moduloBanna();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }            	
            case 'banna':
            	if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->banna();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
            case 'attiva':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->attiva();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
            case 'privilegi':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->privilegi();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
            case 'togliPrivilegi':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->togliPrivilegi();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
            case 'elimina':
       			if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->elimina();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
                break;
            case 'database':
       			if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->database();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
                break;
            case 'moduloModifica':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->moduloModifica();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
                break;
            case 'modificaCampo':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->modificaCampo();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
                break;
            case 'aggiungiCampo':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->aggiungiCampo();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
                break;
            case 'togliBan':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if ($this->checkAmministratore())
                	return $this->togliBan();
                else{
                	$VHome->impostaAccessoNegato('Non hai i privilegi di amministratore');
                	return $VHome->getErrore();
                }
        }
    }
    
}