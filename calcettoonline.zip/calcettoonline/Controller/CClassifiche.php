<?php
/**
 * @access public
 * @package Controller
 */
class CClassifiche{
	
	/**
	 * Mostra la tabella con le statistiche degli utenti
	 */
	public function classificaMediaGol(){		
		$view=USingleton::getInstance('VClassifiche');
		$param=array(array('privilegi','=','0'));
		$ordinamento=$view->getRequest('ordine');
		$risultato=$this->cercaUtente($param,$ordinamento);
		$view->assign('utente',$risultato);
		$view->impostaUrl();
		return $view->getContenuto('default');
	}
	
	/**
	 * Dati parametri e ordine cerca gli utenti e restituisce un array di utenti
	 * @param array $param
	 * @param string $ordinamento
	 * @return  array di utenti $risultato
	 */
	public function cercaUtente($param,$ordinamento){
		$futente=USingleton::getInstance('FUtente');
		$return= $futente->search($param,$ordinamento);
		return $return;
	}
	
	/**
	 * Mostra la tabella con le statistiche delle squadre
	 */
	public function	classificaSquadre(){
		$view=USingleton::getInstance('VClassifiche');
		$fsquadra=USingleton::getInstance('FSquadra');
		$param=array();
		$ordinamento=$view->getRequest('ordine');
		$squadre=$fsquadra->search($param,$ordinamento);
		$view->assign('squadre',$squadre);
		$view->impostaUrl();
		return $view->getContenuto('squadre');
	}
	
	/**
	 * Mostra la tabella dei risultati della ricerca e se specificato li ordina
	 */
	public function cerca(){
		$view = USingleton::getInstance('VClassifiche');
		$cerca = $view->getRequest('utente');		
		$parametri=array(array('nomeUtente','REGEXP',$cerca));
		$ordinamento=$view->getRequest('ordine');
		$utente=$this->cercaUtente($parametri,$ordinamento);
		$view->assign('cerca',$cerca);
		$view->assign('utente',$utente);
		$view->impostaUrl();
		return $view->getContenuto('cerca');
	}
	
	/**
     * Smista le richieste ai vari metodi
     * @return mixed
     */
	public function smista(){
		$view=USingleton::getInstance('VClassifiche');
        switch ($view->getTask()) {
        	default:
        		return $this->classificaMediaGol();
        	case 'cerca':
        		return $this->cerca();
        	case 'squadre':
        		return $this->classificaSquadre();
		}
	}
}