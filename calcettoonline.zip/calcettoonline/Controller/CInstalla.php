<?php
/**
 * @access public
 * @package Controller
 */
class CInstalla{
    
	/**
	 * 
	 * Stampa il modulo per l'installazione dell'applicazione
	 */
	public function moduloInstalla(){
		$install = USingleton::getInstance('VInstalla');
		return $install->display('installazione_modulo.tpl');
	}
	
	/**
	 * 
	 * Installa l'applicazione: crea il database e il file di configurazione
	 */
	public function installa(){
	    $check = USingleton::getInstance('UControlli');
	    $install = USingleton::getInstance('VInstalla');
		$dati = $_POST;
		$esito = NULL;
		if(!isset($dati['nomeDb']))
    		$esito[] = 'Devi inserire il nome del database';
		if(!isset($dati['hostDb']))
    		$esito[] = 'Devi inserire la posizione del database';
		if(!isset($dati['usernameDb']))
        	$esito[] = 'Devi inserire il campo username database';
		if($dati['passwordDb']!=$dati['passwordCDb'])
        	$esito[] = 'Errore nella conferma della password del databse';
		if($check->username($dati['usernameApp'],true) != NULL)
        	$esito[] = 'Errore nel campo utente amministratore';
		if($check->password($dati['passwordApp'], $dati['passwordCApp']) != NULL)
        	$esito[] = 'Errore nel campo password amministratore';
		if(isset($dati['esempio']) && $dati['esempio']=='true')
    		$esempio=true;
		else 
			$esempio=false;
		if(!isset($dati['mailServer'])) 
			$esito[] = 'Campo Server mail vuoto';
		if(!isset($dati['mailPorta'])) 
			$esito[] = 'Campo Porta (mail) vuoto';
		if(!isset($dati['mailAuth'])){
    		$dati['mailAuth']=false;
    		$dati['mailUsername']="";
    		$dati['mailPassword']="";
		}
		else{
    	$dati['mailAuth']=true;
    	if($dati['mailPassword']!=$dati['mailPasswordC'])
        	$esito[] = 'La Password della mail e la conferma non coincidono';
		}
		if(!isset($esito)){
			$connessione=mysql_connect($dati['hostDb'], $dati['usernameDb'], $dati['passwordDb']);
      	if($connessione) {
            if($this->memorizzaDati($dati)){
                 if($this->creaDatabase($connessione,$dati,$esempio)){
           		 	$install->impostaSuccesso("Installazione avvenuta con successo.");
                    return $install->display('installazione_successo.tpl');
                 }
                 else{
					unlink('includes/config.inc.php');
                 	$install->impostaAccessoNegato("Errore nella creazione del database");
                    return $install->display('installazione_errore.tpl');
                 }
                 }   
                 else{ 
					unlink('includes/config.inc.php');
                 	$install->impostaAccessoNegato("Errore nella memorizzazione di config");
                    return $install->display('installazione_errore.tpl');
                 }
       		mysql_close($connessione);
       		}
       		else{
				unlink('includes/config.inc.php');
       			$install->impostaAccessoNegato("Errore nella connesione al database");
                return $install->display('installazione_errore.tpl');
       		}
		}
		else{
			unlink('includes/config.inc.php');
      		$install->impostaAccessoNegato("Errore");
            return $install->display('installazione_errore.tpl');
    	}
		
	}
    
	/**
	 * 
	 * Crea l'url dell'applicazione
	 */
	public function componiUrl(){
    	$dir= dirname($_SERVER['SCRIPT_NAME']);
    	$url=$_SERVER['SERVER_NAME'].$dir."/";
    	return $url;
	}
	
	/**
	 * 
	 * Crea il database eseguendo le query che si trovano nei vari file sql.
	 * Se $esempio � true, inserisce anche dei dati di esempio.
	 * @param mixed $connessione
	 * @param array $dati
	 * @param bolean $esempio
	 */
	public function creaDatabase($connessione,$dati,$esempio){
		if(!mysql_query("CREATE DATABASE ".$dati['nomeDb'],$connessione)) {
			return false;
		}
    	if(!mysql_query("use ".$dati['nomeDb'],$connessione)){
    		return false;
    	}
    	$script_sql[]="./sql/utenti.sql";
    	$script_sql[]="./sql/campi.sql";
    	$script_sql[]="./sql/squadre.sql";
    	$script_sql[]="./sql/partite.sql";
     	$script_sql[]="./sql/recuperi.sql";
     	$script_sql[]="./sql/voti.sql";
    	$script_sql[]="./sql/partecipanti.sql";
    	if($esempio){
        	$script_sql[]="./sql/esempio.sql";
    	}
		foreach ($script_sql as $value1) {
			if(!file_exists ($value1)){
              return false;
        	}
			$stringa=file_get_contents($value1);
        	$array=explode(';',$stringa);
        	array_pop($array);
			foreach ($array as $value2){
           		if(!mysql_query($value2,$connessione)){
               		return false;
           		}
        	}
    	}
    	$password = md5($dati['passwordApp']);
    	$q_admin="INSERT INTO `utente` (`nomeUtente`, `password`, `email`,
              `residenza`,`nomeu`, `cognome`,`sesso`, `dataN`,`ban`,`codiceAttivazione`,
               `gol`,`attivato`,`privilegi`,`foto`,`giocate`,`mediaGol`) VALUES ('".$dati['usernameApp']."', '".$password."', 'calcetto89@virgilio.it',
               'laquila','admin','admin', 'm', '1989-1-1', '0',
               '0000000000000000', '0', '1', '1', './templates/main/templates/default.jpg', '0', '0')";

    	if(!mysql_query($q_admin,$connessione)){
               return false;
        }
		return true;
	}
	
	/**
	 * 
	 * Crea il file congif.inc.php e scrive al suo interno i dati ricevuti dalla
	 * form di installazione
	 * @param array $dati
	 */
	public function memorizzaDati($dati){
		$config_file="./includes/config.inc.php";
    	$source_file="config.inc";
    		if(!file_exists ($source_file)){
        		return false;
    		}
		$source=file($source_file);
		$url="http://".$this->componiUrl();
    	$urls="https://".$this->componiUrl();
    	$source[]='$config[\'url\'][\'http\'] = '.'\''.$url.'\';'."\n";
    	$source[]='$config[\'url\'][\'https\'] = '.'\''.$urls.'\';'."\n";
    	$source[]='$config[\'mysql\'][\'database\'] = '.'\''.$dati['nomeDb'].'\';'."\n";
    	$source[]='$config[\'mysql\'][\'user\'] = '.'\''.$dati['usernameDb'].'\';'."\n";
    	$source[]='$config[\'mysql\'][\'password\'] = '.'\''.$dati['passwordDb'].'\';'."\n";
    	$source[]='$config[\'mysql\'][\'host\'] = '.'\''.$dati['hostDb'].'\';'."\n";
    	$source[]='$config[\'smtp\'][\'host\'] = '.'\''.$dati['mailServer'].'\';'."\n";
    	$source[]='$config[\'smtp\'][\'port\'] = '.'\''.$dati['mailPorta'].'\';'."\n";
    	$source[]='$config[\'smtp\'][\'smtpauth\'] = '.'\''.$dati['mailAuth'].'\';'."\n";
    	$source[]='$config[\'smtp\'][\'username\'] = '.'\''.$dati['mailUsername'].'\';'."\n";
    	$source[]='$config[\'smtp\'][\'password\'] = '.'\''.$dati['mailPassword'].'\';'."\n";
    	$source[]='?>';
		if(!file_put_contents($config_file, $source)) {
        	return false;
    	}
    	else 
    		return true;
	}
	
	/**
	 * 
	 * Smista le richieste ai vari metodi
	 * @return mixed
	 */
	public function smista(){
		$vinstall = USingleton::getInstance('VInstalla');
		$install = $vinstall->getTask();
		switch ($install) {
			default:
				return $this->moduloInstalla();
			case 'installa':
				return $this->installa();	
		}
	}
	
	
}