<?php
/**
 * @access public
 * @package Controller
 */

class CAjax {
	
	/**
     * Dato l'id di una partita inviato tramite request, restituisce il
     * template contenente le informazioni relative alle partita stessa. 
     */ 
	public function riepilogo_partita(){
		$view = USingleton::getInstance('VAjax');
		$fpartita = USingleton::getInstance('FPartita');
		$id = $view->getRequest('idp');
		$partita = $fpartita->load($id);
		$view->assign('partita',$partita);
		$view->display('ajax_riepilgo_partite.tpl');
	}
	
	/**
     * 
     * Data una coppia campo-valore inviata tramite request, dice se
     * esiste una occorrenza di quel campo all'interno della tabella utenti,
     * per quel valore nel database restituisce 1 o 0 al client.
     */
    public function esistenza(){
       $vajax = USingleton::getInstance('VAjax');
       $futente = USingleton::getInstance('FUtente');
       $val = $vajax->getRequest('valore');
       $cam = $vajax->getRequest('campo');
       $parametri = array(array($cam,'=',$val));
       $risultato = $futente->search($parametri);
       if($risultato != false)
            echo '1';
       else
            echo '0';
    }
    
	/**
     * 
     * Data una coppia campo-valore inviata tramite request, dice se
     * esiste una occorrenza di quel campo all'interno della tabella squadra,
     * per quel valore nel database restituisce 1 o 0 al client.
     */
    public function esistenzaSquadra(){
       $vajax = USingleton::getInstance('VAjax');
       $fsquadra = USingleton::getInstance('FSquadra');
       $val = $vajax->getRequest('valore');
       $cam = $vajax->getRequest('campo');
       $parametri = array(array($cam,'=',$val));
       $risultato = $fsquadra->search($parametri);
       if($risultato != false)
            echo '1';
       else
            echo '0';
    }
    
	/**
     * 
     * Data una coppia campo-valore inviata tramite request, dice se
     * esiste una occorrenza di quel campo all'interno della tabella campo,
     * per quel valore nel database restituisce 1 o 0 al client.
     */
    public function esistenzaCampo(){
       $vajax = USingleton::getInstance('VAjax');
       $fcampo = USingleton::getInstance('FCampo');
       $val = $vajax->getRequest('valore');
       $cam = $vajax->getRequest('campo');
       $parametri = array(array($cam,'=',$val));
       $risultato = $fcampo->search($parametri);
       if($risultato != false)
            echo '1';
       else
            echo '0';
    }
    
    /**
     * Stampa il template relativo alle informazioni sul sito.
     */ 
	public function istruzioni(){
		$view = USingleton::getInstance('VAjax');
		return $view->display('home_main_istruzioni.tpl');
	}
	
	/**
     * Stampa il template relativo alle home
     */
	public function home(){
		$view = USingleton::getInstance('VHome');
		$CHome = USingleton::getInstance('CHome');
		$CHome->assegnaPartite();
		$view->display('home_main_default.tpl');
	}
	
	/**
     * Stampa il template relativo alle informazioni sui campi. 
     */
	public function campi(){
    	$fcampo = USingleton::getInstance('FCampo');
    	$view = USingleton::getInstance('VAjax');
    	$parametri=array();
    	$ordinamento = $view->getRequest('ordine');
    	$campi = $fcampo->search($parametri,$ordinamento);
    	$view->assign('campi',$campi);
    	return $view->display('home_main_campi.tpl');    	
    }
    
    /**
     * Smista le richieste ai vari metodi
     * @return mixed
     */
	public function smista(){
		$view = USingleton::getInstance('VAjax');
        switch ($view->getTask()){
            case 'riepilogo_partite':
                return $this->riepilogo_partita();
            case 'esistenza':
            	return $this->esistenza();
            case 'campi':
            	return $this->campi();
            case 'istruzioni':
            	return $this->istruzioni();	
            default:
            	return $this->home();
            case 'esistenzaSquadra':
            	return $this->esistenzaSquadra();
            case 'esistenzaCampo':
            	return $this->esistenzaCampo();		
        }
    }
	
}