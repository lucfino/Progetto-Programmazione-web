<?php

/**
 * @access public
 * @package Controller
 */
class CRegistrazione{
    
	/**
	 * Ritorna il tpl relativo al modulo di registrazione di 
	 * una partita
	 */
	public function modulo(){
	    $view = USingleton::getInstance('VRegistrazione');
	    $view->impostaUrl();
	    $view->impostaDate('nascita');
	    if ($view->getRequest('aj')==1)
        	return $view->display('registrazione_modulo.tpl');
        else 
        	return $view->getContenuto('modulo');	
    }
    
    /**
     * 
     * Ritorna il tpl relativo al modulo di registrazione di 
	 * una partita nel caso l'utente voglia modificare i dati 
     */
	public function modifica(){
	    $view = USingleton::getInstance('VRegistrazione');
	    $dati = $view->getDatiRegistrazione();
	    $view->assegnaDatiRegistrazione($dati);
	    $view->impostaUrl();
	    $view->impostaDate('nascita');
	    $dati = $view->getDatiRegistrazione();
	    $view->assegnaDatiRegistrazione($dati,1);
		if ($view->getRequest('aj')==1)
        	return $view->display('registrazione_modulo.tpl');
        else 
        	return $view->getContenuto('modulo');	
    }
    
    
    /**
     * 
     * Restituisce il tpl relativo alla schermata di riepilogo
     * dei dati inseriti nella registrazione se sono corretti
     * altrimenti ritorna al modulo di creazione
     */
    public function riepilogo(){
     	$view = USingleton::getInstance('VRegistrazione');
	    $dati = $view->getDatiRegistrazione();
	    $errori = $this->controllaRegistrazione($dati);
	    $esito = false;
	    foreach($errori as $value){
        	if($value != NULL)
            	$esito = true;
        }
    	if(!$esito){
           	$view->assegnaDatiRegistrazione($dati);
            $view->impostaUrl();
            if ($view->getRequest('aj')==1)
        		return $view->display('registrazione_riepilogo.tpl');
        	else 
        		return $view->getContenuto('riepilogo');	
            }
        else{
            $array = array();
            foreach ($errori as $value)
                if(isset ($value))
                    $array[]=$value;
            $view->assign('errori',$array);
            return $this->modifica();
            }
    }
    
  	/**
   	* 
   	* Salva i dati di creazione sul db e restituisce il tpl 
   	* per gli inviti
   	*/
	public function salva(){
	    $view = USingleton::getInstance('VRegistrazione');
	    $utente = USingleton::getInstance('EUtente');
	    $futente = USingleton::getInstance('FUtente');
	    $VHome = USingleton::getInstance('VHome');
	    $dati = $view->getDatiRegistrazione();
	    $utente->setCampi($dati);
	    $utente->foto = './templates/main/templates/images/default.jpg';
	    $futente->store($utente);
	    $this->emailAttivazione($utente);
	    $view->impostaUrl();
	    $VHome->impostaSuccesso('registrazione effettuata con successo');
	    if ($view->getRequest('aj')==1)
        	 return $VHome->display('successo_main.tpl'); 
        else 
        	return $view->getSuccesso();	  
    }
    
    /**
     * 
     * Permette di attivare l'utente se il codice di attivazione
     * e lo username inviati tramite request sono presenti
     * altrimenti ritorno il tpl di attivazione
     */
    public function attivazione(){
    	$VHome = USingleton::getInstance('VHome');
    	$view = USingleton::getInstance('VRegistrazione');
    	$futente = USingleton::getInstance('Futente');
    	$codice = $view->getRequest('codiceAttivazione');
    	$user = $view->getRequest('username');
    	if($codice != '' && $user != ''){
    		$utente = $futente->load($user);
    		if ($codice == $utente->codiceAttivazione){
    			$utente->attivato = 1;
    			$futente->update($utente);
    			$VHome->impostaSuccesso('attivazione avvenuta con successo');
    			return $VHome->getSuccesso();
    		}
    	}
    	$view->impostaUrl();
    	return $view->getContenuto('attivazione');
    }
    
	
    /**
     * 
     * La funzione effettua il login e imposta i permessi in caso di esito positivo
     * @return string Ritorna la pagina relativa al controllo sull'esito
     */    
	public function login(){
        global $config;
        $view = USingleton::getInstance('VHome');
        $registrazione = USingleton::getInstance('VRegistrazione');
        $CHome = USingleton::getInstance('CHome');
        $session = USingleton::getInstance('USession');
        $cookie = USingleton::getInstance('UCookie');
        if($cookie->checkCookie() == true){
            $esito = $this->autentica();
            $username = $session->leggiValore('username');
            if($esito == true){
                if($session->leggiValore('admin') == 1){
                    $view->setController('amministratore');
                    $cookie->setCookie('sessione','si');
                    return $CHome->impostaPagina();}
                if($session->leggiValore('attivato') == false){
                    $session->distruggiSessione();
                    return $registrazione->getContenuto('attivazione');
                }
                else{
                    $view->setController('default');
                    $cookie->setCookie('sessione','si');
                    return $CHome->impostaPagina();}
            }
            else{
                $ban = $this->checkBan($username);
                if($ban=='1'){
                    $view->impostaAccessoNegato('Sei stato allontanato dal sito.');
                    return $view->getErrore();
                }
                else{
                $view->impostaAccessoNegato('Username o password errati. Riprova.');
                return $view->getErrore();}
            }

            }
       else{
           return $view->getContenuto('cookieDisattivati');
       }
    }
    
    /**
     * 
     * Questa funzione viene utilizzata per controllare che i dati di login siano corretti.
     * Controlla prima che l'username esista, poi che
     * la password inserita corrisponda a quella di quell'username e infine controlla
     * che il codice di attivazione sia 0 (=utente confermato). Il metodo si occupa anche
     * di controllare che username e password siano scritti nel modo corretto. In caso contrario ritorna false
     * @return bool
     */
    public function autentica(){
        global $config;
        $controlli = USingleton::getInstance('UControlli');
        $VRegistrazione = USingleton::getInstance('VRegistrazione');
        $futente = USingleton::getInstance('FUtente');
        $session = USingleton::getInstance('USession');
        $username = $VRegistrazione->getRequest('username');
        $password = $VRegistrazione->getRequest('password');
        $check[] = $controlli->username($username,true);
        $check[] = $controlli->password($password,$password);
        $utente = $futente->load($username);
        $ban = $this->checkBan($username);
        if($ban != '1'){
            if($utente != '' && $check[0] == NULL && $check[1] == NULL){
                if(md5($password) == $utente->password){
                    if($utente->privilegi == '1')
                        $session->impostaValore('admin',1);
                    if($utente->attivato == 1)
                        $session->impostaValore ('attivato', true);
                    else
                        $session->impostaValore ('attivato', false);
                    $session->impostaValore('username', $username);

                    return true;
                }
                else{
                    return false;
                }
            }
            
            else
                return false;}
       else{
           $session->impostaValore('username', $username);
           return false;
       }
    }
    
	public function checkBan($username){
		$futente = USingleton::getInstance('FUtente');
        $utente = $futente->load($username);
        if ($utente)
        	return $utente->ban;
        else 
        	return;	
    }
    

    /** 
     * La funzione effettua il logout dopo una sessione.
     * @param bool $redirect Deve essere impostato a false nel
     * caso dopo il logout non si voglia effettuare il redirect all'home page
     * @return mixed reimposta la pagina iniziale
     */
    public function logout($redirect = true){
        $view = USingleton::getInstance('VHome');
        $CHome = USingleton::getInstance('CHome');
        $session = USingleton::getInstance('USession');
        $session->distruggiSessione();
        $session->cancellaValore('username');
        $session->cancellaValore('attivato');
        $session->cancellaValore('admin');
        $view->setController('default');
        unset($_COOKIE['sessione']);
        if($redirect == true){
            $view->unsetRequest();
            $CHome->impostaPagina();}
    }
    

    /** 
     * @return string ritorna il fetch del tpl per il recupero delle credenziali
     */
    public function moduloRecupero(){
        $view = USingleton::getInstance('VRegistrazione');
        return $view->getContenuto('recuperaCredenziali');
    }    
    

    /** 
     * Il metodo invia una mail contenente il codice di conferma per richiedere la password.
     * Tale metodo inserisce in una tabella il codice fiscale dell'utente e il codice di attivazione.
     * Quando l'utente invierà queste due informazioni, allora verrà portato alla schermata per la modifica della
     * password
     */
    public function recupera(){
        $view = USingleton::getInstance('VRegistrazione');
        $FRecupero = USingleton::getInstance('FRecupero');
        $FUtente = USingleton::getInstance('FUtente');
        $CHome = USingleton::getInstance('CHome');
        $controlli = USingleton::getInstance('UControlli');
        $EConferma = USingleton::getInstance('ERecupero');
        $VHome = USingleton::getInstance('VHome');
        $email = $view->getRequest('email');
        $esito = $controlli->emailRichieste($email);
        $risultato = $FUtente->search(array(array('email','=',$email)));
        if($risultato!=null){
            if(isset($email) && $esito == NULL){
                $FRecupero->delete($risultato[0]);
                $EConferma->setCampi($email);
                $FRecupero->store($EConferma);
                $this->inviaEmailCredenziali($email);
                $VHome->impostaSuccesso('L\'operazione è avvenuta con successo. Ti è stata
                                        spedita una mail all\'indirizzo segnalato, controlla la casella di posta
                                        per recuperare la password.');
                return $VHome->getSuccesso();
                }

            $VHome->impostaAccessoNegato('Per effettuare il recupero della password devi cominciare la procedura dall\'inizio');
            return $VHome->getErrore();
            }
        else{
            $VHome->impostaAccessoNegato('L\'indirizzo email inserito non appartiene ad alcun utente.');
            return $VHome->getErrore();
            }
    	

        }
        

    /** 
     * Questa funzione invia una mail all'account segnalato dall'utente. Solo grazie a questa mail,
     * l'utente potrà attivarsi
     */
    public function inviaEmailCredenziali($email){
        global $config;
        $FUtente = USingleton::getInstance('FUtente');
        $send = USingleton::getInstance('UEmail');
        $view = USingleton::getInstance('VRegistrazione');
        $FRecupero = USingleton::getInstance('FRecupero');
		$tmp = $FUtente->search(array(array('email','=',$email)));
        $nome = $tmp[0]->nomeu;
        $username = $tmp[0]->nomeUtente;
        $tmp = $FRecupero->search(array(array('email','=',$email)));
        $codice = $tmp[0]->codiceConferma;
		$view->assign('codiceConferma', $codice);
        //$email = urlencode($email);
        $view->assign('email',$email);
        $view->assign('nome',$nome);
        $view->assign('username',$username);
        $view->assign('url',$config['url']['https']);
        $corpo = $view->getContenuto('email_recuperocredenziali');
        //$email = urldecode($email);
        $send->invia_email($email, $nome, 'Recupero credenziali di accesso', $corpo);
    }

    /**
     * Quando un utente invia il codice di attivazione e il codice fiscale, allora viene avviata la procedura
     * per il cambiamento della password (in pratica viene confermata la volontà dell'utente di cambiare la password).
     * @return string ritorna il fetch del template per il recupero della password
     * 
     */
    public function confermaRecupero(){
        $view = USingleton::getInstance('VRegistrazione');
        $VHome = USingleton::getInstance('VHome');
        $CHome = USingleton::getInstance('CHome');
        $FRecupero = USingleton::getInstance('FRecupero');
        $email = $view->getRequest('email');
        $codice = $view->getRequest('codiceConferma');
        $esito = $FRecupero->load($email);
        if($esito->codiceConferma == $codice){
            $session = USingleton::getInstance('USession');
            $session->impostaValore('email',$email);
            $session->impostaValore('codiceConferma',$codice);
            return $view->getContenuto('recuperoPassword');
            }
        $VHome->impostaAccessoNegato('Per effettuare il recupero della password devi cominciare la procedura dall\'inizio');
        return $VHome->getErrore();
        }
        

    /** 
     * Questa funzione modifica il valore della password di un utente, conoscendone
     * il codice fiscale. Il metodo, effettua di nuovo il controllo nella tabella richieste
     * per controllare di nuovo che l'utente abbia effettuato davvero la richiesta di cambio pwd.
     */
    public function cambia(){
        $session = USingleton::getInstance('USession');
        $FUtente = USingleton::getInstance('FUtente');
        $controlli = USingleton::getInstance('UControlli');
        $CHome = USingleton::getInstance('CHome');
        $VHome = USingleton::getInstance('VHome');
        $view = USingleton::getInstance('VRegistrazione');
        $FRecupero = USingleton::getInstance('FRecupero');
        $cookie = USingleton::getInstance('UCookie');
        if($cookie->checkCookie()==true){
            $email = $session->leggiValore('email');
            $codice = $session->leggiValore('codiceConferma');
            $esito = $FRecupero->load($email);
            $newPassword = $view->getRequest('password');
            $newPasswordC = $view->getRequest('passwordC');
            $con = $controlli->password($newPassword, $newPasswordC);
            if($esito->codiceConferma == $codice && $con==NULL){
                $FRecupero->delete($esito);
                $session->cancellaValore('codiceConferma');
                $utente = $FUtente->search(array(array('email','=',$email)));
                $utente[0]->password = $newPassword;
                $FUtente->update($utente[0]);
                $VHome->impostaSuccesso('L\'operazione è avvenuta con successo.');
                return $VHome->getSuccesso();}

            $VHome->impostaAccessoNegato('Impossibile cambiare la password. Ripeti la procedura dall\'inizio');
            return $VHome->getErrore();}
       else{
            return $VHome->getContenuto('cookieDisattivati');
       }
            
    }
    
        
   /** 
     * Controlla se l'utente è loggato
     * @return bool  true nel caso l'utente sia loggato (ma non necessariamente confermato)
     * false nel caso non sia loggato
     */
    public function getLoggato(){
    $session = USingleton::getInstance('USession');
    if($session->leggiValore('username') == true)
        return true;
    else
        return false;}

    /**    
     * Controlla se l'utente è attivato
     * @return bool  true nel caso l'utente sia attivato (e quindi anche loggato)
     * false nel caso in cui l'utente non sia attivato (che ai fini dell'applicazione,
     * equivale a dire che l'utente non è nemmeno loggato).
     */
    public function getAttivato(){
    $session = USingleton::getInstance('USession');
    if($session->leggiValore('attivato') == true)
        return true;
    else
        return false;}    
    
	/**
     * Invia un email contenente il codice di attivazione per un utente appena registrato
     * @global array $config
     * @param EUtente $utente
     * @return boolean
     */
    public function emailAttivazione(EUtente $utente) {
        global $config;
        $view=USingleton::getInstance('VRegistrazione');        
        $view->assegnaDatiOggetto($utente);
        $view->assign('email_webmaster',$config['email_webmaster']);
        $view->assign('url',$config['url']['http']);
        $corpo_email=$view->getcontenuto('email_attivazione');
        $email=USingleton::getInstance('UEmail');
        return $email->invia_email($utente->email,$utente->nomeu.' '.$utente->cognome,'Attivazione account calcetto',$corpo_email);
    }
    
	/**
     * 
     * Funzione che controlla i campi per la registrazione
     * @param array $dati � l'array che contiene i campi da controllare
     * @return array array di stringhe, rappresentative dell'errore
     */
    public function controllaRegistrazione($dati){
        $UControlli = USingleton::getInstance('UControlli');
        $errori[0] = $UControlli->nomCog($dati['nomeu']);
        $errori[1] = $UControlli->nomCog($dati['cognome']);
        $errori[2] = $UControlli->sesso($dati['sesso']);
        $errori[3] = $UControlli->comune($dati['residenza']);
        $errori[4] = $UControlli->username($dati['nomeUtente']);
        $errori[5] = $UControlli->data($dati['giorno'], $dati['mese'],$dati['anno']);        
        $errori[6] = $UControlli->password($dati['password'],$dati['Cpassword']);
        $errori[7] = $UControlli->email($dati['email'],$dati['Cemail']);
        return $errori;
	}
    
	/**
     * Smista le richieste ai vari metodi
     * @return mixed
     */
    public function smista() {
        $view=USingleton::getInstance('VCreazione');
        $VHome = USingleton::getInstance('VHome');
        $cookie  = USingleton::getInstance('UCookie');
        switch ($view->getTask()) {
            case 'modulo':
                if($this->getAttivato() == false)
                	return $this->modulo();
                else{
                    $VHome->impostaAccessoNegato('Sei già registrato, non puoi creare un altro account');
                    return $VHome->getErrore();} 
            case 'modifica':
                if($this->getAttivato() == false)
                	return $this->modifica();
                else{
                    $VHome->impostaAccessoNegato('Sei già registrato, non puoi creare un altro account');
                    return $VHome->getErrore();}             
            case 'riepilogo':
        		if($this->getAttivato() == false){
                	return $this->riepilogo();}
                else{
                    $VHome->impostaAccessoNegato('Sei già loggato.');
                    return $VHome->getErrore();}  
            case 'salva':
        		if($this->getAttivato() == false){
                	return $this->salva();}
                else{
                    $VHome->impostaAccessoNegato('Sei già loggato.');
                    return $VHome->getErrore();}
            case 'attivazione':
        		if($this->getAttivato() == false){
                	return $this->attivazione();}
                else{
                    $VHome->impostaAccessoNegato('Sei già attivato.');
                    return $VHome->getErrore();}
            case 'login':
         		if($this->getAttivato() == false){
                	return $this->login();}
                else{
                    $VHome->impostaAccessoNegato('Sei già loggato.');
                    return $VHome->getErrore('errore');}
            case 'logout':
            	return $this->logout();
            case 'moduloRecupero':
        		if($this->getAttivato() == false)
                    return $this->moduloRecupero();
                 else{
                    $VHome->impostaAccessoNegato('Sei loggato. Non hai bisogno di recuperare la password');
                    return $VHome->getErrore('errore');}
            case 'recupera':
        		if($this->getAttivato() == false)
                	return $this->recupera();
                else{
                    $VHome->impostaAccessoNegato('Sei loggato. Non hai bisogno di recuperare la password');
                    return $VHome->getErrore('errore');}
            case 'confermaRecupero':
        		if($this->getAttivato() == false)
                    return $this->confermaRecupero();
                else{
                    $VHome->impostaAccessoNegato('Sei loggato. Non hai bisogno di recuperare la password');
                    return $VHome->getErrore('errore');}
            case 'cambia':
        		if($this->getAttivato() == false)
                    return $this->cambia();
                else{
                    $VHome->impostaAccessoNegato('Sei loggato. Non hai bisogno di recuperare la password');
                    return $VHome->getErrore('errore');}							
            		  
          					
            		  
          	
            }
    }
    
    
}