<?php
/**
 * @access public
 * @package Controller
 */
class CProfilo{
	
	/**
	 * 
	 * Calcola e mostra tutte le statistiche di un utente 
	 */
	public function riepilogo(){
		$futente = USingleton::getInstance('FUtente');
		$view = USingleton::getInstance('VProfilo');
		$fpartecipanti = USingleton::getInstance('FPartecipanti');
		$session = USingleton::getInstance('USession');
		$fpartita = USingleton::getInstance('FPartita');
		$voto = USingleton::getInstance('EVoto');
	    $nomeu = $session->leggiValore('username');
		$utente = $futente->load($nomeu);
		$param = array(array('utente','=',$nomeu));
		$partecipanti = $fpartecipanti->search($param);
		if ($partecipanti != null)
			foreach($partecipanti as $item){
				$partita[] = $fpartita->load($item->id_partita);
			}
		else 
			$partita=array();
		$view->assign('utente',$utente);
		$view->assign('partita',$partita);
		if (!$partita){
			$count = 0;
			$mediag = 0;
			$mediav = 0;
		}
		else{
			$count = count($partecipanti);
			$mediav = $voto->mediaVoto($nomeu,$count);
			$mediag = $utente->gol/$count;
		}
		$view->assign('gol',$utente->gol);
		$view->assign('mediag',$mediag);
		$view->assign('count',$count);
		$view->assign('mediav',$mediav);
		return $view->display('profilo_riepilogo.tpl');
	}
	
	
	/**
	 * 
	 * Ritorna il tpl della form per la modifica dei 
	 * dati di registrazione
	 */
	public function modifica(){
	    $view = USingleton::getInstance('VProfilo');
	    $session = USingleton::getInstance('USession');
	    $futente = USingleton::getInstance('FUtente');
	    $user = $session->leggiValore('username');
	    $utente = $futente->load($user);
	    $view->assign('utente',$utente);
	    $view->impostaUrl();
	    $view->impostaDate('nascita');
        return $view->display('profilo_modulo.tpl');
    }
    
    
    /**
     * 
     * Modifica i dati di registrazione di un utente
     */
	public function update(){
	    $view = USingleton::getInstance('VProfilo');
	    $session = USingleton::getInstance('USession');
	    $futente = USingleton::getInstance('FUtente');
	    $VHome = USingleton::getInstance('VHome');
	    $dati = $view->getDati();
	    $user = $session->leggiValore('username');
	    $errori = $this->controllaRegistrazione($dati,$user);
		$esito = false;
	    foreach($errori as $value){
        	if($value != NULL)
            	$esito = true;
        }
	    if (!$esito){
	    	$utente = $futente->load($user);
	    	$utente->setCampi($dati);
	    	$futente->update($utente);
	    	$view->impostaUrl();
	    	$VHome->impostaSuccesso('modifiche effettuata con successo');
	    	return $VHome->display("successo_main.tpl");
	    }
	    else
	    $array = array();
            foreach ($errori as $value)
                if(isset ($value))
                    $array[]=$value;
            $view->assign('errori',$array);
	    	return $this->modifica();
    }
    
/**
     * 
     * Funzione che controlla i campi per la registrazione
     * @param array $dati � l'array che contiene i campi da controllare
     * @return array array di stringhe, rappresentative dell'errore
     */
    public function controllaRegistrazione($dati){
        $UControlli = USingleton::getInstance('UControlli');
        $FUtente = USingleton::getInstance('FUtente');
        $errori[0] = $UControlli->nomCog($dati['nomeu']);
        $errori[1] = $UControlli->nomCog($dati['cognome']);
        $errori[2] = $UControlli->sesso($dati['sesso']);
        $errori[3] = $UControlli->comune($dati['residenza']);
        $errori[5] = $UControlli->data($dati['giorno'], $dati['mese'],$dati['anno']);        
        $errori[6] = $UControlli->password($dati['password'],$dati['Cpassword']);
        $errori[7] = $UControlli->email($dati['email'],$dati['Cemail'],TRUE);
        $utenti = $FUtente->search();
        foreach ($utenti as $item){
   			if ($item->email == $dati['email'] && $item->nomeUtente!=$dati['nomeUtente'])  
            	$errori[8] = "L'email inserita è già stata utilizzata da un altro utente";
        }
        return $errori;
    }    
	
    /**
     * 
     * Carica la foto, esague il controllo, salva il path nel database e
     * la foto nella cartella images
     */
    public function modificaFoto(){
    	$sessione = USingleton::getInstance('USession');
    	$futente = USingleton::getInstance('FUtente');
    	$vhome = USingleton::getInstance('VHome');
    	$user = $sessione->leggiValore('username');
    	$utente = $futente->load($user);
    	$fotoVecchia= $utente->foto;
    	$esito = $this->controllaFoto();
    	if ($esito){
    		$vhome->impostaAccessoNegato($esito);
            return $vhome->getErrore();
    	}
    	$path = $_FILES['fotoUtente']['name'];
    	$utente->foto = './templates/main/templates/images/'.$path;
    	$esito = $futente->update($utente);
    	if (!$esito){
	    	$vhome->impostaAccessoNegato('C\'&egrave; stato un errore. Riprova');
            return $vhome->getErrore();
	    }
	    if ($fotoVecchia)
	    	if ($fotoVecchia=="./templates/main/templates/images/default.jpg")
	    		unlink($fotoVecchia);
	    $esito = move_uploaded_file($_FILES['fotoUtente']['tmp_name'], './templates/main/templates/images/'.$_FILES['fotoUtente']['name']);    		
	    if (!$esito){
 			$vhome->impostaUrl();
    		$vhome->impostaAccessoNegato("C'&egrave: stato un errore nel caricamento della foto. Riprova");
            return $vhome->getErrore();	    	
	    }
	    $vhome->impostaUrl();
	    $vhome->impostaSuccesso('Foto caricata con successo');
	    return $vhome->getSuccesso();
    }
    
    /**
     * 
     * Controlla che le dimesioni e il formato siano corrette oltre che 
     * contrllare se $_FILES["fotoCampo"]['error'] sia uguale a 0 
     */
    public function controllaFoto(){
    	$mess = NULL;
    	if($_FILES['fotoUtente']['error'] == 4){} //se il campo error &egrave = 4 allora in ql campo nn &egrave stata caricata alcuna foto
			else if($_FILES["fotoUtente"]['type'] !='image/jpeg' && $_FILES["fotoUtente"]['type'] !='image/gif' && $_FILES["fotoUtente"]['type'] !='image/png'  ){
				$mess= $mess."il formato della foto non è corretto. <br>La foto non &egrave; stata inserita. Riprova ";
				return $mess;
				}
			else{  //controllo le dimensioni del file. La dimensione max definita in php.ini &egrave di 2 MB=2097152 Byte
					if($_FILES["fotoUtente"]['size'] > 2097152){
						$mess="la foto &grave; troppo grande. <br> La foto non &egrave; stata inserita. Riprova!";
						return $mess;
					}	
					else if($_FILES["fotoUtente"]['error'] != 0){
						$mess="&egrave; stato riscontrato un errore nella foto. Riprova";
						return $mess;
					}
		}
		return $mess;
    }
	
    /**
     * Smista le richieste ai vari metodi
     * @return mixed
     */
	public function smista(){
		$VHome = USingleton::getInstance('VHome');
		$cookie = USingleton::getInstance('UCookie');
		$view=USingleton::getInstance('VProfilo');
		$CReg = USingleton::getInstance('CRegistrazione');
        switch ($view->getTask()) {
        	case 'riepilogo':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                    return $this->riepilogo();
                else{
                    $VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                    return $VHome->getErrore();}	    
			case 'modifica':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
            	}
            	if($CReg->getLoggato() == true)
            		return $this->modifica();
            	else{
            		$VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                	return $VHome->getErrore();}
			case 'modificaFoto':
        		if($cookie->checkCookie()==false){
            		return $VHome->getContenuto('cookieDisattivati');
            	}
            	if($CReg->getLoggato() == true)
            		return $this->modificaFoto();
            	else{
                	$VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                	return $VHome->getErrore();}
			case 'update':
        		if($cookie->checkCookie()==false){
            		return $VHome->getContenuto('cookieDisattivati');
           		}
           		if($CReg->getLoggato() == true)
           			return $this->riepilogo();
            	else{
                	$VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                	return $VHome->getErrore();}
		}
	}
	
	
}