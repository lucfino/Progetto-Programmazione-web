<?php
/**
 * @access public
 * @package Controller
 */
class CCreazione{
	
	/**
	 * 
	 * Ritorna il tpl relativo al modulo di creazione di 
	 * una partita
	 */
	public function modulo(){
	    $view = USingleton::getInstance('VCreazione');
	    $campi = USingleton::getInstance('FCampo');
	    $tmp = $campi->search();
	    $campo[] = '-campo-';
	    foreach ($tmp as $tmp1){
	    	$campo[] = $tmp1->nome;
	    }
	    $view->impostaCampi($campo);
	    $view->impostaUrl();
	    $view->impostaDate('ricerca');
	    $view->impostaOra();
		if ($view->getRequest('aj')==1)
    		return $view->display('creazione_modulo_partita.tpl');
    	else
    		return $view->getContenuto('modulo_partita');	    		
    	}
    
   /**
	 * 
	 * Ritorna il tpl relativo al modulo di creazione di 
	 * una partita
	 */
	public function modifica(){
	    $view = USingleton::getInstance('VCreazione');
	    $campi = USingleton::getInstance('FCampo');
	    $tmp = $campi->search();
	    $campo[] = '-campo-';
	    foreach ($tmp as $tmp1){
	    	$campo[] = $tmp1->nome;
	    }
	    $view->impostaCampi($campo);
	    $view->impostaUrl();
	    $view->impostaDate('ricerca');
	    $view->impostaOra();
	    $dati = $view->getDatiRegistrazione();
	    $view->assegnaDatiRiepilogo($dati,false);
		if ($view->getRequest('aj')==1)
    		return $view->display('creazione_modulo_partita.tpl');
    	else
    		return $view->getContenuto('modulo_partita');	    		
    	}
    
    /**
     * 
     * Restituisce il tpl relativo alla schermata di riepilogo
     * dei dati inseriti nella creazione  se sono corretti
     * altrimenti ritorna al modulo di creazione
     */
    public function riepilogo(){
	    $view = USingleton::getInstance('VCreazione');
	    $fsquadra = USingleton::getInstance('FSquadra');
	    $dati = $view->getDatiRegistrazione();
	    $errori = $this->controllaCampi($dati);
	    $esito = false;
	    $allarm1 = '';
	    $allarm2 = '';
        foreach($errori as $value){
        	if($value != NULL)
            	$esito = true;
        }
        if(!$esito){           	
            $view->assegnaDatiRiepilogo($dati);
            $view->impostaUrl();
        	if ($view->getRequest('aj')==1)
    			return $view->display('creazione_riepilogo_partita.tpl');
    		else
    			return $view->getContenuto('riepilogo_partita');	    		
    		}
     	else{            
            return $this->modifica();
            }
        }
  /**
   * 
   * Salva i dati di creazione sul db e restituisce il tpl 
   * per gli inviti
   */
   public function salva(){
	    $view = USingleton::getInstance('VCreazione');
	    $partita = USingleton::getInstance('EPartita');
	    $fpartita = USingleton::getInstance('FPartita');
	    $fsquadra = USingleton::getInstance('FSquadra');
	    $session = USingleton::getInstance('USession');
	    $dati = $view->getDatiRegistrazione();
	    $dati['username'] = $session->leggiValore('username');
	    $partita->setCampi($dati);
	    $esiste1 = $fsquadra->esisteSquadra($partita->_squadra1->nome);
	   	$esiste2 = $fsquadra->esisteSquadra($partita->_squadra2->nome);	    
	    if (!$esiste1){
	    	$fsquadra->store($partita->_squadra1);
	    }
   		if (!$esiste2){
	    	$fsquadra->store($partita->_squadra2);
	    }
	    $fpartita->store($partita);
	    $view->assign('idp',$partita->id);
	    $view->impostaUrl();
	    if ($view->getRequest('aj')==1)
    		return $view->display('creazione_inviti_partita.tpl');
    	else
    		return $view->getContenuto('inviti_partita');	
    }
   
    /**
     * 
     * Controlla che le email siano scritte in modo corretto
     * e spedisce gli inviti
     */
	public function spedisci(){
    	$view = USingleton::getInstance('VCreazione');
    	$VHome = USingleton::getInstance('VHome');
	    $dati=$view->getDatiEmail();
	    $esito = $this->emailInviti($dati);
	    if ($esito){
	    	$view->assign('idp',$dati['idp']);
	    	$view->impostaUrl();
	    	if ($view->getRequest('aj')==1)
    		return $view->display('creazione_inviti_partita.tpl'); 
    	else
    		return $view->getContenuto('inviti_partita');		
	    }
	    else{
        $view->impostaUrl();
        $VHome->impostaSuccesso('Tutti gli inviti sono stati spediti');
        if ($view->getRequest('aj')==1)
    		return $VHome->display('successo_main.tpl');
    	else
    		return $view->getSuccesso();	
    }
}
    
    
   /**
     * Invia un email di invito per la partita creata a tutti gli invitati
     *
     * @global array $config
     * @param array $array
     * @return boolean
     */
    public function emailInviti($array) {
        global $config;
        $UControlli = USingleton::getInstance('UControlli');
        $partita=USingleton::getInstance('FPartita');
        $view=USingleton::getInstance('VCreazione');
        $futente=USingleton::getInstance('FUtente');
        $id = $array['idp'];
        $nomepartita=$partita->load($id);
        $view->assegnaDatiOggetto($nomepartita);
        $view->assign('email_webmaster',$config['email_webmaster']);
        $view->impostaUrl();
        $esito = false;
        foreach ($array as $utente){
        	if($utente != '' && $utente != $id){
        		if (!($UControlli->emailRichieste($utente))){        		
        			$corpo_email=$view->getcontenuto('email_inviti');
        			$email = new UEmail;
        			$email->invia_email($utente,'','Invito partita di calcetto',$corpo_email);
        			
        		}
        		else{
        			if ($futente->esisteUtente($utente)){
        				$tmp=USingleton::getInstance('FUtente');
        				$view->assign('nome_utente',' '.$utente);
        				$nomeutente=$tmp->load($utente);
        				$corpo_email=$view->getcontenuto('email_inviti_registrato');
        				$email = new UEmail;
        				$email->invia_email($nomeutente->email,$nomeutente->nomeu.' '.$nomeutente->cognome,'Invito partita di calcetto',$corpo_email);
        			}
        			else
        				$esito=true;	
        		}
        	}
        }
        return $esito;
    }
    
        
    /**
     * 
     * Funzione che controlla i campi per la creazioni
     * @param array $dati � l'array che contiene i campi da controllare
     * @return array array di stringhe, rappresentative dell'errore
     */
    public function controllaCampi($dati){
        $UControlli = USingleton::getInstance('UControlli');
        $errori[0] = $UControlli->nomP($dati['nomep']);
        $errori[1] = $UControlli->nomC($dati['_campo']);
        $errori[2] = $UControlli->nomS($dati['_squadra1']);
        $errori[3] = $UControlli->nomS($dati['_squadra2']);
        $errori[4] = $UControlli->data($dati['giorno'], $dati['mese'],$dati['anno']);
        $errori[6] = $UControlli->ora($dati['ore'],$dati['minuti']);
        if ($errori[4] == '' && $errori[6])
        	$errori[5] = $UControlli->isMaggioreDataAttuale($dati);
        $errori[8] = $UControlli->testo($dati['note']);
        return $errori;

    }
    
    


    /**
     * Smista le richieste ai vari metodi
     * @return mixed
     */
    public function smista() {
        $view = USingleton::getInstance('VCreazione');
        $CReg = USingleton::getInstance('CRegistrazione');
        $VHome = USingleton::getInstance('VHome');
        $cookie = USingleton::getInstance('UCookie');
        switch ($view->getTask()) {
            case 'modulo':
            	if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                	return $this->modulo();
                else{
                    $VHome->impostaAccessoNegato('Non sei registrato, non puoi creare partite');
                    return $VHome->getErrore();}   
            case 'riepilogo':
                if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                	return $this->riepilogo();
                else{
                    $VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                    return $VHome->getErrore();}   
            case 'salva':
                if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                	return $this->salva();
                else{
                    $CHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                    return $VHome->getErrore();}   
            case 'spedisci':
            	if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                	return $this->spedisci();
                else{
                    $VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                    return $VHome->getErrore();}  
            case 'modifica':
            	if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                	return $this->modifica();
                else{
                    $VHome->impostaAccessoNegato('Non sei registrato, non puoi creare partite');
                    return $VHome->getErrore();}          	
        }
    }
}