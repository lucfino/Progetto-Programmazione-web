<?php
/**
 * @access public
 * @package Controller
 */
class CCerca{	
	
	/**
	 * Mostra tutte la tabella di tutte partite ordinate per nome
	 */
	public function tutte(){
		$param=array();
		$ordinamento= 'nomep ASC';
		return $this->impostaPartite($param,$ordinamento);
	}
	
	/**
	 * Mostra la tabella di tutte le partite giocate
	 */
	public function giocate(){
		$param = array(array('disputata','=',1));
		$ordinamento = 'datap,orap DESC';	
		return $this->impostaPartite($param,$ordinamento);
	}
	
	/**
	 * Mostra tutte le partite ancora da giocare
	 */
	public function da_giocare(){		
		$param = array(array('disputata','=',0));
		$ordinamento = 'datap,orap';
		return $this->impostaPartite($param,$ordinamento);
	}
	
	/**
	 * Imposta la tabella da mostrare
	 * @param array $parametri
	 * @param strung $ordinamento
	 * @param string $limit
	 */
	public function impostaPartite($parametri = array(), $ordinamento = '', $limit = ''){
		$view = USingleton::getInstance('VCerca');
		$fpartite = USingleton::getInstance('FPartita');
		$VHome = USingleton::getInstance('VHome');
		$ordine=$view->getRequest('ordine');
		if ($ordine!='')
			$ordinamento=$ordine;
		$risultato = $fpartite->search($parametri,$ordinamento,$limit);
		$task=$view->getTask();
		$view->assign('task',$task);
		$view->assign('partite',$risultato);
		$view->impostaUrl();
		return $view->getContenuto('partite');
	}
	
	/**
	 * Mostra le partite a cui partecipa una squadra
	 */
	public function cerca(){
		$view = USingleton::getInstance('VCerca');
		$fpartita = USingleton::getInstance('FPartita');
		$fsquadra=USingleton::getInstance('FSquadra');
		$VHome = USingleton::getInstance('VHome');
		$squadra=$view->getRequest('squadra');
		$squadraO=$fsquadra->search(array(array('nome','=',$squadra)));
		if  ($squadraO){
			$id=$squadraO[0]->id;
			$partiteA=$fpartita->search(array(array('id_squadra1','=',$id)));
			$partiteR=$fpartita->search(array(array('id_squadra2','=',$id)));
			if (!$partiteA)
				$partite=$partiteR;
			else{
				if (!$partiteR)
					$partite=$partiteA;
				else
					$partite=array_merge($partiteA,$partiteR);
			}
		}
		else 
			$partite = array();
		$task=$view->getTask();
		$view->assign('task',$task);
		$view->assign('partite',$partite);
		$view->impostaUrl();
		return $view->getContenuto('squadra');
	}
	
	/**
	 * Mostra il riepilogo della partita
	 */
	public function riepilogo(){
		$view = USingleton::getInstance('VCerca');
		$fpartita = USingleton::getInstance('FPartita');
		$fpartecipanti = USingleton::getInstance('FPartecipanti');
		$session = USingleton::getInstance('USession');
		$user = $session->leggiValore('username');
		$id = $view->getRequest('idp');
		$partita = $fpartita->load($id);
		$view->assegnaDatiRiepilogo($partita);
		$this->aggiungiLink($partita,$user);
		$view->assign('id',$partita->id);
		$view->assign('risultato',$partita->risultato);
		$partecipa = false;	
		if ($fpartecipanti->partecipa($id,$user) || $user == $partita->_username->nomeUtente){
			$partecipa = true;
		}
		$part = $fpartecipanti->search(array(array('id_partita','=',$id)));
		if ($part){
			foreach ($part as $item){
				if ($item->squadra == $partita->_squadra1->nome)
					$dati1[] = $item->utente;
				else 
					$dati2[] = $item->utente;	
			}
		}
		if (isset($dati1) && isset($dati2)){
			$view->assign('dati1',$dati1);
			$view->assign('dati2',$dati2);
			$view->assign('partecipa',$partecipa);
		}
		$view->impostaUrl();
		return $view->getContenuto('riepilogo');
	}
	
	/**
	 * Data una partita e uno user fa apparire il link di compila statistiche
	 * solo se la data della partita &egrave passata e se $user $egrave; l'utente che ha creato la partita
	 * @param EPartita $partita
	 * @param string $user
	 */
	public function aggiungiLink($partita,$user){
		$time = USingleton::getInstance('UControlli');
		$view = USingleton::getInstance('VCerca');
		$tmp=explode("-",$partita->datap);
		$dati['anno']= $tmp[0];
		$dati['mese']= $tmp[1];
		$dati['giorno']= $tmp[2];
		$tmp=explode(":",$partita->orap);
		$dati['ore']= $tmp[0];
		$dati['minuti']= $tmp[1];
		$passato = $time->isMaggioreDataAttuale($dati);
		if ($passato && $partita->disputata == 0 && $partita->_username->nomeUtente == $user){
			$link = "<a href = index.php?controller=partite&task=moduloCompila&idp={$partita->id}>clicca qui per compliare le statistiche della partita</a>";
			$view->assign('link',$link); 
		}
	}
	
	/**
	 * Calcola il risultato della partita
	 * @param EPartita $partita
	 * @param array $gol
	 */
	public function risultato($partita,$gol){
		$controlli = USingleton::getInstance('Ucontrolli');
		$view = USingleton::getInstance('VCerca');
		$fpartita = USingleton::getInstance('FPartita');
		foreach ($gol as $item){
		$totale = $controlli->gol($item);
		if ($totale != NULL){
			return false;
			} 
		}
		$risultato = $view->getRisultato($gol);
		$partita->risultato = $risultato;
		$fpartita->update($partita);
		return $risultato;	
	}
	
	/**
	 * Controlla se la form &egrave; completa e aggiunge i gol ad ogni utente registrato
	 * @param array $part
	 * @param array $gol
	 */
	public function gol($part,$gol){
		$futente = USingleton::getInstance('FUtente');
		foreach($part as $item){
			if($item == ''){
				return false;
			}
		}
		$i = 1;
		foreach($part as $item){
			if ($futente->esisteUtente($item)){
				$utente = $futente->load($item);
				$futente->aggiornaGol($utente,$gol[$i]);
				$i++;
			}	
		}
		return true;
	}
	
	/**
	 * Salva i partecipanti di una partita in una squadra
	 * @param EPartita $partita
	 * @param array $part
	 * @param string $squadra
	 */
	public function salvaPartecipanti($partita,$part,$squadra){
		$futente = USingleton::getInstance('FUtente');
		$fpartecipanti = USingleton::getInstance('FPartecipanti');
		$partecipanti = USingleton::getInstance('EPartecipanti');
		$partecipanti->_partita = $partita;
		$partecipanti->_squadra = $squadra;
		foreach($part as $item){
			if(!$futente->esisteUtente($item))
				$partecipanti->_utenti[] = $item;	
		
			else
				$partecipanti->_nomiUtenti[] = $futente->load($item);
		}
		$fpartecipanti->store($partecipanti);
	}
	
	/**
	 * Mostra il modulo per compilare le statistiche della partita
	 */
	public function modulocompila(){
		$view = USingleton::getInstance('VCerca');
		$id = $view->getRequest('idp');
		$view->assign('idp',$id);
		$view->impostaUrl();
		return $view->getContenuto('compila');
	}
	
	/**
	 * Controlla se hai inserito correttamente tutti i partecipanti e i gol;
	 * salva i partecipanti.
	 */
	public function compila(){
		$view = USingleton::getInstance('VCerca');
		$fpartita = USingleton::getInstance('FPartita');
		$fsquadra = USingleton::getInstance('FSquadra');
		$id = $view->getRequest('idp');
		$partita = $fpartita->load($id);
		$gol = $view->getDatiCompila3();
		$part1 = $view->getDatiCompila1();
		$part2 = $view->getDatiCompila2();
		$part = $view->getDatiCompila4();
		$this->risultato($partita, $gol);
		$partita->_squadra1->giocate += 1;
		$partita->_squadra2->giocate += 1;
		$risultato=explode("-",$partita->risultato);
		$partita->_squadra1->golFatti += $risultato[0];
		$partita->_squadra1->golSubiti += $risultato[1];
		$partita->_squadra2->golSubiti += $risultato[0];
		$partita->_squadra2->golFatti += $risultato[1];
		if ($risultato[1]<$risultato[0]){
			$partita->_squadra1->vittorie += 1;
			$partita->_squadra2->sconfitte += 1;
		}
		if ($risultato[1]>$risultato[0]){
			$partita->_squadra2->vittorie += 1;
			$partita->_squadra1->sconfitte += 1;
		}
		if ($risultato[1]==$risultato[0]){
			$partita->_squadra1->pareggi += 1;
			$partita->_squadra2->pareggi += 1;
		}
		$fsquadra->update($partita->_squadra1);
		$fsquadra->update($partita->_squadra2);
		$view->assign('idp',$partita->id);
		if (!$this->gol($part,$gol)){
			$view->assign('errore','C\'&egrave; stato un errore. Riprova');
			return $view->getContenuto('compila');
		}
		else{
			$fpartita->disputata($partita);
			$this->salvaPartecipanti($partita,$part1,$partita->_squadra1);
			$this->salvaPartecipanti($partita,$part2,$partita->_squadra2);
			return $this->riepilogo();
		}
	}
	
	/**
     * Smista le richieste ai vari metodi
     * @return mixed
     */
    public function smista() {
        $view=USingleton::getInstance('VCerca');
        $VHome = USingleton::getInstance('VHome');
        $cookie = USingleton::getInstance('UCookie');
        $CReg = USingleton::getInstance('CRegistrazione');
        switch ($view->getTask()) {
        	default:
        		return $this->tutte();
        	case 'giocate':
        		return $this->giocate();
        	case 'da_giocare':
        		return $this->da_giocare();
           	case 'riepilogo':
        		if($cookie->checkCookie()==false)
                	return $VHome->getContenuto('cookieDisattivati');
                else	
        			return $this->riepilogo();
        	case 'moduloCompila':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                    return $this->modulocompila();
                else{
                    $VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                    return $VHome->getErrore();}   
        	case 'cerca':
        		return $this->cerca();	
        	case 'compila':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                    return $this->compila();
                else{
                    $VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                    return $VHome->getErrore();}   							
        }
    }
	
	
        		
	
	
	
	
	
	
	
	
}
?>