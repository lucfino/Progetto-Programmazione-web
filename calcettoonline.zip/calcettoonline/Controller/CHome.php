<?php
/**
 * @access public
 * @package Controller
 */
class CHome {
    /**
     * Imposta la pagina
     */
    public function impostaPagina () {
    	$VHome= USingleton::getInstance('VHome');
    	$session = USingleton::getInstance('USession');
    	$CReg = USingleton::getInstance('CRegistrazione');
    	$cookie = USingleton::getInstance('UCookie');
    	
    	$username = $session->leggiValore('username');
        if($username != ''){
          $ban = $CReg->checkBan($username);
        	if($ban == '1'){
          		$cookie->eliminaCookie('PHPSESSID');
          		return false;
        	}
        }
        $VHome->impostaUrl();    
        $this->ciaoUtente();
        $this->setMenu();
        $cookie->setCookie();    
        $contenuto=$this->smista();
    	if($contenuto != false){
            $VHome->impostaContenuto($contenuto);
            $VHome->inserisciContenuto();
            if($session->leggiValore('admin')!=1){
                $VHome->mostraPagina();}
            else{
                $controller = $VHome->getRequest('controller');
                if($controller == 'amministratore')
                    $VHome->mostraPaginaAdmin();
                else{
                    $VHome->setRequest('controller','amministratore');
                    $VHome->setRequest('task','');
                    $this->impostaPagina();
                	}
                }
            }
    }
    
    
 	/**
     * 
     * La funzione imposta il menu in alto, in base al fatto che l'utente sia loggato o meno
     */
    public function setMenu(){
        $VHome = USingleton::getInstance('VHome');
        $session = USingleton::getInstance('USession');
        if($session->leggiValore('username') != false){
        	$VHome->assign('username',$session->leggiValore('username'));
            $VHome->impostaMenu('registrato');}
        else
            $VHome->impostaMenu('ospite');
        if($session->leggiValore('admin') == 1){
            $VHome->assign('username',$session->leggiValore('username'));
            $VHome->impostaMenu('admin');}
        }
    /**
     *
     * La funzione nel caso l'utente è loggato visualizza "ciao nomeutente"o
     */
    public function ciaoUtente(){
        
        $VHome = USingleton::getInstance('VHome');
        $session = USingleton::getInstance('USession');
        $utente=$session->leggiValore('username');
        if($utente == '') $utente=null;
        $VHome->assign('ciaoUtente',$utente);

        }
    
 /**
     * 
     * La funzione ritorna una vista della home, in base al fatto che l'utente sia loggato
     * o meno
     * @return mixed Ritorna il risultato del fetch su uno dei template della home
     */
    public function ritornaHome(){
        $VHome = USingleton::getInstance('VHome');
        $VReg = USingleton::getInstance('VRegistrazione');
        $session = USingleton::getInstance('USession');
        $VHome->impostaUrl();
        if($session->leggiValore('attivato') != false){
             $this->assegnaPartite();
             return $VHome->getContenuto('default');}
        else{
            if($session->leggiValore('username') != false)
                    return $VReg->getContenuto('attivazione');
            $this->assegnaPartite();        
            return $VHome->getContenuto('default');
            }
        }    
    
    /**
     * 
     * Assegna a smarty l'elenco delle 
     * ultime 10 partite
     */
    public function assegnaPartite(){    
    	$view = USingleton::getInstance('VHome');
    	$fpartite = USingleton::getInstance('FPartita');
		$parametri=array();
		$ordinamento = 'id DESC';
		$limit = '10';
		$risultato = $fpartite->search($parametri,$ordinamento,$limit);
		$view->assign('partite',$risultato);
    }  
    
    /**
     * 
     * Assegna a smarty l'elenco di tutti i campi
     */
	public function campi(){
    	$fcampo = USingleton::getInstance('FCampo');
    	$vhome = USingleton::getInstance('VHome');
    	$parametri=array();
    	$ordinamento = $vhome->getRequest('ordine');
    	$campi = $fcampo->search($parametri,$ordinamento);
    	$vhome->assign('campi',$campi);
    	return $vhome->getContenuto('campi');    	
    }
    

    /**
     * Smista le richieste ai vari controller
     * @return mixed
     */
    public function smista() {
    	USingleton::getInstance('USession');
        $view = USingleton::getInstance('VHome');
        $sessione = USingleton::getInstance('USession');
        $cookie = USingleton::getInstance('UCookie');  
        $sessioneAttiva = $sessione->checkSessioneAttiva();
        $controller = $view->getController();
        if($sessioneAttiva != false){
        	$CRegistrazione = USingleton::getInstance('CRegistrazione');
        	switch ($view->getController()) {
        		case 'creazione':
        			$CCreazione=USingleton::getInstance('CCreazione');
                	return $CCreazione->smista();
        		case 'campi':
        	    	return $this->campi();
        		case 'istruzioni':
        			$view->impostaUrl();
        			return $view->getContenuto('istruzioni');	
        		case 'partite':
        			$CCerca=USingleton::getInstance('CCerca');
                	return $CCerca->smista();
        		case 'profilo':
        			$CProfilo = USingleton::getInstance('CProfilo');
        			return $CProfilo->smista(); 
        		case 'classifiche':
        			$CClassifiche = USingleton::getInstance('CClassifiche');
        			return $CClassifiche->smista();	 
        		case 'registrazione':
        			$CRegistrazione = USingleton::getInstance('CRegistrazione');
        			return $CRegistrazione->smista();
        		case 'amministratore':
        			$CAdmin = USingleton::getInstance('CAmministratore');
                   	return $CAdmin->smista();
                case 'voti':
        			$CVoti = USingleton::getInstance('CVoti');
        			return $CVoti->smista(); 
        		case 'ajax':
        			$CAjax = USingleton::getInstance('CAjax');
        			return $CAjax->smista();	   		
        		default:
        			if (!file_exists('./includes/config.inc.php')){
        				$install = USingleton::getInstance('CInstalla');
        				return $install->smista();
        			}
        			else 
        				return $this->ritornaHome();  
        	}
    	}
    	else
    	{
        	$cookie->eliminaCookie('sessione',"/");
        	$sessione->distruggiSessione();
            $view->impostaAccessoNegato('Sessione scaduta');
            return $view->getErrore();
    	}
	}
	
	
}
    
?>