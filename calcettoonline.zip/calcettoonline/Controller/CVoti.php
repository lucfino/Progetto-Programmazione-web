<?php

/**
 * @access public
 * @package Controller
 */

class CVoti {
	
	/**
	 * 
	 * Dato l'id della partia inviato tramite request, 
	 * cerca tutti i voti di quella partita e li assegna 
	 * a smarty insieme ai partecpanti della stessa
	 */
	public function modulo(){
		$view = USingleton::getInstance('VVoti');
		$fvoto = USingleton::getInstance('FVoto');
		$fpartita = USingleton::getInstance('FPartita');
		$fpartecipanti = USingleton::getInstance('FPartecipanti');
		$idp = $view->getRequest('idp');
		$partita = $fpartita->load($idp);
		$ordine = 'id DESC';
		$param1 = array(array('id_partita','=',$idp),array('squadra','=',$partita->_squadra1->nome));
		$param2 = array(array('id_partita','=',$idp),array('squadra','=',$partita->_squadra2->nome));
		$commenti = $fvoto->search(array(array('id_partita','=',$idp)),$ordine);
		$view->assign('commenti',$commenti);
		$partecipanti1 = $fpartecipanti->search($param1);
		$partecipanti2 = $fpartecipanti->search($param2);
		$view->assign('partita',$partita);
		$view->assign('partecipanti1',$partecipanti1);
		$view->assign('partecipanti2',$partecipanti2);
		$view->impostaUrl();
       	return $view->getContenuto('riepilogo');
	}
	
	/**
	 * 
	 * Aggiunge un commento al db se i dati inviati sono
	 * corretti altrimenti ritorna la pagina precedente
	 */
	public function aggiungi(){
		$view = USingleton::getInstance('VVoti');
		$voto = USingleton::getInstance('EVoto');
		$fvoto = USingleton::getInstance('FVoto');
		$session = USingleton::getInstance('USession');
		$fpartita = USingleton::getInstance('FPartita');
		$dati = $view->getDatiCommento();
		$errori = $this->controllaCampi($dati);
		$esito = false;
		foreach($errori as $value){
        	if($value != NULL)
            	$esito = true;
        }
		if (!$esito){
			$user = $session->leggiValore('username');
			$voto->setCampi($dati[1],$dati[2],$user,$dati[0],$dati[3]);
			$fvoto->store($voto);
		}
		else{
			$array = array();
            foreach ($errori as $value)
                if(isset ($value))
                    $array[]=$value;            
            $view->assign('errori',$array);
		}		
        return $this->modulo();
	}
	
	/**
	 * 
	 * Controlla se i dati inviati nella form voti sono corretti
	 * @param array $dati
	 * @return array $errori
	 */
	public function controllaCampi($dati){
		$UControlli = USingleton::getInstance('UControlli');
		$futente = USingleton::getInstance('FUtente');
		$fpartecipanti = USingleton::getInstance('FPartecipanti');
		$session = USingleton::getInstance('USession');
        $errori[0] = $UControlli->username($dati[0],true);
        $errori[1] = NULL;
        $nome = $session->leggiValore('username');
        if (!$fpartecipanti->partecipa($dati[3],$dati[0]))
        	$errori[1] = "l'utente non partecipa alla partita";
        	else if ($nome==$dati[0])
        		$errori[1] = "Non puoi dare il voto a te stesso";
        $errori[2] = $UControlli->voto($dati[1]);
        $errori[3] = $UControlli->testo($dati[2]);
        return $errori;

    }
	
    /**
     * Smista le richieste ai vari metodi
     * @return mixed
     */
	public function smista(){
		$VHome = USingleton::getInstance('VHome');
		$cookie = USingleton::getInstance('UCookie');
		$view = USingleton::getInstance('VVoti');
		$CReg = USingleton::getInstance('CRegistrazione');
        switch ($view->getTask()) {
        	case 'aggiungi':
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                    return $this->aggiungi();
                else{
                    $VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                    return $VHome->getErrore();
                }
        	default:
        		if($cookie->checkCookie()==false){
                	return $VHome->getContenuto('cookieDisattivati');
                }
                if($CReg->getLoggato() == true)
                    return $this->modulo();
                else{
                    $VHome->impostaAccessoNegato('L\'operazione non ti è consentita, devi effettuare il login');
                    return $VHome->getErrore();
                }
	    	}
	    
	}
	
	
}