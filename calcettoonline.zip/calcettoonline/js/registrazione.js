reg=new Object();

reg.ajax=compatibilita();

/**
 * Fa una richiesta GET http tramite ajax al server
 *  e mette il risultato nel div rappresentato dall'id contente
 */
reg.modulo=function(){
    
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=reg.ajax.responseText;              
        }
    }
    this.ajax.open("POST","?controller=registrazione&task=modulo&aj=1",true);
    this.ajax.send();
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
reg.riepilogo=function(){
	
	var formname = document.getElementById('form_reg').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=reg.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
reg.modifica=function(){
	
	var formname = document.getElementById('form_reg_mod').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=reg.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
reg.salva=function(){
	
	var formname = document.getElementById('form_reg_salva').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=reg.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

/**
 * Fa una richiesta GET http tramite ajax al server
 *  e mette il risultato nel div rappresentato dall'id contente
 */
reg.modulorecupero=function(){
    
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=reg.ajax.responseText;              
        }
    }
    this.ajax.open("POST","?controller=registrazione&task=moduloRecupero&aj=1",true);
    this.ajax.send();
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
reg.recupera=function(){
	
	var formname = document.getElementById('mail_rec').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=reg.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
reg.cambia=function(){
	
	var formname = document.getElementById('dati').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=reg.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}