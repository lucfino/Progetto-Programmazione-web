profilo=new Object();

profilo.ajax=compatibilita();

/**
 * Fa una richiesta GET http tramite ajax al server
 *  e mette il risultato nel div rappresentato dall'id contente
 */
profilo.mostra=function(){    
	
    var utente = document.getElementById('user').value;
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById("content");
        	cont.innerHTML=profilo.ajax.responseText;
        		
        }
    }
    this.ajax.open("GET","?controller=profilo&task=riepilogo&aj=1&utente="+utente,true);
    this.ajax.send();
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
profilo.modifica=function(){
	
	var formname = document.getElementById('form_pro').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=profilo.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
profilo.update=function(){
	
	var formname = document.getElementById('form_pro_up').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=profilo.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

/**
 * Se &egrave; gi&agrave; presente un div con id field lo cancella;
 * fa una richiesta GET http tramite ajax al server
 *  e mostrando il risultato nel div field
 */
profilo.riepilogo=function(idp){
     
	var a = document.getElementById('field');
	if (a != undefined){
		if (a.parentNode.id == 'prova'+idp){
			a.parentNode.removeChild(a);
			return;
		}
		else
			a.parentNode.removeChild(a);
		}
	
		this.ajax.onreadystatechange = function(){
		if(this.readyState == 4 && this.status == 200 ){       	
			var cont=document.getElementById('prova'+idp);
			var field = document.createElement('field');
			field.id = 'field';
			field.innerHTML=profilo.ajax.responseText; 
        	cont.appendChild(field);
		}
		}
		this.ajax.open("GET","?controller=ajax&task=riepilogo_partite&idp="+idp,true);
		this.ajax.send();
}