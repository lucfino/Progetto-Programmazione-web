partite=new Object();

/**
 * Crea l'oggetto ajax a seconda del browser.
 */
partite.compatibilita=function(){

  var xmlhttp;
  if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
    else
  {// code for IE6, IE5
     xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlhttp;
}

partite.ajax=partite.compatibilita();

/**
 * Fa una richiesta GET http tramite ajax al server
 *  e mette il risultato nel div rappresentato dall'id contente
 */
partite.riepilogo=function(param){
    
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=partite.ajax.responseText;              
        }
    }
    this.ajax.open("GET","?controller=partite&task=riepilogo&aj=1&idp="+param,true);
    this.ajax.send();
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
partite.riepilogo1=function(){
	
	var formname = document.getElementById('form_comp').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=profilo.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}