admin = new Object();

admin.ajax=compatibilita();

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
admin.banna = function (){
	
	var formname = document.getElementById('banna').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=admin.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

utente=new Array()
utente[0]="NomeUtente";
utente[1]="residenza";
utente[2]="email";

campo=new Array()
campo[0]="nome";
campo[1]="citta";

partita=new Array()
partita[0]="nomep";

squadra=new Array()
squadra[0]="nome";

voto=new Array()
voto[0]="voto";
voto[1]="testo";
voto[2]="ricevente";
voto[3]="mittente";

/**
* Riempie la select colonne a seconda di quale tabella si sceglie
*/
function riempiColonne (){
	var tabella = document.getElementById ('tabella');
	secondlist = eval( tabella.options[tabella.selectedIndex].value );
	var colonne = document.getElementById('colonne');
	colonne.options.length=0;
	for(i=0;i<secondlist.length;i++) {
	       colonne.options[i] = new Option(secondlist[i]);
	       colonne.options[i].setAttribute('value',secondlist[i]);
	   };
	colonne.selectedIndex=0;
}