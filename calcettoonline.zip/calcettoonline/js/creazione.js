crea=new Object();

crea.ajax=compatibilita();

/**
 * Fa una richiesta GET http tramite ajax al server e mette il risultato
 * nel div rappresentato dall'id contente
 */
crea.modulo=function(){
    
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=crea.ajax.responseText;              
        }
    }
    this.ajax.open("POST","?controller=creazione&task=modulo&aj=1",true);
    this.ajax.send();
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
crea.riepilogo=function(){
	
	var formname = document.getElementById('form_cre').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=crea.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
crea.modifica=function(){
	
	var formname = document.getElementById('form_cre_riep').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=crea.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
crea.salva=function(){
	
	var formname = document.getElementById('form_cre_salva').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=crea.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}

/**
 * Fa una richiesta POST http tramite ajax al server caricando i dati della form
 *  e mette il risultato nel div rappresentato dall'id contente
 */
crea.spedisci=function(){
	
	var formname = document.getElementById('mail').name;
	this.ajax.open('POST',"", true);
    this.ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=crea.ajax.responseText;              
        }
    }
    this.ajax.send(getquerystring(formname));
}