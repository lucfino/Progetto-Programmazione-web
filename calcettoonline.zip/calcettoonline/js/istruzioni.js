istr=new Object();

/**
 * Crea l'oggetto ajax a seconda del browser
 */
istr.compatibilita=function(){

  var xmlhttp;
  if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
    else
  {// code for IE6, IE5
     xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlhttp;
}

istr.ajax=istr.compatibilita();

/**
 * Fa una richiesta GET http tramite ajax al server
 *  e mette il risultato nel div rappresentato dall'id contente
 */
istr.mostra=function(){
    
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=istr.ajax.responseText;              
        }
    }
    this.ajax.open("GET","?controller=ajax&task=istruzioni&aj=1",true);
    this.ajax.send();
}



