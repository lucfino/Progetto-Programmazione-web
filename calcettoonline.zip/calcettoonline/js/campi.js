campi=new Object();

campi.ajax=compatibilita();

/**
 * Fa una richiesta POST http tramite ajax al server
 *  e mostra il risultato nel div rappresentato dall'id contente
 */
campi.mostra=function(){
    
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=campi.ajax.responseText;              
        }
    }
    this.ajax.open("GET","?controller=ajax&task=campi&aj=1",true);
    this.ajax.send();
}



