
var a=Array();
a[0]="templates/main/templates/images/voto12.png";
a[1]="templates/main/templates/images/voto34.png";
a[2]="templates/main/templates/images/voto5.png";
a[3]="templates/main/templates/images/voto67.png";
a[4]="templates/main/templates/images/voto89.png";
a[5]="templates/main/templates/images/voto10.png";

/**
 * A seconda del voto carica un immagine a fianco al commento
 * @param voto
 * @param key
 */
function jfotovoti(voto,key){
	switch(voto){	
	case 0:
		document.getElementById('imgvoti'+key).src = a[0];
		break;
	case 1:
		document.getElementById('imgvoti'+key).src = a[0];
		break;
	case 2:
		document.getElementById('imgvoti'+key).src = a[0];
		break;
	case 3:
		document.getElementById('imgvoti'+key).src = a[1];
		break;		
	case 4:
		document.getElementById('imgvoti'+key).src = a[1];
		break;
	case 5:
		document.getElementById('imgvoti'+key).src = a[2];
		break;		
	case 6:
		document.getElementById('imgvoti'+key).src = a[3];
		break;
	case 7:
		document.getElementById('imgvoti'+key).src = a[3];
		break;
	case 8:
		document.getElementById('imgvoti'+key).src = a[4];
		break;
	case 9:
		document.getElementById('imgvoti'+key).src = a[4];
		break;
	case 10:
		document.getElementById('imgvoti'+key).src = a[5];
		break;
	}	
}
 /**
  * Toglie l'immagine nel relativo div
  * @param voto
  * @param key
  */
function jscompari(voto,key){
	switch(voto){
	
	case 0:
		document.getElementById('imgvoti'+key).src = "";
		break;
	case 1:
		document.getElementById('imgvoti'+key).src = "";
		break;
	case 2:
		document.getElementById('imgvoti'+key).src = "";
		break;
	case 3:
		document.getElementById('imgvoti'+key).src = "";
		break;		
	case 4:
		document.getElementById('imgvoti'+key).src = "";
		break;
	case 5:
		document.getElementById('imgvoti'+key).src = "";
		break;		
	case 6:
		document.getElementById('imgvoti'+key).src = "";
		break;
	case 7:
		document.getElementById('imgvoti'+key).src = "";
		break;
	case 8:
		document.getElementById('imgvoti'+key).src = "";
		break;
	case 9:
		document.getElementById('imgvoti'+key).src = "";
		break;
	case 10:
		document.getElementById('imgvoti'+key).src = "";
		break;
	}
}