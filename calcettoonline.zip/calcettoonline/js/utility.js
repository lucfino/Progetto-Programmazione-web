/**
 * dato l'id dell'oggetto e il tipo di fade che si vuole effettuare, applica il fade al parent
 * dell'oggetto passato
 * @param {string} idOggetto L'id dell'oggetto figlio dell'oggetto a cui si vuole appliare il fade
 * @param {mixed} tipo Il tipo di fade: 1 se fade-in, qualunque altro valore altrimenti 
 */
function effettoScomparsa(idOggetto,tipo){
    var cont;
    document.getElementById(idOggetto).parentNode.setAttribute('fadeIn', 0);
    document.getElementById(idOggetto).parentNode.setAttribute('fadeOut', 1);
    if(tipo == '1'){
        cont = "document.getElementById(\""+idOggetto+"\").parentNode";
        fadeEffectIn(cont);
    }
    else{
        cont = "document.getElementById(\""+idOggetto+"\").parentNode";
        fadeEffectOut(cont);
    }
}

/**
 * Simula un effetto di fade-in dato il parametro
 * @param {string} cont Una stringa del tipo document.getElementById('esempio')
 */
function fadeEffectIn(cont){
    var errore = eval(cont);
    if(parseFloat(errore.attributes['fadeIn'].nodeValue) < 1){
        errore.style.opacity = parseFloat(errore.style.opacity)+0.1;
        if(parseFloat(errore.style.opacity)>1.1){
            errore.style.opacity = '0';
            errore.attributes['fadeIn'].nodeValue = 1;
            }
        errore.attributes['fadeIn'].nodeValue = parseFloat(errore.attributes['fadeIn'].nodeValue)+0.1;
        setTimeout("fadeEffectIn('"+cont+"')", 100);
        }
    else
        return;
}

/**
 * Simula un effetto di fade-out dato il parametro
 * @param {string} cont Una stringa del tipo document.getElementById('esempio')
 */
function fadeEffectOut(cont){
    var errore = eval(cont);
    if(parseFloat(errore.attributes['fadeOut'].nodeValue) > 0){
        errore.style.opacity = parseFloat(errore.style.opacity)-0.1;
        errore.attributes['fadeOut'].nodeValue = parseFloat(errore.attributes['fadeOut'].nodeValue)-0.1;
        if(parseFloat(errore.style.opacity)<0.1){
            errore.style.opacity = '0';
            errore.attributes['fadeOut'].nodeValue = 0;}
        setTimeout("fadeEffectOut('"+cont+"')", 100);}
    else
        return;
}

function update(){
	var path = document.location.pathname;
	document.location.replace(path);
}

/**
 * La funzione, dato un evento, mostra vicino al mouse una
 * foto grazie alla stringa k
 * @param {event} event L'oggetto evento
 * @param {string} k nome della foto da visualizzare
  */
function mostraFoto(event,path){
    var q = document.getElementById('foto');
    if(q!=undefined)
        q.parentNode.removeChild(q);
    var x = event.pageX;
    var y = event.pageY;
    var foto;
    var evento = document.getElementById('eventi');
    foto = document.createElement('img');
    foto.style.position = 'absolute';
    foto.style.top = (y+12)+'px';
    foto.style.left = (x+12)+'px';
    foto.style.border = '3px solid black';
    foto.style.width = '200px';
    foto.style.height = '200px';
    foto.style.backgroundColor = '#ffff88';
    foto.setAttribute('id', 'foto');
    foto.style.padding = '0px';
    foto.src = path;
    evento.appendChild(foto);
}

/**
 * toglie l'immagine vicino al mouse
 */
function togliFoto(){
    var x = document.getElementById('foto');
    x.parentNode.removeChild(x);
}

/**
 * Compone la stringa da inviare al server contenente i valori della form
 * @param {string} formname il nome della form da inviare
 * @author presa da internet
 */
function getquerystring(formname) {
    var form = document.forms[formname];
	var qstr = "";

    /**
      * Compone una stringa nel formato x-www-form-urlencoded
      * @param {string} name
      * @param {string} value
      * @author presa da internet
      */
    function GetElemValue(name, value) {
        qstr += (qstr.length > 0 ? "&" : "")
            + escape(name).replace(/\+/g, "%2B") + "="
            + escape(value ? value : "").replace(/\+/g, "%2B");
			//+ escape(value ? value : "").replace(/\n/g, "%0D");
    }
	var elemArray = form.elements;
    for (var i = 0; i < elemArray.length; i++) {
        var element = elemArray[i];
        var elemType = element.type.toUpperCase();
        var elemName = element.name;
        if (elemName) {
            if (elemType == "TEXT"
                    || elemType == "TEXTAREA"
                    || elemType == "PASSWORD"
					|| elemType == "BUTTON"
					|| elemType == "RESET"
					|| elemType == "SUBMIT"
					|| elemType == "FILE"
					|| elemType == "IMAGE"
                    || elemType == "HIDDEN")
                GetElemValue(elemName, element.value);
            else if (elemType == "CHECKBOX" && element.checked)
                GetElemValue(elemName,
                    element.value ? element.value : "On");
            else if (elemType == "RADIO" && element.checked)
                GetElemValue(elemName, element.value);
            else if (elemType.indexOf("SELECT") != -1)
                for (var j = 0; j < element.options.length; j++) {
                    var option = element.options[j];
                    if (option.selected)
                        GetElemValue(elemName,
                            option.value ? option.value : option.text);
                }
        }
    }
    qstr+=qstr+'&aj=1';
    return qstr;
}

/**
 * Inserisce il parametro str nel responsediv
 * @param {string} str
 * @param {string} responsediv
 *
 */
function updatepage(str,responsediv){
    document.getElementById(responsediv).innerHTML = str;
}

/**
 * Inserisce l'immangine di attesa nel responsediv
 * @param {string} responsediv
 */
function attesa(responsediv){
	var q = document.getElementById('hint');
    if(q!=undefined)
        q.parentNode.removeChild(q);
	var evento = document.getElementById(responsediv);
	hint = document.createElement('img');
	hint.setAttribute('src', 'templates/main/templates/images/loadinfo.net.gif');
	hint.setAttribute('id', 'hint');
	evento.appendChild(hint);
}