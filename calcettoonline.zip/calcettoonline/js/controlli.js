
/*//////////////////////////////////////////////////////////////////////////////
REGISTRAZIONE
//////////////////////////////////////////////////////////////////////////////*/

/**
 * Data una stringa la porta a lowercase
 * @param {string} text
 */
function toLc(text){
    text.value = text.value.toLowerCase();
}

/**
 * Se il nome utente non &egrave; scritto correttamente fa apparire
 *  un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jnomeRegistrazione(){
    var segnaErrore = document.getElementById('nomeErr');
    var errore = new Array();
    jnome(document.getElementById('nomeu').value,errore);
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('nomeErr','1')
        return true;
        }
    else{
        effettoScomparsa('nomeErr','2');
        return false;
        }
}

/**
 * Se il cognome utente non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jcognomeRegistrazione(){
    var segnaErrore = document.getElementById('nomeErr');
    var errore = new Array();
    jnome(document.getElementById('cognome').value,errore);
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('nomeErr','1')
        return true;
        }
    else{
        effettoScomparsa('nomeErr','2');
        return false;
        }
}

/**
 * Se il comune non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jcomuneRegistrazione(){
    var segnaErrore = document.getElementById('comuneErr');
    var errore = new Array();
    jcomune(document.getElementById('comune').value,errore);
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('comuneErr','1')
        return true;
        }
    else{
        effettoScomparsa('comuneErr','2');
        return false;
        }
}

/**
 * Quando viene scelto un anno nella select, attiva la select dei mesi
 * @param {int} anno
 */
function controllaAnno(anno){
    bisestile=false;
    var lung = anno.id.length;
    var sender = anno.id[lung-1];
    var mese = document.getElementById('mese'+sender);
    var indice = anno.selectedIndex;
    var valore = anno[indice].value;
    if(valore != '-anno-'){
        mese.removeAttribute("disabled");
        bisestile = calcolaBisestile(valore);}
    else{
        mese.selectedIndex = 0;
        mese.setAttribute("disabled","disabled");}
    controllaMese(mese);
}

/**
 * Una volta selezionato il mese, inserisce i giorni nella select relativa
 * @param {int} mese
 *
 */
function controllaMese(mese){
    var lung = mese.id.length;
    var sender = mese.id[lung-1];
    var giorno = document.getElementById('giorno'+sender);

    var indice = mese.selectedIndex;
    var valore = mese[indice].value;
    if(valore != 0){
         if(bisestile && valore == 2){
            giorno[30].style.display = "none";
            giorno[31].style.display = "none";}

         if(!bisestile && valore == 2){
            giorno[29].style.display = "none";
            giorno[30].style.display = "none";
            giorno[31].style.display = "none";}

         if(valore == 11 || valore == 4 || valore == 6 || valore == 9){
            giorno[29].style.display = "block";
            giorno[30].style.display = "block";
            giorno[31].style.display = "none";
         }
         else
            if(valore != 2){
                giorno[29].style.display = "block";
                giorno[30].style.display = "block";
                giorno[31].style.display = "block";
         }
    giorno.removeAttribute("disabled");
    }
    else
        {
        giorno.selectedIndex = 0;
        giorno.setAttribute("disabled", "disabled");
        }
    }

/**
 * Dato un anno, controlla se &egrave; bisestile
 * @param {int}
 * @returns true nel caso di anno bisestile false altrimenti
 * @type bool
 */
function calcolaBisestile(anno){
    if((anno % 100) == 0 && (anno % 400) == 0){
        return true;}
    if((anno % 100) != 0 && (anno % 4) == 0){
        return true}
    else return false;
}

/**
 * Se il giorno non � selezionato correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jdataNascitaRegistrazione(){
    var segnaErrore = document.getElementById('dataNErr');
    var errore = new Array();
    jselect('giornoN',errore);
    if(errore != ''){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = 'Devi selezionare la data di Nascita';
        effettoScomparsa('dataNErr','1');
        return true;
        }
    else{
        effettoScomparsa('dataNErr','2');
        return false;
        }
}

/**
 * Se lo username non &egrave; scritto correttamente fa apparire
 * un errrore a fianco alla form interessata
 * @returns {Boolean}
 */
function jusernameRegistrazione(){
    var segnaErrore = document.getElementById('usernameErr');
    var errore = new Array();
    jusername(document.getElementById('nomeUtente').value,errore)
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('usernameErr','1')
        return true;
        }
    else{
        effettoScomparsa('usernameErr','2');
        return false;
        }
}

/**
 * Se la password non &egrave; scritto correttamente fa apparire
 * un errrore a fianco alla form interessata
 * @returns {Boolean}
 */
function jpasswordRegistrazione(){
    var segnaErrore = document.getElementById('passwordErr');
    var errore = new Array();
    jpassword(document.getElementById('password').value,errore)
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
	segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('passwordErr','1')
        return true;
        }
    else{
        effettoScomparsa('passwordErr','2');
        return false;
        }

}

/**
 * Se il valore di conferma password &egrave; diverso da quello di password
 * un errore fa apparire a fianco alla form interessata
 * @returns {Boolean}
 */
function jmatchPasswordRegistrazione(){
    var segnaErrore = document.getElementById('passwordErr');
    var errore = new Array();
    jpassword(document.getElementById('password').value,errore)
    if(errore != "")
        return jpasswordRegistrazione();
    else{
        jMatch(document.getElementById('password').value, document.getElementById('Cpassword').value, errore);
            if(errore != ""){
                segnaErrore.parentNode.style.opacity = 0;
                segnaErrore.parentNode.style.visibility = 'visible';
                segnaErrore.innerHTML = ''+errore[1];
                effettoScomparsa('passwordErr','1')
                return true;
                }
            effettoScomparsa('passwordErr','2');
            return false;}
}

/**
 * Se l'email non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jemailRegistrazione(){
    var segnaErrore = document.getElementById('emailErr');
    var errore = new Array();
    jemail(document.getElementById('email').value,errore)
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
	segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('emailErr','1')
        return true;
        }
    else{
        effettoScomparsa('emailErr','2');
        return false;
    }
}

/**
 * Se il valore di conferma email &egrave; diverso da quello di email
 *  fa apparire un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jmatchEmailRegistrazione(){
    var segnaErrore = document.getElementById('emailErr');
    var errore = new Array();
    jemail(document.getElementById('email').value,errore)
    if(errore != "")
        return jemailRegistrazione();
    else{
        jMatch(document.getElementById('email').value, document.getElementById('Cemail').value, errore);
        if(errore != ""){
        	segnaErrore.parentNode.style.opacity = 0;
            segnaErrore.parentNode.style.visibility = 'visible';
            segnaErrore.innerHTML = ''+errore[1];
            effettoScomparsa('emailErr','1')
            return true;
            }
        effettoScomparsa('emailErr','2');
        return false;
    }
}

/**
 * Mostra se il nome utente &egrave; disponibile o se &egrave;
 * gi&agrave; stato usato nel db
 * @returns {Boolean}
 */
function jesistenzaUsernameRegistrazione(){
    var valore = document.getElementById('nomeUtente').value;
    var esito = jusername(valore);
    var segnaErrore = document.getElementById('spanusername');
    segnaErrore.innerHTML = "";
    if(esito == false){
        var xmlhttp = compatibilita();
        xmlhttp.onreadystatechange = function(){
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200 ){
                if(xmlhttp.responseText == 0){
                    segnaErrore.innerHTML = " Lo username &egrave; disponibile";
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "green";
                    return false;
                }
                if(xmlhttp.responseText != 0){
                    segnaErrore.innerHTML = " Lo username &egrave; gi&agrave; stato usato";
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "red";
                    return true;
                }
            }
            else{
    			attesa('spanusername');
    		}
        }
        xmlhttp.open('GET','?controller=ajax&task=esistenza&campo=nomeUtente&valore='+valore,false);
        xmlhttp.send();
    }
    else{
        segnaErrore.innerHTML = "";
    }
}

/**
 * Mostra se l'email &egrave; disponibile o se &egrave;
 * gi&agrave; stata usata nel db
 */
function jesistenzaEmailRegistrazione(){
    var valore = document.getElementById('email').value;
    var segnaErrore = document.getElementById('spanemail');
    segnaErrore.innerHTML = "";
    if(jemail(valore) == false){
        var xmlhttp = compatibilita();
        xmlhttp.onreadystatechange = function(){
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200 ){
                if(xmlhttp.responseText == 0){
                    segnaErrore.innerHTML = " L\'indirizzo email &egrave; disponibile"
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "green";
                    return false;}
                if(xmlhttp.responseText != 0){
                    segnaErrore.innerHTML = " L\'indirizzo email &egrave; gi&agrave; stato usato"
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "red";
                    return true;}
            }
            else{
    			attesa('spanemail');
    		}
        }

        xmlhttp.open('GET','?controller=ajax&task=esistenza&campo=email&valore='+valore,true);
        xmlhttp.send();}
    else{
        segnaErrore.innerHTML = "";
    }
}


/**
 * Controlla che tutti i campi nella fase di registrazione siano privi di errori
 * in caso contrario non invia i dati al server e fa apparire tutti gli errori.
 */
function controllaRegistrazione(){
	var segnaErrore = document.getElementById('endErrReg');
    var test = new Array();
    var k=false;
    test[0] = jnomeRegistrazione();
    if(test[0] == false)
        test[1] = jcognomeRegistrazione();
    test[2] = jdataNascitaRegistrazione();
    test[3] = jusernameRegistrazione();
    test[4] = jpasswordRegistrazione();
    test[5] = jmatchPasswordRegistrazione();
    test[6] = jemailRegistrazione();
    test[7] = jcomuneRegistrazione();
    test[8] = jmatchEmailRegistrazione();
    for(var i=0;i<test.length && k==false;i++)
       k=test[i];
    if(k==false)
    	reg.riepilogo();
    else{
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        effettoScomparsa('endErrReg', '1');
    }
}

/**
 * Controlla che tutti i campi nella fase di modifica dati di registrazione siano privi di errori
 * in caso contrario non invia i dati al server e fa apparire tutti gli errori.
 */
function modificaRegistrazione(){
	var segnaErrore = document.getElementById('endErrReg');
    var test = new Array();
    var k=false;
    test[0] = jnomeRegistrazione();
    if(test[0] == false)
        test[1] = jcognomeRegistrazione();
    test[2] = jdataNascitaRegistrazione();
    test[3] = jusernameRegistrazione();
    test[4] = jpasswordRegistrazione();
    test[5] = jmatchPasswordRegistrazione();
    test[6] = jemailRegistrazione();
    test[7] = jcomuneRegistrazione();
    test[8] = jmatchEmailRegistrazione();
    for(var i=0;i<test.length && k==false;i++)
       k=test[i];
    if(k==false)
    	profilo.update();
    else{
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        effettoScomparsa('endErrReg', '1');
    }
}

/*///////////////////////////////////////////////////////////////////////////
PARTITA
///////////////////////////////////////////////////////////////////////////*/

/**
 * Se il nome della partita non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jnomePartita(){
    var segnaErrore = document.getElementById('nomeErr');
    var errore = new Array();
    jnomep(document.getElementById('nomep').value,errore);
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('nomeErr','1')
        return true;
        }
    else{
        effettoScomparsa('nomeErr','2');
        return false;
        }
}

/**
 * Se la select del campo non &grave; selezionata correttamente
 * fa apparire un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jcampoPartita(){
    var segnaErrore = document.getElementById('campoErr');
    var errore = new Array();
    jselect('_campo',errore);
    if(errore != ''){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = 'Devi selezionare il campo';
        effettoScomparsa('campoErr','1');
        return true;
        }
    else{
        effettoScomparsa('campoErr','2');
        return false;
        }
}

/**
 * Se il giorno non � selezionato correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jdataPartita(){
    var segnaErrore = document.getElementById('dataPErr');
    var errore = new Array();
    jselect('giornoP',errore);
    if(errore != ''){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = 'Devi selezionare la data della partita';
        effettoScomparsa('dataPErr','1');
        return true;
    }
    else{
        effettoScomparsa('dataPErr','2');
        return false;
    }
}

/**
 * Controlla se la data inserita &egrave; maggiore della data attuale
 * @param {char} lettera l'ultima lettera dell'id della select della data
 * @return true se la data &egrave; maggiore, false se &egrave; minore di quella odierna
 * @type bool
 */
    function jisMaggioreDataAttualeInserimento(lettera){
        lettera = lettera || 'P';
        var errore = new Array();        
        jisMaggioreDataAttuale(lettera, errore);
        if(errore != ""){
            document.getElementById('giorno'+lettera).parentNode.style.border = "3px solid red";
        	var segnaErrore = document.getElementById('spandata');
        	segnaErrore.parentNode.style.opacity = 0;
            segnaErrore.parentNode.style.visibility = 'visible';
            segnaErrore.innerHTML = 'La data deve essere maggiore di quella attuale';
            effettoScomparsa('spandata','1');
            return true;
        }
        else{
        	document.getElementById('giorno'+lettera).parentNode.style.border = "";        	
        	effettoScomparsa('spandata','2');
        	return false;
        }

    }

/**
 * Se l'ora non � selezionato correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function joraPartita(){
	var segnaErrore = document.getElementById('oraPErr');
	var errore = new Array();
	jselect('oraP',errore);
	if(errore != ''){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = 'Devi selezionare l\'ora';
        effettoScomparsa('oraPErr','1');
        return true;
        }
    else{
        effettoScomparsa('oraPErr','2');
        return false;
        }
}

/**
 * Se i minuti non sono selezionati correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jminutiPartita(){
	var segnaErrore = document.getElementById('minutiPErr');
	var errore = new Array();
	jselect('minutiP',errore);
	if(errore != ''){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = 'Devi selezionare i minuti';
        effettoScomparsa('minutiPErr','1');
        return true;
        }
    else{
        effettoScomparsa('minutiPErr','2');
        return false;
        }
}

/**
 * Se il nome della prima squadra non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jsquadraPartita1(){
    var segnaErrore = document.getElementById('squadra1Err');
    var errore = new Array();
    jsquadra(document.getElementById('_squadra1').value,errore);
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('squadra1Err','1')
        return true;
        }
    else{
        effettoScomparsa('squadra1Err','2');
        return false;
        }
}

/**
 * Se il nome della seconda squadra non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jsquadraPartita2(){
    var segnaErrore = document.getElementById('squadra2Err');
    var errore = new Array();
    jsquadra(document.getElementById('_squadra2').value,errore);
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('squadra2Err','1')
        return true;
        }
    else{
        effettoScomparsa('squadra2Err','2');
        return false;
        }
}

/**
 * Mostra se il nome della prima squadra &egrave; disponibile o se &egrave;
 * gi&agrave; stato usato nel db
 * @returns {Boolean}
 */
function jesisteSquadra1(){
    var valore = document.getElementById('_squadra1').value;
    var esito = jsquadra(valore);
    var segnaErrore = document.getElementById('spansquadra1');
    segnaErrore.innerHTML = "";
    if(esito == false){
        var xmlhttp = compatibilita();
        xmlhttp.onreadystatechange = function(){
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200 ){
            	if(xmlhttp.responseText != 0){
                    segnaErrore.innerHTML = " attenzione!!! il nome della squadra &egrave; gi&agrave; stato usato se confermi il nome le statistiche della squadra saranno unificate";
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "red";
                    return true;
                }
                if(xmlhttp.responseText == 0){
                    segnaErrore.innerHTML = "";
                    return false;
                }
            }
            else{
    			attesa('spansquadra1');
    		}
        }
        xmlhttp.open('GET','?controller=ajax&task=esistenzaSquadra&campo=nome&valore='+valore,false);
        xmlhttp.send();
    }
    else{
        segnaErrore.innerHTML = "";
    }
}

/**
 * Mostra se il nome della seconda squadra &egrave; disponibile o se &egrave;
 * gi&agrave; stato usato nel db
 * @returns {Boolean}
 */
function jesisteSquadra2(){
    var valore = document.getElementById('_squadra2').value;
    var esito = jsquadra(valore);
    var segnaErrore = document.getElementById('spansquadra2');
    segnaErrore.innerHTML = "";
    if(esito == false){
        var xmlhttp = compatibilita();
        xmlhttp.onreadystatechange = function(){
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200 ){
			if(xmlhttp.responseText != 0){
                    segnaErrore.innerHTML = " attenzione!!! il nome della squadra &egrave; gi&agrave; stato usato se confermi il nome le statistiche della squadra saranno unificate";
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "red";
                    return true;
                }
                if(xmlhttp.responseText == 0){
                    segnaErrore.innerHTML = "";
                    return false;
                }                
            }
            else{
    			attesa('spansquadra2');
    		}
        }
        xmlhttp.open('GET','?controller=ajax&task=esistenzaSquadra&campo=nome&valore='+valore,false);
        xmlhttp.send();
    }
    else{
        segnaErrore.innerHTML = "";
    }
}

/**
 * Controlla che tutti i campi nella fase di creazione di una partita
 * siano privi di errori in caso contrario non invia i dati al server
 */
function controllaPartita(){
	var segnaErrore = document.getElementById('endErrPart');
    var test = new Array();
    var k=false;
    test[0] = jnomePartita();
    test[1] = jdataPartita();
    test[2] = joraPartita();
    test[3] = jminutiPartita();
    test[4] = jsquadraPartita1();
    test[5] = jsquadraPartita2();
    test[6] = jcampoPartita();
    test[7] = jisMaggioreDataAttualeInserimento('P');
    for(var i=0;i<test.length && k==false;i++)
       k=test[i];
    if(k==false)
    	crea.riepilogo();
    else{
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        effettoScomparsa('endErrPart', '1');
    }
}

/*//////////////////////////////////////////////////////////////////////////////
STATISTICHE
/////////////////////////////////////////////////////////////////////////////*/

/**
 * Se lo username non &egrave; scritto correttamente fa apparire
 * un errrore a fianco alla form interessata
 * @returns {boolean}
 */
function jusernameStatistiche(){
    var errore = new Array();
    ritorno = false;
    for (i=1;i<11;i++){
    	jusernameStat(document.getElementById('part'+i).value,errore);
    	if(errore != ""){
    		var segnaErrore = document.getElementById('usernameErr'+i);
    		segnaErrore.parentNode.style.opacity = 0;
    		segnaErrore.parentNode.style.visibility = 'visible';
    		segnaErrore.innerHTML = ''+errore[1];
    		if (i==10)
    		effettoScomparsa('usernameErr'+i,'1')
    		ritorno = true;
        }
    	else{
    		if (i==10)
    		effettoScomparsa('usernameErr'+i,'2');
        }
    }
    return ritorno;
}

/**
 * Se il gol non &egrave; scritto correttamente fa apparire
 * un errrore a fianco alla form interessata
 * @returns {boolean}
 */
function jusernameGol(){
    var errore = new Array();
    ritorno = false;
    for (i=1;i<11;i++){
    	jgolStat(document.getElementById('gol'+i).value,errore);
    	if(errore != ""){
    		var segnaErrore = document.getElementById('golErr'+i);
    		segnaErrore.parentNode.style.opacity = 0;
    		segnaErrore.parentNode.style.visibility = 'visible';
    		segnaErrore.innerHTML = ''+errore[1];
    		if (i==10)
    		effettoScomparsa('golErr'+i,'1')
    		ritorno = true;
        }
    	else{
    		if (i==10)
    		effettoScomparsa('golErr'+i,'2');
        }
    }
    return ritorno;
}

/**
 * Controlla che tutti i campi nella fase riempimento della form  dei giocatori e dei 
 * rispettivi gol siano privi di errori in caso contrario non invia i dati al server
 */
function controllaGol(){
	var segnaErrore = document.getElementById('endErrPart');
    var test = new Array();
    var k=false;
    test[0] = jusernameStatistiche();
    test[1] = jusernameGol();
    for(var i=0;i<test.length && k==false;i++)
       k=test[i];
    if(k==false)
    	partite.riepilogo1();
    else{
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        effettoScomparsa('endErrPart', '1');
    }
}

/*//////////////////////////////////////////////////////////////////////////////
RECUPERO
//////////////////////////////////////////////////////////////////////////////*/

/**
 * Se l'email non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jemailRecupero(){
    var segnaErrore = document.getElementById('emailErr');
    var errore = new Array();
    jemail(document.getElementById('email').value,errore)
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
	segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('emailErr','1')
        ritorno= true;
        }
    else{
        effettoScomparsa('emailErr','2');
        ritorno= false;
    }
    if (ritorno){
    	a=document.getElementById('submit_r').disabled=true;
    	return ritorno;
	}
    else{
    	a=document.getElementById('submit_r').disabled=false;
    	return ritorno;
    }
}

/*//////////////////////////////////////////////////////////////////////////////
Voto
//////////////////////////////////////////////////////////////////////////////*/

/**
 * Controlla se la select del voto � selezionata correttamente
 * @param {char} id della select da controllare
 * @param {char} id del div dove far apparire l'errore
 * @return true se non &egrave; selezionata correttamente, false altrimenti
 * @type bool
 */
function jselectVoto(idSelect,err){
    var segnaErrore = document.getElementById(err);
    var errore = new Array();
    jselect(idSelect,errore);
    if(errore != ''){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = 'Devi selezionare questo campo';
        effettoScomparsa(err,'1');
        return true;
        }
    else{
        effettoScomparsa(err,'2');
        return false;
        }
}

/*//////////////////////////////////////////////////////////////////////////////
Admin
//////////////////////////////////////////////////////////////////////////////*/

/**
 * Controlla se lo username � stato scritto correttamente
 * @param {char} id dello username da controllare
 * @param {char} id del div dove far apparire l'errore
 * @return true se non &egrave; corretto, false altrimenti
 * @type bool
 */
function jusernameAdmin(id,err){
	var segnaErrore = document.getElementById(err);
    var errore = new Array();
    ritorno = false;
    for (i=1;i<11;i++){
    	jusername(document.getElementById(id).value,errore);
    	if(errore != ""){    		
    		segnaErrore.parentNode.style.opacity = 0;
    		segnaErrore.parentNode.style.visibility = 'visible';
    		segnaErrore.innerHTML = ''+errore[1];
    		if (i==10)
    		effettoScomparsa(err,'1')
    		ritorno = true;
        }
    	else{
    		if (i==10)
    		effettoScomparsa(err,'2');
        }
    }
    return ritorno;
}

/**
 * Controlla se lo username � presente nel database tramite una richiesta ajax
 * @param {char} id dello username da controllare
 * @param {char} id del div dove far apparire l'errore
 * @return true se &egrave; presente nel database, false altrimenti
 * @type bool
 */
function jesistenzaUsernameAdmin(id,err){
    var valore = document.getElementById(id).value;
    var esito = jusername(valore);
    var segnaErrore = document.getElementById(err);
    segnaErrore.innerHTML = "";
    if(esito == false){
        var xmlhttp = compatibilita();
        xmlhttp.onreadystatechange = function(){
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200 ){
                if(xmlhttp.responseText == 0){
                    segnaErrore.innerHTML = " Lo username non &egrave; presente nel database";
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "red";
                    return false;
                }
                if(xmlhttp.responseText != 0){
                    segnaErrore.innerHTML = " Lo username &egrave; presente nel database";
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "green";
                    return true;
                }
            }
            else{
    			attesa(err);
    		}
        }
        xmlhttp.open('GET','?controller=ajax&task=esistenza&campo=nomeUtente&valore='+valore,false);
        xmlhttp.send();
    }
    else{
        segnaErrore.innerHTML = "";
    }
}


/**
 * Mostra se il nome utente &egrave; disponibile o se &egrave;
 * gi&agrave; stato usato nel db
 * @returns {Boolean}
 */
function jesistenzaCampo(){
    var valore = document.getElementById('nome').value;
    var esito = jusername(valore);
    var segnaErrore = document.getElementById('spancampo');
    segnaErrore.innerHTML = "";
    if(esito == false){
        var xmlhttp = compatibilita();
        xmlhttp.onreadystatechange = function(){
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200 ){
                if(xmlhttp.responseText == 0){
                    segnaErrore.innerHTML = " Il campo &egrave; disponibile";
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "green";
                    return false;
                }
                if(xmlhttp.responseText != 0){
                    segnaErrore.innerHTML = " Il campo &egrave; gi&agrave; stato usato";
                    segnaErrore.style.fontWeight = 'bolder';
                    segnaErrore.style.color = "red";
                    return true;
                }
            }
            else{
    			attesa('spancampo');
    		}
        }
        xmlhttp.open('GET','?controller=ajax&task=esistenzaCampo&campo=nome&valore='+valore,false);
        xmlhttp.send();
    }
    else{
        segnaErrore.innerHTML = "";
    }
}

/**
 * Se il nome della prima squadra non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jcampoAdmin(){
    var segnaErrore = document.getElementById('campoErr');
    var errore = new Array();
    jcampo(document.getElementById('nome').value,errore);
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('campoErr','1')
        return true;
        }
    else{
        effettoScomparsa('campoErr','2');
        return false;
        }
}

/**
 * Se il comune non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jcomuneAdmin(){
    var segnaErrore = document.getElementById('comuneErr');
    var errore = new Array();
    jcomune(document.getElementById('citta').value,errore);
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('comuneErr','1')
        return true;
        }
    else{
        effettoScomparsa('comuneErr','2');
        return false;
        }
}

/*//////////////////////////////////////////////////////////////////////////////
Installazione
//////////////////////////////////////////////////////////////////////////////*/

/**
 * Se lo username non &egrave; scritto correttamente fa apparire
 * un errrore a fianco alla form interessata
 * @returns {Boolean}
 */
function jusernameAdmin(){
    var segnaErrore = document.getElementById('usernameErr');
    var errore = new Array();
    jusername(document.getElementById('usernameApp').value,errore)
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('usernameErr','1')
        return true;
        }
    else{
        effettoScomparsa('usernameErr','2');
        return false;
        }
}

/**
 * Se la password non &egrave; scritto correttamente fa apparire
 * un errrore a fianco alla form interessata
 * @returns {Boolean}
 */
function jpasswordAdmin(){
    var segnaErrore = document.getElementById('passwordErr');
    var errore = new Array();
    jpassword(document.getElementById('passwordApp').value,errore)
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
	segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('passwordErr','1')
        return true;
        }
    else{
        effettoScomparsa('passwordErr','2');
        return false;
        }

}

/**
 * Se il valore di conferma password &egrave; diverso da quello di password
 * un errore fa apparire a fianco alla form interessata
 * @returns {Boolean}
 */
function jmatchPasswordAdmin(){
    var segnaErrore = document.getElementById('passwordCErr');
    var errore = new Array();
    jpassword(document.getElementById('passwordCApp').value,errore)
    if(errore != "")
        return jpasswordRegistrazione();
    else{
        jMatch(document.getElementById('passwordApp').value, document.getElementById('passwordCApp').value, errore);
            if(errore != ""){
                segnaErrore.parentNode.style.opacity = 0;
                segnaErrore.parentNode.style.visibility = 'visible';
                segnaErrore.innerHTML = ''+errore[1];
                effettoScomparsa('passwordCErr','1')
                return true;
                }
            effettoScomparsa('passwordCErr','2');
            return false;}
}

/**
 * Se la password non &egrave; scritto correttamente fa apparire
 * un errrore a fianco alla form interessata
 * @returns {Boolean}
 */
function jpasswordEmailAdmin(){
    var segnaErrore = document.getElementById('passwordEErr');
    var errore = new Array();
    jpassword(document.getElementById('mailPassword').value,errore)
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
	segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('passwordEErr','1')
        return true;
        }
    else{
        effettoScomparsa('passwordEErr','2');
        return false;
        }

}

/**
 * Se il valore di conferma password &egrave; diverso da quello di password
 * un errore fa apparire a fianco alla form interessata
 * @returns {Boolean}
 */
function jmatchPasswordEmailAdmin(){
    var segnaErrore = document.getElementById('passwordECErr');
    var errore = new Array();
    jpassword(document.getElementById('mailPasswordC').value,errore)
    if(errore != "")
        return jpasswordRegistrazione();
    else{
        jMatch(document.getElementById('mailPassword').value, document.getElementById('mailPasswordC').value, errore);
            if(errore != ""){
                segnaErrore.parentNode.style.opacity = 0;
                segnaErrore.parentNode.style.visibility = 'visible';
                segnaErrore.innerHTML = ''+errore[1];
                effettoScomparsa('passwordECErr','1')
                return true;
                }
            effettoScomparsa('passwordECErr','2');
            return false;}
}

/**
 * Se il comune non &egrave; scritto correttamente fa apparire
 * un errore a fianco alla form interessata
 * @returns {Boolean}
 */
function jportaServer(){
    var segnaErrore = document.getElementById('portaErr');
    var errore = new Array();
    jporta(document.getElementById('mailPorta').value,errore);
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
        segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('portaErr','1')
        return true;
        }
    else{
        effettoScomparsa('portaErr','2');
        return false;
        }
}

/**
 * Se la password non &egrave; scritto correttamente fa apparire
 * un errrore a fianco alla form interessata
 * @returns {Boolean}
 */
function jpasswordDb(){
    var segnaErrore = document.getElementById('passwordDbErr');
    var errore = new Array();
    jpassword(document.getElementById('passwordDb').value,errore)
    if(errore != ""){
        segnaErrore.parentNode.style.opacity = 0;
        segnaErrore.parentNode.style.visibility = 'visible';
	segnaErrore.innerHTML = ''+errore[1];
        effettoScomparsa('passwordDbErr','1')
        return true;
        }
    else{
        effettoScomparsa('passwordDbErr','2');
        return false;
        }

}

/**
 * Se il valore di conferma password &egrave; diverso da quello di password
 * un errore fa apparire a fianco alla form interessata
 * @returns {Boolean}
 */
function jmatchPasswordDb(){
    var segnaErrore = document.getElementById('passwordCDbErr');
    var errore = new Array();
    jpassword(document.getElementById('passwordCDb').value,errore)
    if(errore != "")
        return jpasswordRegistrazione();
    else{
        jMatch(document.getElementById('passwordDb').value, document.getElementById('passwordCDb').value, errore);
            if(errore != ""){
                segnaErrore.parentNode.style.opacity = 0;
                segnaErrore.parentNode.style.visibility = 'visible';
                segnaErrore.innerHTML = ''+errore[1];
                effettoScomparsa('passwordCDbErr','1')
                return true;
                }
            effettoScomparsa('passwordCDbErr','2');
            return false;}
}