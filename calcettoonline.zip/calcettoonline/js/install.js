/**
 * Se il check � attivo abilita i campi mailUsername e mailPassword
 * @param check
 */
function autenticazione(check){

     var campi=new Array();
     campi[0]=document.getElementById('mailPassword');
     campi[1]=document.getElementById('mailPasswordC');
     campi[2]=document.getElementById('mailUsername');

     var istr;
     if(check.checked) istr="campi[i].removeAttribute('disabled')";
     else istr="campi[i].setAttribute('disabled', 'disabled')";

     for(var i in campi){
        eval(istr);
     }
          
  }