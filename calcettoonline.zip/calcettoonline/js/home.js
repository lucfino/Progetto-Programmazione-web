home=new Object();

home.ajax=compatibilita();

/**
 * Fa una richiesta GET http tramite ajax al server
 *  e mette il risultato nel div rappresentato dall'id contente
 */
home.mostra=function(){
    
    this.ajax.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200 ){
        	 
        	var cont=document.getElementById('content');
        	cont.innerHTML=home.ajax.responseText;              
        }
    }
    this.ajax.open("GET","?controller=ajax",true);
    this.ajax.send();
}

foto= new Array();
foto[0]="templates/main/templates/images/calcetto1.jpg";
foto[1]="templates/main/templates/images/calcetto2.jpg";
foto[2]="templates/main/templates/images/calcetto3.jpg";
foto[3]="templates/main/templates/images/calcetto4.jpg";
foto[4]="templates/main/templates/images/calcetto5.jpg";
foto[5]="templates/main/templates/images/calcetto6.jpg";
foto[6]="templates/main/templates/images/calcetto7.jpeg";
foto[7]="templates/main/templates/images/calcetto8.jpg";
imageIndex=0;

/**
 * A seconda del parametro carica una foto nella galleria
 * @param i
 */
function image(i) {
	 imageIndex = imageIndex + i;
	 if (imageIndex < 0) {imageIndex=foto.length-1}
	 if (imageIndex >= foto.length) {imageIndex=0}
	 document.getElementById('gallery').src = foto[imageIndex];
	 
}

/**
 * Setta il bordo del bottone a inset
 * @param button
 */
function inset(button){
	button.style.borderStyle="inset";
}

/**
 * Setta il bordo del bottone a outset
 * @param button
 */
function outset(button){
	button.style.borderStyle="outset";
}
