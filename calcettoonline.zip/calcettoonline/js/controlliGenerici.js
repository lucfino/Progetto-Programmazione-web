/**
 * Crea l'oggetto ajax a seconda del browser.
 * @returns
 */
function compatibilita(){

  var xmlhttp;
  if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
    else
  {// code for IE6, IE5
     xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlhttp;
}

/**
 * Controlla se il nome che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} il nome da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jnome(nome,array){
    array = array || new Array();
    var r5 = /^([a-zA-Z]{1,}( |'){0,1}){1,}([a-zA-Z]{1,})$/;
    if(!nome.match(r5)){
		if(nome==""){
			array[0] = '1';
                        array[1] = "Nome e/o cognome vuoti";}
		else{
			array[0] = '2';
                        array[1] = "Formato del nome e/o cognome errato";}
		return true;
            }
        return false;
}

/**
 * Controlla se il nome della partita che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} il nome della partita da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jnomep(nome,array){
    array = array || new Array();
    var r5 = /^[a-zA-Z0-9]{1,}$/;
    if(!nome.match(r5)){
		if(nome==""){
			array[0] = '1';
                        array[1] = "Devi inserire il nome della partita";}
		else{
			array[0] = '2';
                        array[1] = "Formato del nome della partita errato";}
		return true;
            }
        return false;
}

/**
 * Controlla se il nome della squadra che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} il nome della squadra da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jsquadra(nome,array){
    array = array || new Array();
    var r5 = /^([a-zA-Z0-9]{1,}( |'){0,1}){1,}([a-zA-Z0-9]{1,})$/;
    if(!nome.match(r5)){
		if(nome==""){
			array[0] = '1';
                        array[1] = "Nome della squadra vuoto";}
		else{
			array[0] = '2';
                        array[1] = "Formato del nome della squadra errato";}
		return true;
            }
        return false;
}

/**
 * Controlla se il nome del campo che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} il nome della squadra da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jcampo(nome,array){
    array = array || new Array();
    var r5 = /^([a-zA-Z0-9]{1,}( |'){0,1}){1,}([a-zA-Z0-9]{1,})$/;
    if(!nome.match(r5)){
		if(nome==""){
			array[0] = '1';
                        array[1] = "Nome del campo vuoto";}
		else{
			array[0] = '2';
                        array[1] = "Formato del nome del campo errato";}
		return true;
            }
        return false;
}


/**
 * Controlla se il comune che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} il nome del comune da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jcomune(comune,array){
    array = array || new Array();
    var r5 = /^([a-zA-Z]{1,}( |'){0,1}){1,}([a-zA-Z]{1,})$/;
    if(!comune.match(r5)){
		if(comune==""){
			array[0] = '1';
                        array[1] = "Non hai inserito il comune";}
		else{
			array[0] = '2';
                        array[1] = "Formato del comune errato";}
		return true;
            }
        return false;
}

/**
 * Controlla se lo username che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} lo username da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jusername(username,array){
    array = array || new Array();
    var r1 = /^[0-9a-z]{5,15}$/;
	if(!username.match(r1)){
            if(username == ""){
                array[0] = '1';
                array[1] = 'Username vuoto';
                return true;}
            else{
                array[0] = '2';
                array[1] = 'Formato dell\'username errato'
                return true;
            }
        }
        else
        return false;
}

/**
 * Controlla se lo username che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} lo username da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jusernameStat(username,array){
    array = array || new Array();
    var r1 = /^[0-9a-z]{5,15}$/;
	if(!username.match(r1)){
            if(username == ""){
                array[0] = '1';
                array[1] = 'Uno dei campi dei giocatori non &egrave; stato ancora riempito';
                return true;}
            else{
                array[0] = '2';
                array[1] = 'Il formato di uno dei campi dei giocatori non &egrave; stato riempito correttamente'
                return true;
            }
        }
        else
        return false;
}

/**
 * Controlla se il gol che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {int} gol il numero da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jgolStat(gol,array){
    array = array || new Array();
    var r1 = /^[0-9]{1,2}$/;
	if(!gol.match(r1)){
            if(gol == ""){
                array[0] = '1';
                array[1] = 'Uno dei campi gol non &egrave; stato ancora riempito';
                return true;}
            else{
                array[0] = '2';
                array[1] = 'Il formato di uno dei campi gol non &egrave; stato riempito correttamente'
                return true;
            }
        }
        else
        return false;
}

/**
 * Controlla se la porta che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {int} gol il numero da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jporta(porta,array){
    array = array || new Array();
    var r1 = /^[0-9]{1,5}$/;
	if(!porta.match(r1)){
            if(porta == ""){
                array[0] = '1';
                array[1] = 'La porta non &egrave; stata ancora riempita';
                return true;}
            else{
                array[0] = '2';
                array[1] = 'Il formato della porta non &egrave; corretto'
                return true;
            }
        }
        else
        return false;
}

/**
 * Controlla se la select non &egrave; selezionata al primo indice
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} id della select da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jselect(selectId,array){
    array = array || new Array();
    if(document.getElementById(selectId).selectedIndex == 0){
        array[0] = '1';
        array[1] = 'Devi selezionare tutta la data';
        return true;}
    return false;
}

/**
 * Controlla se la password che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} password da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jpassword(password,array){
    array = array || new Array();
    var r2 = /^[0-9a-zA-Z\*\@\_\-]{7,15}$/;
    if(!password.match(r2)){
		if(password==""){
                        array[0] = '1';
			array[1] = 'Password vuota';
                        }
		else{
                    if(password.length < 7){
                        array[0] = '2';
                        array[1] = 'Password di minimo 7 caratteri';
                    }
                    else{
                        array[0] = '3';
			array[1] = 'Alcuni caratteri non sono consentiti.';
                        }
                    }
		return true;
            }
    return false;
}

/**
 * Controlla se email che gli viene passato non &grave; una stringa vuota
 * e e se &egrave scritto in maniera corretta.
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} email da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jemail(email,array){
    array = array || new Array();
    var r3 = /^[0-9a-z_\.]+@+[a-z]+\.+[a-z0-9]{2,4}$/;
    if(!email.match(r3)){
		if(email==""){
                        array[0] = '1';
			array[1] = "Email vuota";
                        }
		else{
                    array[0] = '2'
                    array[1] = 'Il formato della mail è errato';
                    }
		return true;
            }
    return false
}

/**
 * Controlla se i due parametri passati sono uguali
 * Setta l'array che gli viene passato con gli errori.
 * @param {char} prima stringa da analizzare
 * @param {char} seconda stringa da analizzare
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return false se passa tutti i controlli, true se trova errori
 * @type bool
 */
function jMatch(entry1,entry2,array){
    array = array || new Array();
    if(entry1 != entry2){
        array[0] = '1';
        array[1] = 'I due campi non coincidono';
        return true;
    }
    return false;
}

/**
 * Controlla se la data inserita è maggiore della data attuale
 * @param {char} lettera l'ultima lettera dell'id della select della data
 * @param {array} array L'array nel quale viene scritto l'errore
 * @return true se la data è maggiore, false se è minore di quella odierna
 * @type bool
 */
    function jisMaggioreDataAttuale(lettera,array){
        lettera = lettera || 'P';
        array = array || new Array();
        var oggi,dataP
        oggi = new Date();
        
        dataP = document.getElementById('anno'+lettera).value+',';
        var mese = parseInt(document.getElementById('mese'+lettera).value);
        if(document.getElementById('mese'+lettera).selectedIndex != 0){
            mese = mese-1;
            mese = ''+mese;
            }
        dataP = dataP+mese+',';
        dataP = dataP+document.getElementById('giorno'+lettera).value+',';
        dataP = dataP+document.getElementById('ora'+lettera).value+',';
        dataP = dataP+document.getElementById('minuti'+lettera).value+',00';
        dataP = eval("new Date("+dataP+")");
        if(dataP < oggi){
           array[0] = '1';
           array[1] = 'Data passata';
           return true;}
        return false;

    }